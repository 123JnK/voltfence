export type SiteCategory = 
  | 'substation'
  | 'industrial'
  | 'commercial'
  | 'residential'
  | 'solar_renewable'
  | 'municipal';

export type SiteStatus = 'active' | 'completed' | 'paused';

export interface ElectricalSite {
  id: string;
  code: string;
  name: string;
  clientName: string;
  address: string;
  location: {
    lat: number;
    lng: number;
  };
  geofenceRadius: number; // in meters
  status: SiteStatus;
  category: SiteCategory;
  hazards: string[];
  contactPerson: string;
  contactPhone: string;
  startDate: string;
  targetEndDate: string;
  assignedEmployeeIds: string[];
  notes?: string;
  estimatedBudgetHours?: number;

  // Project-Specific Shift Time Slab & Overtime Schedule
  shiftConfig?: ProjectShiftConfig;

  // Per-Project Custom Rates Assigned to Each Employee Separately
  employeeProjectRates?: Record<string, EmployeeProjectRate>;
}

export interface ProjectShiftConfig {
  shiftName: string; // e.g. "Standard General Shift"
  shiftStartTime: string; // e.g. "08:00"
  shiftEndTime: string; // e.g. "17:00"
  breakMinutes: number; // e.g. 60
  regularShiftHours: number; // e.g. 8.0 hours
  overtimeStartTime: string; // e.g. "17:30" (time when overtime begins)
  overtimeGraceMinutes?: number; // e.g. 15 or 30 minutes
}

export interface EmployeeProjectRate {
  regularHourlyRate: number; // Rate for regular shift hours on this project
  overtimeHourlyRate: number; // Rate for overtime hours on this project
  dailyWage?: number; // Optional reference daily wage for regular shift on this project
}

export interface AuthSession {
  role: 'manager' | 'employee' | 'client';
  employeeId?: string; // Present when role === 'employee'
  clientEmail?: string; // Present when role === 'client'
  clientName?: string;
  authenticatedAt: string;
}

export type EmployeeStatus = 'on_site' | 'off_site' | 'on_break' | 'on_leave';

export interface LeaveBalance {
  casual: number;
  sick: number;
  earned: number;
}

export interface EmployeeLocation {
  lat: number;
  lng: number;
  lastPingTime: string;
  battery?: number;
  accuracy?: number;
  isOnline?: boolean;
  address?: string;
}

export interface Employee {
  id: string;
  code: string;
  name: string;
  role: string;
  email: string;
  phone: string;
  emergencyContact: string;
  certifications: string[];
  avatarBg: string;
  primarySiteId?: string;
  status: EmployeeStatus;
  isActive: boolean; // When false, the app is disabled on their phone!
  deactivatedReason?: string;

  // Live Location tracking (visible to manager even when not signed in)
  currentLocation?: EmployeeLocation;

  // Salary, Daily Wage & Overtime Rates (Configurable separately per employee)
  dailyWage: number; // Regular shift daily wage (e.g. ₹1,200/day)
  regularShiftHours: number; // Standard regular shift duration (e.g. 8.0 hours)
  regularHourlyRate: number; // Rate per hour for regular shift (e.g. ₹150/hr)
  overtimeHourlyRate: number; // Overtime rate per hour (e.g. ₹250/hr)
  basicSalary: number; // Monthly reference basic wage
  hazardAllowance: number; // Site special hazard allowance
  epfEnabled: boolean; // Whether EPF is applicable
  epfUan?: string; // EPF Universal Account Number (UAN)
  epfRate: number; // EPF employee deduction rate (default 12%)
  leaveBalance: LeaveBalance;
  joinedDate: string;
  bankAccountMasked?: string;
  pin?: string; // 4-digit secure access PIN for employee login (default '1234')
}

export type LeaveType = 'casual' | 'sick' | 'earned' | 'unpaid';
export type LeaveStatus = 'pending' | 'approved' | 'rejected';

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  type: LeaveType;
  startDate: string;
  endDate: string;
  totalDays: number;
  reason: string;
  status: LeaveStatus;
  appliedDate: string;
  reviewedDate?: string;
  reviewedBy?: string;
  reviewNote?: string;
}

export type AttendanceStatus = 'active_shift' | 'completed' | 'flagged_mismatch' | 'overtime';

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  siteId: string;
  siteName: string;
  date: string; // YYYY-MM-DD
  checkInTime: string; // ISO
  checkOutTime?: string; // ISO
  checkInCoords: {
    lat: number;
    lng: number;
  };
  checkInDistanceMeters: number;
  checkOutCoords?: {
    lat: number;
    lng: number;
  };
  checkOutDistanceMeters?: number;
  geofenceVerified: boolean;
  status: AttendanceStatus;
  ppeConfirmed: boolean;
  taskDescription?: string;
  durationMinutes?: number;
  deviceNotes?: string;
  // Working hours and wage breakdown per shift
  regularHours?: number;
  overtimeHours?: number;
  regularPay?: number;
  overtimePay?: number;
  totalShiftPay?: number;
  isManagerInitiated?: boolean;
}

export interface UserLocation {
  lat: number;
  lng: number;
  accuracy: number;
  isSimulated?: boolean;
  sourceDescription?: string;
}

export interface CompanySettings {
  companyName: string;
  currencySymbol: string; // '₹' | '$' | '€' | '£'
  currencyCode: string; // 'INR' | 'USD'
  defaultEpfRate: number; // default 12%
  defaultEmployerEpfRate: number; // 3.67%
  defaultEmployerEpsRate: number; // 8.33%
  googleSheetWebhookUrl?: string; // Google Apps Script Web App URL for real-time Sheet sync
  googleSheetAutoSync?: boolean; // Whether to automatically post records to Google Sheet on clock-in

  // CLIENT PASSKEY & AUTHORIZED EMAILS (Instant Access without Google Login)
  clientPasskey?: string; // e.g. 'VOLT-CLIENT-2026'
  authorizedEmails?: string[]; // Whitelisted emails for client / supervisors
  allowPasskeyDirectAccess?: boolean; // Enable 1-tap passkey access
}
