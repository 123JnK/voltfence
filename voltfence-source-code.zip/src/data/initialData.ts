import { ElectricalSite, Employee, AttendanceRecord, LeaveRequest, CompanySettings } from '../types';

export const DEFAULT_COMPANY_SETTINGS: CompanySettings = {
  companyName: 'VoltFence Electrical Engineering & Maintenance',
  currencySymbol: '₹',
  currencyCode: 'INR',
  defaultEpfRate: 12,
  defaultEmployerEpfRate: 3.67,
  defaultEmployerEpsRate: 8.33,
  clientPasskey: 'VOLT-CLIENT-2026',
  authorizedEmails: ['client@voltfence.in', 'sitelead@electrical.com'],
  allowPasskeyDirectAccess: true,
};

export const INITIAL_SITES: ElectricalSite[] = [
  {
    id: 'site-1',
    code: 'ELEC-ST-101',
    name: 'Industrial 33kV/11kV Substation Switchgear Retrofit',
    clientName: 'State Industrial Power Distribution Corp',
    address: 'Plot 42, Heavy Industrial Area, Phase II',
    location: {
      lat: 28.5355,
      lng: 77.3910,
    },
    geofenceRadius: 120,
    status: 'active',
    category: 'substation',
    hazards: ['33kV/11kV Medium Voltage', 'Arc Flash PPE Cat 4 Required', 'Confined Switchgear Trench'],
    contactPerson: 'Rajesh Verma (Superintendent)',
    contactPhone: '+91 98110 23411',
    startDate: '2026-09-15',
    targetEndDate: '2026-11-30',
    assignedEmployeeIds: ['emp-1', 'emp-2', 'emp-5', 'emp-9'],
    notes: 'Busbar thermal imaging and breaker calibration scheduled this week.',
    estimatedBudgetHours: 420,
  },
  {
    id: 'site-2',
    code: 'ELEC-ST-102',
    name: 'Metro Hospital Emergency DG Sets & ATS Maintenance',
    clientName: 'City Healthcare & Research Institute',
    address: 'Medical Campus, Central Ring Road',
    location: {
      lat: 28.5672,
      lng: 77.2100,
    },
    geofenceRadius: 100,
    status: 'active',
    category: 'commercial',
    hazards: ['Critical Life Safety Load', 'Dual 1500kVA Diesel Generators', 'Automatic Transfer Switches'],
    contactPerson: 'Anil Sharma (Chief Facilities Engineer)',
    contactPhone: '+91 98220 54122',
    startDate: '2026-10-01',
    targetEndDate: '2026-10-28',
    assignedEmployeeIds: ['emp-3', 'emp-4', 'emp-11', 'emp-12'],
    notes: 'Load bank testing permitted only between 06:00 and 10:00.',
    estimatedBudgetHours: 180,
  },
  {
    id: 'site-3',
    code: 'ELEC-ST-103',
    name: 'Solar Park 5MW Central Inverters & HT Cabling',
    clientName: 'Green Urja Renewable Infrastructure',
    address: 'Sector 88, Solar Energy Corridor',
    location: {
      lat: 28.4595,
      lng: 77.0266,
    },
    geofenceRadius: 300,
    status: 'active',
    category: 'solar_renewable',
    hazards: ['1500V DC String Arrays', 'Remote Heat Exposure', 'Inverter Step-Up Transformers'],
    contactPerson: 'Pooja Nair (Site Incharge)',
    contactPhone: '+91 98450 77199',
    startDate: '2026-08-20',
    targetEndDate: '2026-12-15',
    assignedEmployeeIds: ['emp-6', 'emp-7', 'emp-15', 'emp-16'],
    notes: 'Array Block 3 strings 12-18 experiencing ground fault leakage.',
    estimatedBudgetHours: 650,
  },
  {
    id: 'site-4',
    code: 'ELEC-ST-104',
    name: 'DLF CyberCity Towers HT Panel & Lighting Automation',
    clientName: 'CyberCity Commercial Asset Management',
    address: 'Tower B, Commercial Zone',
    location: {
      lat: 28.4900,
      lng: 77.0800,
    },
    geofenceRadius: 80,
    status: 'active',
    category: 'commercial',
    hazards: ['Live 415V 3-Phase Risers', 'Working at Heights', 'Occupied Building Rules'],
    contactPerson: 'Sanjay Mehra (Property Operations)',
    contactPhone: '+91 98100 44211',
    startDate: '2026-09-01',
    targetEndDate: '2026-11-10',
    assignedEmployeeIds: ['emp-8', 'emp-10', 'emp-13'],
    notes: 'DALI dimming control commissioning on floors 14 to 22.',
    estimatedBudgetHours: 320,
  },
  {
    id: 'site-5',
    code: 'ELEC-ST-105',
    name: 'Manufacturing Plant VFDs & Motor Control Centers',
    clientName: 'Bharat Precision Logistics & Motors',
    address: 'Industrial Plot 12, Automotive Hub',
    location: {
      lat: 28.4100,
      lng: 77.3100,
    },
    geofenceRadius: 150,
    status: 'active',
    category: 'industrial',
    hazards: ['Harmonic Filters', 'High Current MCC Panels', 'Active Automated Conveyors'],
    contactPerson: 'Karan Patel (Plant Electrical Head)',
    contactPhone: '+91 98700 88200',
    startDate: '2026-10-05',
    targetEndDate: '2026-11-20',
    assignedEmployeeIds: ['emp-14', 'emp-17', 'emp-18'],
    notes: 'Replacing obsolete ABB drives with newest Rockwell PowerFlex 755T.',
    estimatedBudgetHours: 240,
  },
  {
    id: 'site-6',
    code: 'ELEC-ST-106',
    name: 'Metro Rail Station Emergency Power & UPS Bank Recert',
    clientName: 'Rapid Transit Corporation',
    address: 'Central Interchange Station',
    location: {
      lat: 28.6139,
      lng: 77.2090,
    },
    geofenceRadius: 90,
    status: 'active',
    category: 'municipal',
    hazards: ['Traction Power Proximity', 'Night Shift Track Clearance', 'Emergency UPS Battery Banks'],
    contactPerson: 'Sunil Rao (Safety Officer)',
    contactPhone: '+91 99110 33881',
    startDate: '2026-10-08',
    targetEndDate: '2026-10-31',
    assignedEmployeeIds: ['emp-19', 'emp-20'],
    notes: 'Class 1 Div 2 lighting fixture replacements on underground platforms.',
    estimatedBudgetHours: 120,
  },
  {
    id: 'site-7',
    code: 'ELEC-ST-099',
    name: 'Container Terminal High Mast Lighting (Completed)',
    clientName: 'Inland Port Authority',
    address: 'Dry Port Terminal 1',
    location: {
      lat: 28.5100,
      lng: 77.2900,
    },
    geofenceRadius: 110,
    status: 'completed',
    category: 'industrial',
    hazards: ['Weather Corrosion', 'Submerged Conduits', 'High Mast 30m Poles'],
    contactPerson: 'Col. V. Raman',
    contactPhone: '+91 98112 00991',
    startDate: '2026-07-01',
    targetEndDate: '2026-09-30',
    assignedEmployeeIds: [],
    notes: 'Project successfully commissioned and signed off with zero safety incidents.',
    estimatedBudgetHours: 350,
  },
];
const RAW_EMPLOYEES: any[] = [
  {
    id: 'emp-1',
    code: 'ELEC-001',
    name: 'Rameshwar "Ram" Sharma',
    role: 'Licensed Electrical Supervisor',
    email: 'rameshwar.s@voltelectric.in',
    phone: '+91 98101 44112',
    emergencyContact: 'Sunita Sharma (+91 98101 99881)',
    certifications: ['Grade A Electrical Supervisor License', 'NFPA 70E Arc Flash', 'DISHA Certified'],
    avatarBg: 'bg-blue-600',
    primarySiteId: 'site-1',
    status: 'on_site',
    isActive: true,
    basicSalary: 48000,
    hazardAllowance: 6000,
    epfEnabled: true,
    epfUan: '101492819001',
    epfRate: 12,
    leaveBalance: { casual: 5, sick: 7, earned: 12 },
    joinedDate: '2023-02-15',
    bankAccountMasked: '•••• •••• 4481',
  },
  {
    id: 'emp-2',
    code: 'ELEC-002',
    name: 'Jagdish Chandra',
    role: 'High-Voltage Substation Specialist',
    email: 'jagdish.c@voltelectric.in',
    phone: '+91 98202 55223',
    emergencyContact: 'Geeta Chandra (+91 98202 11440)',
    certifications: ['Substation Tech L4', '33kV High Voltage Switching', 'Safety Competency'],
    avatarBg: 'bg-indigo-600',
    primarySiteId: 'site-1',
    status: 'on_site',
    isActive: true,
    basicSalary: 45000,
    hazardAllowance: 5500,
    epfEnabled: true,
    epfUan: '101492819002',
    epfRate: 12,
    leaveBalance: { casual: 6, sick: 6, earned: 14 },
    joinedDate: '2023-05-10',
    bankAccountMasked: '•••• •••• 8820',
  },
  {
    id: 'emp-3',
    code: 'ELEC-003',
    name: 'Priyanka Sen',
    role: 'Lead Hospital Maintenance Electrician',
    email: 'priyanka.s@voltelectric.in',
    phone: '+91 98303 66334',
    emergencyContact: 'Subir Sen (+91 98303 88221)',
    certifications: ['Electrical Wireman Grade 1', 'Hospital Critical Systems', 'NFPA 99'],
    avatarBg: 'bg-emerald-600',
    primarySiteId: 'site-2',
    status: 'on_site',
    isActive: true,
    basicSalary: 42000,
    hazardAllowance: 4800,
    epfEnabled: true,
    epfUan: '101492819003',
    epfRate: 12,
    leaveBalance: { casual: 4, sick: 8, earned: 11 },
    joinedDate: '2023-08-01',
    bankAccountMasked: '•••• •••• 1209',
  },
  {
    id: 'emp-4',
    code: 'ELEC-004',
    name: 'Tariq Hussain',
    role: 'Generator & ATS Control Technician',
    email: 'tariq.h@voltelectric.in',
    phone: '+91 98404 77445',
    emergencyContact: 'Amina Hussain (+91 98404 22110)',
    certifications: ['Cummins/Kirloskar DG Certified', 'Schneider ATS Specialist'],
    avatarBg: 'bg-teal-600',
    primarySiteId: 'site-2',
    status: 'on_site',
    isActive: true,
    basicSalary: 39500,
    hazardAllowance: 4200,
    epfEnabled: true,
    epfUan: '101492819004',
    epfRate: 12,
    leaveBalance: { casual: 5, sick: 6, earned: 13 },
    joinedDate: '2023-09-18',
    bankAccountMasked: '•••• •••• 6712',
  },
  {
    id: 'emp-5',
    code: 'ELEC-005',
    name: 'Manoj Kumar',
    role: 'Senior Wireman & Cable Jointer',
    email: 'manoj.k@voltelectric.in',
    phone: '+91 98505 88556',
    emergencyContact: 'Rekha Kumar (+91 98505 33771)',
    certifications: ['Licensed Wireman', 'CPR/First Aid', 'HT Cable Splicing'],
    avatarBg: 'bg-cyan-600',
    primarySiteId: 'site-1',
    status: 'on_site',
    isActive: true,
    basicSalary: 37000,
    hazardAllowance: 3800,
    epfEnabled: true,
    epfUan: '101492819005',
    epfRate: 12,
    leaveBalance: { casual: 6, sick: 5, earned: 10 },
    joinedDate: '2024-01-10',
    bankAccountMasked: '•••• •••• 9931',
  },
  {
    id: 'emp-6',
    code: 'ELEC-006',
    name: 'Kavita Das',
    role: 'Solar PV & Inverter Field Specialist',
    email: 'kavita.d@voltelectric.in',
    phone: '+91 98606 99667',
    emergencyContact: 'Arup Das (+91 98606 00332)',
    certifications: ['NISE Solar Certified', 'SMA Solar Inverters', 'Safety Level 2'],
    avatarBg: 'bg-amber-600',
    primarySiteId: 'site-3',
    status: 'on_site',
    isActive: true,
    basicSalary: 40000,
    hazardAllowance: 4200,
    epfEnabled: true,
    epfUan: '101492819006',
    epfRate: 12,
    leaveBalance: { casual: 7, sick: 7, earned: 15 },
    joinedDate: '2023-11-01',
    bankAccountMasked: '•••• •••• 2184',
  },
  {
    id: 'emp-7',
    code: 'ELEC-007',
    name: 'Deepak Yadav',
    role: 'Medium Voltage 33kV Cable Splicer',
    email: 'deepak.y@voltelectric.in',
    phone: '+91 98707 11778',
    emergencyContact: 'Sunita Yadav (+91 98707 44882)',
    certifications: ['Raychem / 3M Cold Shrink HT Splicer', 'Confined Space Rescue'],
    avatarBg: 'bg-orange-600',
    primarySiteId: 'site-3',
    status: 'on_site',
    isActive: true,
    basicSalary: 43000,
    hazardAllowance: 5000,
    epfEnabled: true,
    epfUan: '101492819007',
    epfRate: 12,
    leaveBalance: { casual: 5, sick: 6, earned: 12 },
    joinedDate: '2023-04-20',
    bankAccountMasked: '•••• •••• 5590',
  },
  {
    id: 'emp-8',
    code: 'ELEC-008',
    name: 'Sunita Meena',
    role: 'Commercial Facilities Electrician',
    email: 'sunita.m@voltelectric.in',
    phone: '+91 98808 22889',
    emergencyContact: 'Mahesh Meena (+91 98808 77113)',
    certifications: ['Licensed Wireman', 'Schneider EcoStruxure', 'First Aid'],
    avatarBg: 'bg-purple-600',
    primarySiteId: 'site-4',
    status: 'on_site',
    isActive: true,
    basicSalary: 36000,
    hazardAllowance: 3200,
    epfEnabled: true,
    epfUan: '101492819008',
    epfRate: 12,
    leaveBalance: { casual: 6, sick: 8, earned: 10 },
    joinedDate: '2024-02-14',
    bankAccountMasked: '•••• •••• 3319',
  },
  {
    id: 'emp-9',
    code: 'ELEC-009',
    name: 'Bikramjit Singh',
    role: 'Electrical Apprentice (ITI Final Year)',
    email: 'bikram.s@voltelectric.in',
    phone: '+91 98909 33990',
    emergencyContact: 'Harpreet Singh (+91 98909 99224)',
    certifications: ['ITI Electrician Trade', 'Apprenticeship NCVT', 'Basic Safety'],
    avatarBg: 'bg-violet-600',
    primarySiteId: 'site-1',
    status: 'on_site',
    isActive: true,
    basicSalary: 25000,
    hazardAllowance: 2500,
    epfEnabled: true,
    epfUan: '101492819009',
    epfRate: 12,
    leaveBalance: { casual: 5, sick: 5, earned: 8 },
    joinedDate: '2024-06-01',
    bankAccountMasked: '•••• •••• 7740',
  },
  {
    id: 'emp-10',
    code: 'ELEC-010',
    name: 'Arun Prakash',
    role: 'Low Voltage & BMS Specialist',
    email: 'arun.p@voltelectric.in',
    phone: '+91 99010 44001',
    emergencyContact: 'Meera Prakash (+91 99010 66442)',
    certifications: ['DALI & 0-10V Dimming', 'Fire Alarm Interlock Cert'],
    avatarBg: 'bg-fuchsia-600',
    primarySiteId: 'site-4',
    status: 'on_site',
    isActive: true,
    basicSalary: 35000,
    hazardAllowance: 2800,
    epfEnabled: true,
    epfUan: '101492819010',
    epfRate: 12,
    leaveBalance: { casual: 6, sick: 7, earned: 11 },
    joinedDate: '2024-03-22',
    bankAccountMasked: '•••• •••• 8844',
  },
  {
    id: 'emp-11',
    code: 'ELEC-011',
    name: 'Lalit Mohan',
    role: 'Thermal Imaging & Condition Monitoring Tech',
    email: 'lalit.m@voltelectric.in',
    phone: '+91 99111 55112',
    emergencyContact: 'Suman Mohan (+91 99111 88335)',
    certifications: ['FLIR Level II Thermographer', 'Ultrasonic Inspection'],
    avatarBg: 'bg-rose-600',
    primarySiteId: 'site-2',
    status: 'on_site',
    isActive: true,
    basicSalary: 39000,
    hazardAllowance: 3600,
    epfEnabled: true,
    epfUan: '101492819011',
    epfRate: 12,
    leaveBalance: { casual: 4, sick: 6, earned: 9 },
    joinedDate: '2023-10-15',
    bankAccountMasked: '•••• •••• 1029',
  },
  {
    id: 'emp-12',
    code: 'ELEC-012',
    name: 'Zameer Khan',
    role: 'Electrical Apprentice (ITI Level 2)',
    email: 'zameer.k@voltelectric.in',
    phone: '+91 99212 66223',
    emergencyContact: 'Nasreen Khan (+91 99212 55001)',
    certifications: ['ITI Electrician Trade', 'Lockout/Tagout Safety'],
    avatarBg: 'bg-pink-600',
    primarySiteId: 'site-2',
    status: 'on_site',
    isActive: true,
    basicSalary: 23000,
    hazardAllowance: 2200,
    epfEnabled: true,
    epfUan: '101492819012',
    epfRate: 12,
    leaveBalance: { casual: 7, sick: 7, earned: 8 },
    joinedDate: '2024-07-10',
    bankAccountMasked: '•••• •••• 4410',
  },
  {
    id: 'emp-13',
    code: 'ELEC-013',
    name: 'Kishore Reddy',
    role: 'Senior Maintenance Wireman',
    email: 'kishore.r@voltelectric.in',
    phone: '+91 99313 77334',
    emergencyContact: 'Padma Reddy (+91 99313 44112)',
    certifications: ['Grade A Wireman License', 'EV Charger Installation'],
    avatarBg: 'bg-sky-600',
    primarySiteId: 'site-4',
    status: 'on_break',
    isActive: true,
    basicSalary: 37500,
    hazardAllowance: 3200,
    epfEnabled: true,
    epfUan: '101492819013',
    epfRate: 12,
    leaveBalance: { casual: 6, sick: 6, earned: 12 },
    joinedDate: '2023-12-05',
    bankAccountMasked: '•••• •••• 3391',
  },
  {
    id: 'emp-14',
    code: 'ELEC-014',
    name: 'Chetan Mistry',
    role: 'Industrial Motor & VFD Specialist',
    email: 'chetan.m@voltelectric.in',
    phone: '+91 99414 88445',
    emergencyContact: 'Bhavna Mistry (+91 99414 33221)',
    certifications: ['Rockwell Automation Drives', 'Siemens Sinamics'],
    avatarBg: 'bg-blue-700',
    primarySiteId: 'site-5',
    status: 'on_site',
    isActive: true,
    basicSalary: 44000,
    hazardAllowance: 5000,
    epfEnabled: true,
    epfUan: '101492819014',
    epfRate: 12,
    leaveBalance: { casual: 5, sick: 8, earned: 14 },
    joinedDate: '2023-06-25',
    bankAccountMasked: '•••• •••• 8102',
  },
  {
    id: 'emp-15',
    code: 'ELEC-015',
    name: 'Abhishek Jha',
    role: 'Solar Commissioning Technician',
    email: 'abhishek.j@voltelectric.in',
    phone: '+91 99515 99556',
    emergencyContact: 'Pooja Jha (+91 99515 22773)',
    certifications: ['Megger Insulation Testing', 'Solar PV Grid Synchronization'],
    avatarBg: 'bg-yellow-600',
    primarySiteId: 'site-3',
    status: 'on_site',
    isActive: true,
    basicSalary: 35000,
    hazardAllowance: 3000,
    epfEnabled: true,
    epfUan: '101492819015',
    epfRate: 12,
    leaveBalance: { casual: 6, sick: 6, earned: 10 },
    joinedDate: '2024-04-18',
    bankAccountMasked: '•••• •••• 9012',
  },
  {
    id: 'emp-16',
    code: 'ELEC-016',
    name: 'Noah Patel',
    role: 'Junior Electrician',
    email: 'noah.p@voltelectric.in',
    phone: '+91 99616 11667',
    emergencyContact: 'Bhavik Patel (+91 99616 99002)',
    certifications: ['ITI Electrician Trade', 'CPR/AED Certified'],
    avatarBg: 'bg-emerald-700',
    primarySiteId: 'site-3',
    status: 'off_site',
    isActive: true,
    basicSalary: 24000,
    hazardAllowance: 2000,
    epfEnabled: true,
    epfUan: '101492819016',
    epfRate: 12,
    leaveBalance: { casual: 7, sick: 8, earned: 7 },
    joinedDate: '2024-08-01',
    bankAccountMasked: '•••• •••• 5519',
  },
  {
    id: 'emp-17',
    code: 'ELEC-017',
    name: 'Samira Hameed',
    role: 'Instrumentation & Process Control Tech',
    email: 'samira.h@voltelectric.in',
    phone: '+91 99717 22778',
    emergencyContact: 'Farooq Hameed (+91 99717 88114)',
    certifications: ['Instrumentation Diploma', '4-20mA Calibration', 'PLC Diagnostics'],
    avatarBg: 'bg-purple-700',
    primarySiteId: 'site-5',
    status: 'on_site',
    isActive: true,
    basicSalary: 42500,
    hazardAllowance: 4500,
    epfEnabled: true,
    epfUan: '101492819017',
    epfRate: 12,
    leaveBalance: { casual: 5, sick: 7, earned: 13 },
    joinedDate: '2023-09-01',
    bankAccountMasked: '•••• •••• 6631',
  },
  {
    id: 'emp-18',
    code: 'ELEC-018',
    name: 'Tarun Goswami',
    role: 'Maintenance Wireman Grade 1',
    email: 'tarun.g@voltelectric.in',
    phone: '+91 99818 33889',
    emergencyContact: 'Vandana Goswami (+91 99818 77332)',
    certifications: ['Licensed Wireman', 'NFPA 70E Cat 2'],
    avatarBg: 'bg-indigo-700',
    primarySiteId: 'site-5',
    status: 'on_site',
    isActive: true,
    basicSalary: 36500,
    hazardAllowance: 3400,
    epfEnabled: true,
    epfUan: '101492819018',
    epfRate: 12,
    leaveBalance: { casual: 6, sick: 5, earned: 11 },
    joinedDate: '2024-01-20',
    bankAccountMasked: '•••• •••• 2209',
  },
  {
    id: 'emp-19',
    code: 'ELEC-019',
    name: 'Devraj Thapa',
    role: 'Fire Alarm & Emergency Power Specialist',
    email: 'devraj.t@voltelectric.in',
    phone: '+91 99919 44990',
    emergencyContact: 'Maya Thapa (+91 99919 55663)',
    certifications: ['Fire Alarm Level III', 'UPS Battery Maintenance'],
    avatarBg: 'bg-red-600',
    primarySiteId: 'site-6',
    status: 'on_site',
    isActive: true,
    basicSalary: 43000,
    hazardAllowance: 4500,
    epfEnabled: true,
    epfUan: '101492819019',
    epfRate: 12,
    leaveBalance: { casual: 5, sick: 6, earned: 12 },
    joinedDate: '2023-07-15',
    bankAccountMasked: '•••• •••• 7712',
  },
  {
    id: 'emp-20',
    code: 'ELEC-020',
    name: 'Harpreet Kaur',
    role: 'Electrical Apprentice (Level 3)',
    email: 'harpreet.k@voltelectric.in',
    phone: '+91 98120 55001',
    emergencyContact: 'Kuldeep Singh (+91 98120 11224)',
    certifications: ['ITI Gold Medalist', 'Metro Track Safety Clearance'],
    avatarBg: 'bg-teal-700',
    primarySiteId: 'site-6',
    status: 'on_site',
    isActive: true,
    basicSalary: 26000,
    hazardAllowance: 2400,
    epfEnabled: true,
    epfUan: '101492819020',
    epfRate: 12,
    leaveBalance: { casual: 7, sick: 6, earned: 9 },
    joinedDate: '2024-05-10',
    bankAccountMasked: '•••• •••• 3418',
  },
];

export const INITIAL_EMPLOYEES: Employee[] = RAW_EMPLOYEES.map((emp, i) => {
  const dailyWage = Math.round((emp.basicSalary / 26) / 10) * 10;
  const regularShiftHours = 8.0;
  const regularHourlyRate = Math.round(dailyWage / regularShiftHours);
  const overtimeHourlyRate = Math.round(regularHourlyRate * 1.5);

  const siteIndex = (i % 6) + 1;
  const targetSite = INITIAL_SITES.find((s) => s.id === `site-${siteIndex}`) || INITIAL_SITES[0];
  const isOnDuty = emp.status === 'on_site';
  const offsetLat = isOnDuty ? ((i % 3 - 1) * 0.0003) : (((i % 4) - 1.5) * 0.012);
  const offsetLng = isOnDuty ? ((i % 2 - 0.5) * 0.0003) : (((i % 3) - 1) * 0.015);

  return {
    ...emp,
    pin: emp.pin || '1234',
    dailyWage,
    regularShiftHours,
    regularHourlyRate,
    overtimeHourlyRate,
    currentLocation: {
      lat: Number((targetSite.location.lat + offsetLat).toFixed(6)),
      lng: Number((targetSite.location.lng + offsetLng).toFixed(6)),
      lastPingTime: `${((i * 4 + 2) % 20) + 1} mins ago`,
      battery: 65 + ((i * 7) % 32),
      accuracy: 3 + (i % 4),
      isOnline: true,
      address: isOnDuty ? `${targetSite.name.slice(0, 28)}` : 'En route / Delhi NCR',
    },
  };
});

const todayStr = new Date().toISOString().split('T')[0];

export const INITIAL_LEAVES: LeaveRequest[] = [
  {
    id: 'leave-101',
    employeeId: 'emp-16',
    employeeName: 'Noah Patel',
    employeeCode: 'ELEC-016',
    type: 'casual',
    startDate: todayStr,
    endDate: todayStr,
    totalDays: 1,
    reason: 'Family urgent appointment.',
    status: 'approved',
    appliedDate: '2026-10-10',
    reviewedDate: '2026-10-11',
    reviewedBy: 'Operations Manager',
    reviewNote: 'Approved. Reliever assigned to Solar Inverter Block.',
  },
  {
    id: 'leave-102',
    employeeId: 'emp-13',
    employeeName: 'Kishore Reddy',
    employeeCode: 'ELEC-013',
    type: 'sick',
    startDate: '2026-10-14',
    endDate: '2026-10-15',
    totalDays: 2,
    reason: 'Dental tooth extraction and recovery.',
    status: 'pending',
    appliedDate: '2026-10-11',
  },
  {
    id: 'leave-103',
    employeeId: 'emp-9',
    employeeName: 'Bikramjit Singh',
    employeeCode: 'ELEC-009',
    type: 'earned',
    startDate: '2026-10-20',
    endDate: '2026-10-24',
    totalDays: 5,
    reason: 'Annual trade apprenticeship technical semester exams.',
    status: 'pending',
    appliedDate: '2026-10-12',
  },
];

export const INITIAL_ATTENDANCE: AttendanceRecord[] = [
  {
    id: 'att-101',
    employeeId: 'emp-1',
    employeeName: 'Rameshwar "Ram" Sharma',
    siteId: 'site-1',
    siteName: 'Industrial 33kV/11kV Substation Switchgear Retrofit',
    date: todayStr,
    checkInTime: `${todayStr}T06:54:12.000Z`,
    checkInCoords: { lat: 28.5356, lng: 77.3912 },
    checkInDistanceMeters: 24,
    geofenceVerified: true,
    status: 'active_shift',
    ppeConfirmed: true,
    taskDescription: 'Morning safety tailboard briefing & 33kV Busbar A de-energization lockout tagout.',
    deviceNotes: 'Redmi Note 13 5G • GPS accuracy: ±4m',
  },
  {
    id: 'att-102',
    employeeId: 'emp-2',
    employeeName: 'Jagdish Chandra',
    siteId: 'site-1',
    siteName: 'Industrial 33kV/11kV Substation Switchgear Retrofit',
    date: todayStr,
    checkInTime: `${todayStr}T06:58:30.000Z`,
    checkInCoords: { lat: 28.5354, lng: 77.3908 },
    checkInDistanceMeters: 22,
    geofenceVerified: true,
    status: 'active_shift',
    ppeConfirmed: true,
    taskDescription: 'Vacuum Circuit Breaker VCB contact resistance micro-ohmmeter testing.',
    deviceNotes: 'Samsung Galaxy M34 • GPS accuracy: ±3m',
  },
  {
    id: 'att-103',
    employeeId: 'emp-3',
    employeeName: 'Priyanka Sen',
    siteId: 'site-2',
    siteName: 'Metro Hospital Emergency DG Sets & ATS Maintenance',
    date: todayStr,
    checkInTime: `${todayStr}T07:12:05.000Z`,
    checkInCoords: { lat: 28.5674, lng: 77.2102 },
    checkInDistanceMeters: 28,
    geofenceVerified: true,
    status: 'active_shift',
    ppeConfirmed: true,
    taskDescription: 'Emergency ATS 4 bypass isolation inspection in basement critical wing.',
    deviceNotes: 'Realme Narzo 60 • GPS accuracy: ±5m',
  },
  {
    id: 'att-104',
    employeeId: 'emp-4',
    employeeName: 'Tariq Hussain',
    siteId: 'site-2',
    siteName: 'Metro Hospital Emergency DG Sets & ATS Maintenance',
    date: todayStr,
    checkInTime: `${todayStr}T07:15:40.000Z`,
    checkInCoords: { lat: 28.5670, lng: 77.2098 },
    checkInDistanceMeters: 25,
    geofenceVerified: true,
    status: 'active_shift',
    ppeConfirmed: true,
    taskDescription: 'Governor calibration on Cummins 1500kVA DG Set 2.',
    deviceNotes: 'OnePlus Nord CE 3 • GPS accuracy: ±4m',
  },
  {
    id: 'att-105',
    employeeId: 'emp-5',
    employeeName: 'Manoj Kumar',
    siteId: 'site-1',
    siteName: 'Industrial 33kV/11kV Substation Switchgear Retrofit',
    date: todayStr,
    checkInTime: `${todayStr}T07:05:18.000Z`,
    checkInCoords: { lat: 28.5358, lng: 77.3914 },
    checkInDistanceMeters: 45,
    geofenceVerified: true,
    status: 'active_shift',
    ppeConfirmed: true,
    taskDescription: 'Earthing copper flat strip connections on new cable trench.',
    deviceNotes: 'Vivo T2 5G • GPS accuracy: ±5m',
  },
  {
    id: 'att-106',
    employeeId: 'emp-6',
    employeeName: 'Kavita Das',
    siteId: 'site-3',
    siteName: 'Solar Park 5MW Central Inverters & HT Cabling',
    date: todayStr,
    checkInTime: `${todayStr}T07:28:11.000Z`,
    checkInCoords: { lat: 28.4598, lng: 77.0270 },
    checkInDistanceMeters: 55,
    geofenceVerified: true,
    status: 'active_shift',
    ppeConfirmed: true,
    taskDescription: 'IV Curve tracing and thermography on SCB Combiner Box 4.',
    deviceNotes: 'Motorola G54 • GPS accuracy: ±3m',
  },
  {
    id: 'att-107',
    employeeId: 'emp-7',
    employeeName: 'Deepak Yadav',
    siteId: 'site-3',
    siteName: 'Solar Park 5MW Central Inverters & HT Cabling',
    date: todayStr,
    checkInTime: `${todayStr}T07:35:00.000Z`,
    checkInCoords: { lat: 28.4592, lng: 77.0262 },
    checkInDistanceMeters: 62,
    geofenceVerified: true,
    status: 'active_shift',
    ppeConfirmed: true,
    taskDescription: '33kV HT termination heat shrink kit prep on Inverter Transformer 2.',
    deviceNotes: 'iQOO Z7 • GPS accuracy: ±4m',
  },
  {
    id: 'att-108',
    employeeId: 'emp-8',
    employeeName: 'Sunita Meena',
    siteId: 'site-4',
    siteName: 'DLF CyberCity Towers HT Panel & Lighting Automation',
    date: todayStr,
    checkInTime: `${todayStr}T07:45:22.000Z`,
    checkInCoords: { lat: 28.4902, lng: 77.0802 },
    checkInDistanceMeters: 26,
    geofenceVerified: true,
    status: 'active_shift',
    ppeConfirmed: true,
    taskDescription: 'Floor 18-20 distribution board wire dressing and circuit identification.',
    deviceNotes: 'Samsung Galaxy A34 • GPS accuracy: ±4m',
  },
  {
    id: 'att-109',
    employeeId: 'emp-14',
    employeeName: 'Chetan Mistry',
    siteId: 'site-5',
    siteName: 'Manufacturing Plant VFDs & Motor Control Centers',
    date: todayStr,
    checkInTime: `${todayStr}T07:50:14.000Z`,
    checkInCoords: { lat: 28.4102, lng: 77.3102 },
    checkInDistanceMeters: 31,
    geofenceVerified: true,
    status: 'active_shift',
    ppeConfirmed: true,
    taskDescription: 'Parameter programming on PowerFlex 755T in MCC Enclosure 3.',
    deviceNotes: 'Poco X5 Pro • GPS accuracy: ±3m',
  },
  {
    id: 'att-110',
    employeeId: 'emp-19',
    employeeName: 'Devraj Thapa',
    siteId: 'site-6',
    siteName: 'Metro Rail Station Emergency Power & UPS Bank Recert',
    date: todayStr,
    checkInTime: `${todayStr}T07:58:45.000Z`,
    checkInCoords: { lat: 28.6141, lng: 77.2092 },
    checkInDistanceMeters: 27,
    geofenceVerified: true,
    status: 'active_shift',
    ppeConfirmed: true,
    taskDescription: 'Platform underground UPS battery bank discharge test & relay interlocks.',
    deviceNotes: 'Realme 11 Pro • GPS accuracy: ±5m',
  },
];

export const STORAGE_KEYS = {
  SITES: 'voltfence_sites_v3',
  EMPLOYEES: 'voltfence_employees_v3',
  ATTENDANCE: 'voltfence_attendance_v3',
  LEAVES: 'voltfence_leaves_v3',
  MANAGER_PIN: 'voltfence_manager_pin_v3',
  SETTINGS: 'voltfence_settings_v3',
};

export const DEFAULT_MANAGER_PIN = '1234';

export function loadStoredCompanySettings(): CompanySettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...DEFAULT_COMPANY_SETTINGS,
        ...parsed,
        clientPasskey: parsed.clientPasskey || DEFAULT_COMPANY_SETTINGS.clientPasskey,
        authorizedEmails:
          Array.isArray(parsed.authorizedEmails) && parsed.authorizedEmails.length > 0
            ? parsed.authorizedEmails
            : DEFAULT_COMPANY_SETTINGS.authorizedEmails,
        allowPasskeyDirectAccess:
          parsed.allowPasskeyDirectAccess !== undefined
            ? parsed.allowPasskeyDirectAccess
            : DEFAULT_COMPANY_SETTINGS.allowPasskeyDirectAccess,
      };
    }
  } catch (e) {
    console.error('Failed to load company settings', e);
  }
  return DEFAULT_COMPANY_SETTINGS;
}

export function saveStoredCompanySettings(settings: CompanySettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save company settings', e);
  }
}

export function loadStoredSites(): ElectricalSite[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SITES);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load sites from localStorage', e);
  }
  return INITIAL_SITES;
}

export function saveStoredSites(sites: ElectricalSite[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SITES, JSON.stringify(sites));
  } catch (e) {
    console.error('Failed to save sites to localStorage', e);
  }
}

export function loadStoredEmployees(): Employee[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.EMPLOYEES);
    if (raw) {
      const parsed: Employee[] = JSON.parse(raw);
      return parsed.map((emp, i) => {
        const fallback = INITIAL_EMPLOYEES[i] || INITIAL_EMPLOYEES[0];
        const dailyWage = emp.dailyWage || fallback.dailyWage || Math.round((emp.basicSalary || 35000) / 26);
        const regularShiftHours = emp.regularShiftHours || 8.0;
        const regularHourlyRate = emp.regularHourlyRate || Math.round(dailyWage / regularShiftHours);
        const overtimeHourlyRate = emp.overtimeHourlyRate || Math.round(regularHourlyRate * 1.5);
        return {
          ...emp,
          dailyWage,
          regularShiftHours,
          regularHourlyRate,
          overtimeHourlyRate,
          currentLocation: emp.currentLocation || fallback.currentLocation,
        };
      });
    }
  } catch (e) {
    console.error('Failed to load employees from localStorage', e);
  }
  return INITIAL_EMPLOYEES;
}

export function saveStoredEmployees(employees: Employee[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.EMPLOYEES, JSON.stringify(employees));
  } catch (e) {
    console.error('Failed to save employees to localStorage', e);
  }
}

export function loadStoredAttendance(): AttendanceRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load attendance from localStorage', e);
  }
  return INITIAL_ATTENDANCE;
}

export function saveStoredAttendance(records: AttendanceRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(records));
  } catch (e) {
    console.error('Failed to save attendance to localStorage', e);
  }
}

export function loadStoredLeaves(): LeaveRequest[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LEAVES);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load leaves from localStorage', e);
  }
  return INITIAL_LEAVES;
}

export function saveStoredLeaves(leaves: LeaveRequest[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.LEAVES, JSON.stringify(leaves));
  } catch (e) {
    console.error('Failed to save leaves to localStorage', e);
  }
}

export function loadStoredManagerPin(): string {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.MANAGER_PIN);
    if (raw) return raw;
  } catch (e) {
    console.error('Failed to load manager pin', e);
  }
  return DEFAULT_MANAGER_PIN;
}

export function saveStoredManagerPin(pin: string): void {
  try {
    localStorage.setItem(STORAGE_KEYS.MANAGER_PIN, pin);
  } catch (e) {
    console.error('Failed to save manager pin', e);
  }
}

export function resetToDemoData(): {
  sites: ElectricalSite[];
  employees: Employee[];
  attendance: AttendanceRecord[];
  leaves: LeaveRequest[];
  settings: CompanySettings;
} {
  localStorage.removeItem(STORAGE_KEYS.SITES);
  localStorage.removeItem(STORAGE_KEYS.EMPLOYEES);
  localStorage.removeItem(STORAGE_KEYS.ATTENDANCE);
  localStorage.removeItem(STORAGE_KEYS.LEAVES);
  localStorage.removeItem(STORAGE_KEYS.SETTINGS);
  return {
    sites: INITIAL_SITES,
    employees: INITIAL_EMPLOYEES,
    attendance: INITIAL_ATTENDANCE,
    leaves: INITIAL_LEAVES,
    settings: DEFAULT_COMPANY_SETTINGS,
  };
}
