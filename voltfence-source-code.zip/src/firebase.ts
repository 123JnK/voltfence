import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  doc,
  getDocFromServer,
  onSnapshot,
  setDoc,
  deleteDoc,
  collection,
  getDocs,
  writeBatch,
  enableIndexedDbPersistence,
} from 'firebase/firestore';
import { getAuth, signInAnonymously } from 'firebase/auth';
import firebaseConfig from '../firebase-applet-config.json';
import type {
  CompanySettings,
  ElectricalSite,
  Employee,
  AttendanceRecord,
  LeaveRequest,
} from './types';

// Initialize Firebase App
export const app = getApps().length > 0 ? getApp() : initializeApp({
  apiKey: firebaseConfig.apiKey,
  authDomain: firebaseConfig.authDomain,
  projectId: firebaseConfig.projectId,
  storageBucket: firebaseConfig.storageBucket,
  messagingSenderId: firebaseConfig.messagingSenderId,
  appId: firebaseConfig.appId,
});

// Initialize Cloud Firestore with dedicated databaseId
export const db =
  firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)'
    ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
    : getFirestore(app);

// Initialize Firebase Auth
export const auth = getAuth(app);

// Attempt silent anonymous auth so requests carry an authenticated credential if needed
signInAnonymously(auth).catch(() => {
  // Silent failover to public rules
});

// Validate Connection to Firestore (Per Firebase Integration Skill Directive)
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline or waiting for network connection.');
      return false;
    }
    // Document not existing is completely fine; connection was verified
    return true;
  }
}
testFirestoreConnection();

/* =========================================================================
   REAL-TIME CLOUD DATA SYNC SERVICES
   ========================================================================= */

const SETTINGS_DOC_ID = 'main_company_profile';

/**
 * Subscribe to Company Settings in real-time
 */
export function subscribeCompanySettings(
  onData: (settings: CompanySettings) => void,
  onError?: (err: Error) => void
) {
  const settingsDocRef = doc(db, 'companySettings', SETTINGS_DOC_ID);
  return onSnapshot(
    settingsDocRef,
    (snap) => {
      if (snap.exists()) {
        onData(snap.data() as CompanySettings);
      }
    },
    (err) => {
      console.error('Company settings snapshot error:', err);
      onError?.(err);
    }
  );
}

/**
 * Save Company Settings to Cloud
 */
export async function saveCompanySettingsToFirestore(settings: CompanySettings) {
  try {
    const settingsDocRef = doc(db, 'companySettings', SETTINGS_DOC_ID);
    await setDoc(settingsDocRef, settings, { merge: true });
    return true;
  } catch (err) {
    console.error('Failed to save company settings to Firestore:', err);
    throw err;
  }
}

/**
 * Subscribe to Sites in real-time
 */
export function subscribeSites(
  onData: (sites: ElectricalSite[]) => void,
  onError?: (err: Error) => void
) {
  const sitesColRef = collection(db, 'sites');
  return onSnapshot(
    sitesColRef,
    (snapshot) => {
      const sites: ElectricalSite[] = [];
      snapshot.forEach((d) => {
        sites.push(d.data() as ElectricalSite);
      });
      // Sort alphabetically or by code
      sites.sort((a, b) => a.name.localeCompare(b.name));
      onData(sites);
    },
    (err) => {
      console.error('Sites snapshot error:', err);
      onError?.(err);
    }
  );
}

/**
 * Save a single site to Cloud
 */
export async function saveSiteToFirestore(site: ElectricalSite) {
  try {
    const siteRef = doc(db, 'sites', site.id);
    await setDoc(siteRef, site, { merge: true });
  } catch (err) {
    console.error('Failed to save site to Firestore:', err);
    throw err;
  }
}

/**
 * Delete a site from Cloud
 */
export async function deleteSiteFromFirestore(siteId: string) {
  try {
    const siteRef = doc(db, 'sites', siteId);
    await deleteDoc(siteRef);
  } catch (err) {
    console.error('Failed to delete site from Firestore:', err);
    throw err;
  }
}

/**
 * Subscribe to Employees in real-time
 */
export function subscribeEmployees(
  onData: (employees: Employee[]) => void,
  onError?: (err: Error) => void
) {
  const empColRef = collection(db, 'employees');
  return onSnapshot(
    empColRef,
    (snapshot) => {
      const employees: Employee[] = [];
      snapshot.forEach((d) => {
        employees.push(d.data() as Employee);
      });
      employees.sort((a, b) => a.name.localeCompare(b.name));
      onData(employees);
    },
    (err) => {
      console.error('Employees snapshot error:', err);
      onError?.(err);
    }
  );
}

/**
 * Save a single employee to Cloud
 */
export async function saveEmployeeToFirestore(employee: Employee) {
  try {
    const empRef = doc(db, 'employees', employee.id);
    await setDoc(empRef, employee, { merge: true });
  } catch (err) {
    console.error('Failed to save employee to Firestore:', err);
    throw err;
  }
}

/**
 * Delete an employee from Cloud
 */
export async function deleteEmployeeFromFirestore(employeeId: string) {
  try {
    const empRef = doc(db, 'employees', employeeId);
    await deleteDoc(empRef);
  } catch (err) {
    console.error('Failed to delete employee from Firestore:', err);
    throw err;
  }
}

/**
 * Subscribe to Attendance Records in real-time
 */
export function subscribeAttendance(
  onData: (records: AttendanceRecord[]) => void,
  onError?: (err: Error) => void
) {
  const attColRef = collection(db, 'attendance');
  return onSnapshot(
    attColRef,
    (snapshot) => {
      const records: AttendanceRecord[] = [];
      snapshot.forEach((d) => {
        records.push(d.data() as AttendanceRecord);
      });
      // Sort newest first
      records.sort(
        (a, b) => new Date(b.checkInTime).getTime() - new Date(a.checkInTime).getTime()
      );
      onData(records);
    },
    (err) => {
      console.error('Attendance snapshot error:', err);
      onError?.(err);
    }
  );
}

/**
 * Record or update Attendance in Cloud
 */
export async function saveAttendanceRecordToFirestore(record: AttendanceRecord) {
  try {
    const attRef = doc(db, 'attendance', record.id);
    await setDoc(attRef, record, { merge: true });
  } catch (err) {
    console.error('Failed to save attendance record to Firestore:', err);
    throw err;
  }
}

/**
 * Subscribe to Leave Requests in real-time
 */
export function subscribeLeaveRequests(
  onData: (leaves: LeaveRequest[]) => void,
  onError?: (err: Error) => void
) {
  const leaveColRef = collection(db, 'leaveRequests');
  return onSnapshot(
    leaveColRef,
    (snapshot) => {
      const leaves: LeaveRequest[] = [];
      snapshot.forEach((d) => {
        leaves.push(d.data() as LeaveRequest);
      });
      leaves.sort(
        (a, b) => new Date(b.appliedDate).getTime() - new Date(a.appliedDate).getTime()
      );
      onData(leaves);
    },
    (err) => {
      console.error('Leave requests snapshot error:', err);
      onError?.(err);
    }
  );
}

/**
 * Delete Attendance record from Cloud
 */
export async function deleteAttendanceRecordFromFirestore(recordId: string) {
  try {
    const attRef = doc(db, 'attendance', recordId);
    await deleteDoc(attRef);
  } catch (err) {
    console.error('Failed to delete attendance record from Firestore:', err);
    throw err;
  }
}

/**
 * Save or update Leave Request in Cloud
 */
export async function saveLeaveRequestToFirestore(leave: LeaveRequest) {
  try {
    const leaveRef = doc(db, 'leaveRequests', leave.id);
    await setDoc(leaveRef, leave, { merge: true });
  } catch (err) {
    console.error('Failed to save leave request to Firestore:', err);
    throw err;
  }
}

/**
 * Delete Leave Request from Cloud
 */
export async function deleteLeaveRequestFromFirestore(leaveId: string) {
  try {
    const leaveRef = doc(db, 'leaveRequests', leaveId);
    await deleteDoc(leaveRef);
  } catch (err) {
    console.error('Failed to delete leave request from Firestore:', err);
    throw err;
  }
}

/**
 * Seed initial local workspace to Cloud if Cloud collections are completely empty.
 * This guarantees that when a user activates Firebase, their existing custom projects,
 * employees, and shift configurations become instantly accessible to all clients and phones!
 */
export async function seedCloudWorkspaceIfEmpty(initialData: {
  companySettings: CompanySettings;
  sites: ElectricalSite[];
  employees: Employee[];
  attendanceRecords: AttendanceRecord[];
  leaveRequests: LeaveRequest[];
}): Promise<boolean> {
  try {
    const sitesSnapshot = await getDocs(collection(db, 'sites'));
    if (!sitesSnapshot.empty) {
      // Cloud already has sites, don't overwrite
      return false;
    }

    const batch = writeBatch(db);

    // Save Company Settings
    const settingsRef = doc(db, 'companySettings', SETTINGS_DOC_ID);
    batch.set(settingsRef, initialData.companySettings);

    // Save Sites
    for (const site of initialData.sites) {
      const sRef = doc(db, 'sites', site.id);
      batch.set(sRef, site);
    }

    // Save Employees
    for (const emp of initialData.employees) {
      const eRef = doc(db, 'employees', emp.id);
      batch.set(eRef, emp);
    }

    // Save Attendance (last 20 for initial roster)
    for (const att of initialData.attendanceRecords.slice(0, 20)) {
      const aRef = doc(db, 'attendance', att.id);
      batch.set(aRef, att);
    }

    // Save Leave Requests
    for (const leave of initialData.leaveRequests) {
      const lRef = doc(db, 'leaveRequests', leave.id);
      batch.set(lRef, leave);
    }

    await batch.commit();
    return true;
  } catch (err) {
    console.error('Error during initial cloud workspace seeding:', err);
    return false;
  }
}

/**
 * One-click push entire local workspace to Cloud Firestore
 * Overwrites / synchronizes all records to Cloud
 */
export async function pushFullWorkspaceToCloud(workspace: {
  companySettings: CompanySettings;
  sites: ElectricalSite[];
  employees: Employee[];
  attendanceRecords?: AttendanceRecord[];
  leaveRequests?: LeaveRequest[];
}) {
  const batch = writeBatch(db);

  // Settings
  const settingsRef = doc(db, 'companySettings', SETTINGS_DOC_ID);
  batch.set(settingsRef, workspace.companySettings);

  // Sites
  for (const s of workspace.sites) {
    batch.set(doc(db, 'sites', s.id), s);
  }

  // Employees
  for (const e of workspace.employees) {
    batch.set(doc(db, 'employees', e.id), e);
  }

  // Attendance
  if (workspace.attendanceRecords) {
    for (const a of workspace.attendanceRecords.slice(0, 50)) {
      batch.set(doc(db, 'attendance', a.id), a);
    }
  }

  // Leave
  if (workspace.leaveRequests) {
    for (const l of workspace.leaveRequests) {
      batch.set(doc(db, 'leaveRequests', l.id), l);
    }
  }

  await batch.commit();
}
