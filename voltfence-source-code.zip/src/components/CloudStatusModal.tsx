import React, { useState } from 'react';
import {
  Cloud,
  CheckCircle2,
  RefreshCw,
  UploadCloud,
  DownloadCloud,
  ShieldCheck,
  Smartphone,
  ExternalLink,
  X,
  Server,
  Zap,
} from 'lucide-react';
import { pushFullWorkspaceToCloud } from '../firebase';
import { ElectricalSite, Employee, AttendanceRecord, LeaveRequest, CompanySettings } from '../types';

interface CloudStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
  cloudSyncStatus: 'connected' | 'syncing' | 'offline' | 'error';
  lastSyncTime: Date | null;
  companySettings: CompanySettings;
  sites: ElectricalSite[];
  employees: Employee[];
  attendance: AttendanceRecord[];
  leaves: LeaveRequest[];
  onForceRefresh?: () => void;
}

export function CloudStatusModal({
  isOpen,
  onClose,
  cloudSyncStatus,
  lastSyncTime,
  companySettings,
  sites,
  employees,
  attendance,
  leaves,
  onForceRefresh,
}: CloudStatusModalProps) {
  if (!isOpen) return null;

  const [isPushing, setIsPushing] = useState(false);
  const [pushSuccess, setPushSuccess] = useState<string | null>(null);

  const handlePushAllToCloud = async () => {
    try {
      setIsPushing(true);
      setPushSuccess(null);
      await pushFullWorkspaceToCloud({
        companySettings,
        sites,
        employees,
        attendanceRecords: attendance,
        leaveRequests: leaves,
      });
      setPushSuccess('✓ Successfully pushed all projects, employees, and settings to Firebase Cloud!');
      setTimeout(() => setPushSuccess(null), 5000);
    } catch (err: any) {
      console.error(err);
      alert('Failed to sync to cloud: ' + (err.message || 'Network error'));
    } finally {
      setIsPushing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Cloud className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Firebase Cloud Sync Status
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Live Active
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Google Cloud Firestore Real-time Multi-Device Hub
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-sm">
          {/* Status Banner */}
          <div className="p-4 rounded-xl bg-slate-950 border border-emerald-500/30 flex items-start gap-3">
            <div className="w-3 h-3 rounded-full bg-emerald-400 mt-1 shrink-0 animate-ping" />
            <div className="flex-1">
              <div className="font-semibold text-emerald-400 flex items-center gap-2">
                Cloud Database Connected & Synchronizing
              </div>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Your projects, employees, wages, and shift attendance are synchronized in real-time
                via Google Cloud Firestore. When you or your employees update anything on their phone,
                it reflects on all devices immediately.
              </p>
              {lastSyncTime && (
                <div className="text-[11px] text-slate-400 font-mono mt-2 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  Last live heartbeat: {lastSyncTime.toLocaleTimeString()}
                </div>
              )}
            </div>
          </div>

          {/* Sync Stats Overview */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
              <div className="text-xl font-bold text-cyan-400">{sites.length}</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Projects / Sites</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
              <div className="text-xl font-bold text-emerald-400">{employees.length}</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Technicians</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
              <div className="text-xl font-bold text-amber-400">{attendance.length}</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Shift Logs</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
              <div className="text-xl font-bold text-indigo-400">{leaves.length}</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Leave Requests</div>
            </div>
          </div>

          {/* Cloud Action Buttons */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Cloud Operations
            </h3>

            {pushSuccess && (
              <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{pushSuccess}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={handlePushAllToCloud}
                disabled={isPushing}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-medium text-xs flex items-center justify-center gap-2 shadow-lg transition-all disabled:opacity-50 cursor-pointer"
              >
                <UploadCloud className="w-4 h-4" />
                {isPushing ? 'Pushing to Cloud...' : 'Force Push All to Cloud'}
              </button>

              {onForceRefresh && (
                <button
                  type="button"
                  onClick={onForceRefresh}
                  className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs flex items-center justify-center gap-2 border border-slate-700 transition-all cursor-pointer"
                >
                  <RefreshCw className="w-4 h-4 text-cyan-400" />
                  Fetch Fresh from Cloud
                </button>
              )}
            </div>
          </div>

          {/* Client & Employee Sharing Note */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-2">
            <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              How sharing works with Firebase:
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Because your app is now connected to Google Cloud, you can share the direct website
              link to your client or employees without worrying about data being trapped on a single
              phone. Everyone will automatically see the exact same active projects, employee rosters,
              and live attendance.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Encrypted Firestore Multi-Device Security</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
