import React from 'react';
import { ElectricalSite, Employee, AttendanceRecord } from '../types';
import {
  Layers,
  MapPin,
  Plus,
  Edit2,
  CheckCircle,
  Clock,
  ShieldAlert,
  Users,
  Compass,
  Archive,
  ArrowRight,
  Zap,
} from 'lucide-react';

interface SiteListProps {
  sites: ElectricalSite[];
  employees: Employee[];
  attendanceRecords: AttendanceRecord[];
  onAddSite: () => void;
  onEditSite: (site: ElectricalSite) => void;
  onToggleStatus: (siteId: string, currentStatus: string) => void;
  onSelectSiteOnMap: (siteId: string) => void;
  onSimulateAtSite: (site: ElectricalSite) => void;
  selectedSiteId: string | null;
}

export function SiteList({
  sites,
  employees,
  attendanceRecords,
  onAddSite,
  onEditSite,
  onToggleStatus,
  onSelectSiteOnMap,
  onSimulateAtSite,
  selectedSiteId,
}: SiteListProps) {
  const [filter, setFilter] = React.useState<'all' | 'active' | 'completed'>('active');

  const filteredSites = sites.filter((site) => {
    if (filter === 'active') return site.status === 'active';
    if (filter === 'completed') return site.status === 'completed';
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-amber-400" />
            Electrical Repairs &amp; Maintenance Sites ({sites.length} Total)
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Geofenced work zones automatically adapt as client repair projects start, evolve, and complete.
          </p>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          {/* Status Filter */}
          <div className="bg-slate-950 p-1 rounded-xl border border-slate-800 flex text-xs">
            <button
              onClick={() => setFilter('active')}
              className={`px-3 py-1 rounded-lg font-medium transition ${
                filter === 'active'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Active ({sites.filter((s) => s.status === 'active').length})
            </button>
            <button
              onClick={() => setFilter('completed')}
              className={`px-3 py-1 rounded-lg font-medium transition ${
                filter === 'completed'
                  ? 'bg-slate-700 text-white font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Completed ({sites.filter((s) => s.status === 'completed').length})
            </button>
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1 rounded-lg font-medium transition ${
                filter === 'all'
                  ? 'bg-slate-800 text-slate-200 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All
            </button>
          </div>

          <button
            onClick={onAddSite}
            className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-amber-500/20"
          >
            <Plus className="w-4 h-4" />
            Add Work Site
          </button>
        </div>
      </div>

      {/* Sites Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {filteredSites.map((site) => {
          const isSelected = site.id === selectedSiteId;
          const isCompleted = site.status === 'completed';

          // Currently clocked in
          const onSiteRecords = attendanceRecords.filter(
            (r) => r.siteId === site.id && r.status === 'active_shift'
          );

          return (
            <div
              key={site.id}
              className={`bg-slate-900 border rounded-2xl p-4 transition-all flex flex-col justify-between ${
                isSelected
                  ? 'border-sky-500 ring-2 ring-sky-500/30 shadow-xl bg-slate-900/90'
                  : isCompleted
                  ? 'border-slate-800/80 opacity-75 hover:opacity-100 bg-slate-950/40'
                  : 'border-slate-800 hover:border-slate-700 shadow-md'
              }`}
            >
              <div>
                {/* Header row */}
                <div className="flex items-start justify-between gap-2 pb-2 border-b border-slate-800">
                  <div>
                    <span className="text-[10px] font-mono text-amber-400 font-bold uppercase tracking-wider block">
                      {site.code} • {site.category}
                    </span>
                    <h4 className="text-sm font-bold text-white leading-snug mt-0.5">{site.name}</h4>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      site.status === 'active'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : site.status === 'completed'
                        ? 'bg-slate-800 text-slate-400 border border-slate-700'
                        : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                    }`}
                  >
                    {site.status === 'active' ? '● Active' : site.status === 'completed' ? '✓ Finished' : '⏸ Paused'}
                  </span>
                </div>

                {/* Client & Address */}
                <div className="py-2.5 space-y-1 text-xs">
                  <p className="text-slate-300 font-medium">{site.clientName}</p>
                  <p className="text-slate-400 text-[11px] flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-500 inline flex-shrink-0" />
                    <span className="truncate">{site.address}</span>
                  </p>
                </div>

                {/* Geofence & On-Site Stats */}
                <div className="grid grid-cols-2 gap-2 my-1 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-medium">Geofence Radius:</span>
                    <span className="font-mono font-bold text-amber-400 text-xs">
                      {site.geofenceRadius} meters
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block font-medium">Currently On-Site:</span>
                    <span
                      className={`font-bold flex items-center gap-1.5 text-xs ${
                        onSiteRecords.length > 0 ? 'text-emerald-400' : 'text-slate-500'
                      }`}
                    >
                      {onSiteRecords.length > 0 && (
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      )}
                      {onSiteRecords.length} Electricians
                    </span>
                  </div>
                </div>

                {/* Hazards tags */}
                {site.hazards.length > 0 && (
                  <div className="my-2 flex flex-wrap gap-1">
                    {site.hazards.slice(0, 2).map((hz) => (
                      <span
                        key={hz}
                        className="px-2 py-0.5 rounded text-[10px] bg-amber-500/10 text-amber-300 border border-amber-500/20 font-medium truncate max-w-[200px]"
                      >
                        ⚠️ {hz}
                      </span>
                    ))}
                    {site.hazards.length > 2 && (
                      <span className="text-[10px] text-slate-500 self-center">
                        +{site.hazards.length - 2} more
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Bottom Actions */}
              <div className="pt-3 border-t border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" /> End: {site.targetEndDate}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="w-3 h-3" /> {site.assignedEmployeeIds.length} Assigned
                  </span>
                </div>

                <div className="flex items-center gap-1.5 pt-1">
                  <button
                    onClick={() => onSelectSiteOnMap(site.id)}
                    className="flex-1 py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition flex items-center justify-center gap-1"
                    title="Focus on map"
                  >
                    <MapPin className="w-3 h-3 text-sky-400" />
                    Map
                  </button>

                  <button
                    onClick={() => onSimulateAtSite(site)}
                    className="flex-1 py-1.5 px-2 rounded-lg bg-cyan-950/70 hover:bg-cyan-900/80 border border-cyan-500/30 text-cyan-300 text-xs font-medium transition flex items-center justify-center gap-1"
                    title="Teleport worker GPS here for testing"
                  >
                    <Compass className="w-3 h-3 text-cyan-400" />
                    Teleport GPS
                  </button>

                  <button
                    onClick={() => onEditSite(site)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                    title="Edit site details & geofence"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() =>
                      onToggleStatus(site.id, site.status === 'completed' ? 'active' : 'completed')
                    }
                    className={`p-1.5 rounded-lg transition ${
                      site.status === 'completed'
                        ? 'bg-emerald-950 text-emerald-400 hover:bg-emerald-900'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                    title={
                      site.status === 'completed'
                        ? 'Re-activate project'
                        : 'Mark Project as Completed / Closed'
                    }
                  >
                    <CheckCircle className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
