import React, { useState, useMemo } from 'react';
import {
  FileSpreadsheet,
  Download,
  Calendar,
  X,
  CheckCircle2,
  DollarSign,
  Clock,
  Users,
  ShieldCheck,
  Building,
  Info,
} from 'lucide-react';
import { AttendanceRecord, ElectricalSite, Employee, CompanySettings } from '../types';
import {
  getStandardPayPeriods,
  computePayPeriodPayroll,
  exportAttendancePayrollCSV,
  PayPeriodRange,
} from '../utils/payrollReport';

interface ExportPayrollModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: AttendanceRecord[];
  employees: Employee[];
  sites: ElectricalSite[];
  companySettings: CompanySettings;
}

export function ExportPayrollModal({
  isOpen,
  onClose,
  records,
  employees,
  sites,
  companySettings,
}: ExportPayrollModalProps) {
  if (!isOpen) return null;

  const standardPeriods = useMemo(() => getStandardPayPeriods(), []);

  const [selectedPeriodIndex, setSelectedPeriodIndex] = useState<number>(0);
  const [customStartDate, setCustomStartDate] = useState<string>(standardPeriods[0].startDate);
  const [customEndDate, setCustomEndDate] = useState<string>(standardPeriods[0].endDate);
  const [isCustomRange, setIsCustomRange] = useState<boolean>(false);

  const activePeriod: PayPeriodRange = useMemo(() => {
    if (isCustomRange) {
      return {
        label: 'Custom Pay Period',
        startDate: customStartDate,
        endDate: customEndDate,
      };
    }
    return standardPeriods[selectedPeriodIndex] || standardPeriods[0];
  }, [isCustomRange, customStartDate, customEndDate, selectedPeriodIndex, standardPeriods]);

  // Compute live preview metrics for the selected pay period
  const payrollSummary = useMemo(() => {
    return computePayPeriodPayroll(
      records,
      employees,
      sites,
      companySettings,
      activePeriod.startDate,
      activePeriod.endDate
    );
  }, [records, employees, sites, companySettings, activePeriod]);

  const currency = companySettings.currencySymbol || '₹';

  const handleDownload = () => {
    exportAttendancePayrollCSV({
      records,
      employees,
      sites,
      companySettings,
      payPeriodLabel: activePeriod.label,
      startDate: activePeriod.startDate,
      endDate: activePeriod.endDate,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">
                  Export Attendance &amp; Payroll Report
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase font-bold">
                  CSV Format
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Detailed wage reconciliation, statutory EPF deductions &amp; geofence logs
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300">
          {/* Pay Period Selection */}
          <div className="space-y-3">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5 uppercase tracking-wider">
              <Calendar className="w-4 h-4 text-amber-400" />
              Select Pay Period:
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {standardPeriods.map((period, idx) => {
                const isSelected = !isCustomRange && selectedPeriodIndex === idx;
                return (
                  <button
                    key={period.label}
                    type="button"
                    onClick={() => {
                      setIsCustomRange(false);
                      setSelectedPeriodIndex(idx);
                    }}
                    className={`p-3 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-amber-500/10 border-amber-500/60 text-white shadow-sm ring-1 ring-amber-500/30'
                        : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-bold text-xs flex items-center justify-between">
                      <span className={isSelected ? 'text-amber-400' : 'text-slate-200'}>
                        {period.label}
                      </span>
                      {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 mt-1">
                      {period.startDate} → {period.endDate}
                    </div>
                  </button>
                );
              })}

              {/* Custom Date Range Option */}
              <button
                type="button"
                onClick={() => setIsCustomRange(true)}
                className={`p-3 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                  isCustomRange
                    ? 'bg-amber-500/10 border-amber-500/60 text-white shadow-sm ring-1 ring-amber-500/30'
                    : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <div className="font-bold text-xs flex items-center justify-between">
                  <span className={isCustomRange ? 'text-amber-400' : 'text-slate-200'}>
                    Custom Date Range
                  </span>
                  {isCustomRange && <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                </div>
                <div className="text-[10px] font-mono text-slate-500 mt-1">
                  Choose specific start &amp; end dates
                </div>
              </button>
            </div>

            {/* Custom Range Inputs */}
            {isCustomRange && (
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-950/80 border border-slate-800 rounded-xl mt-2">
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={customStartDate}
                    onChange={(e) => setCustomStartDate(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    End Date
                  </label>
                  <input
                    type="date"
                    value={customEndDate}
                    onChange={(e) => setCustomEndDate(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Pay Period Live Computation Preview */}
          <div className="space-y-2">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>Pay Period Reconciliation Summary:</span>
              <span className="text-cyan-400 font-mono">
                {activePeriod.startDate} to {activePeriod.endDate}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Total Shift Logs</span>
                <span className="text-base font-bold text-white font-mono mt-0.5 block">
                  {payrollSummary.totalShifts} Shifts
                </span>
                <span className="text-[10px] text-slate-500">
                  Across {payrollSummary.employeeSummaries.filter(e => e.shiftsCount > 0).length} Techs
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Working Hours</span>
                <span className="text-base font-bold text-amber-400 font-mono mt-0.5 block">
                  {payrollSummary.totalHours} hrs
                </span>
                <span className="text-[10px] text-slate-500">
                  Reg: {payrollSummary.totalRegularHours}h • OT: {payrollSummary.totalOvertimeHours}h
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Gross Wages</span>
                <span className="text-base font-bold text-cyan-400 font-mono mt-0.5 block">
                  {currency}{payrollSummary.totalGrossPay.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-500">Earned in period</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">EPF Deductions</span>
                <span className="text-base font-bold text-rose-400 font-mono mt-0.5 block">
                  -{currency}{payrollSummary.totalEpfDeductions.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-500">Employee Share</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-emerald-500/30 sm:col-span-2">
                <span className="text-[10px] text-emerald-400 font-semibold block">
                  Net Payout to Technicians
                </span>
                <span className="text-lg font-black text-emerald-300 font-mono mt-0.5 block">
                  {currency}{payrollSummary.totalNetPay.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-400">
                  Bank transfer / disbursement net total
                </span>
              </div>
            </div>
          </div>

          {/* CSV File Structure Notice */}
          <div className="p-3.5 bg-slate-950 border border-slate-800/80 rounded-xl space-y-1.5 text-[11px] text-slate-400">
            <div className="font-semibold text-slate-200 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              What this CSV report contains:
            </div>
            <ul className="list-disc pl-4 space-y-1 text-slate-400">
              <li>
                <strong className="text-slate-300">Detailed Shift Logs:</strong> Date, technician name, site, check-in/out timestamps, regular &amp; overtime hours, wage rates, shift pay, and geofence verification audit.
              </li>
              <li>
                <strong className="text-slate-300">Technician Payroll Summary:</strong> Aggregated hours, regular pay, overtime pay, hazard allowance, EPF contributions, UAN numbers, and net disbursement amounts.
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer transition"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleDownload}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-emerald-600/25 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download Full Payroll CSV</span>
          </button>
        </div>
      </div>
    </div>
  );
}
