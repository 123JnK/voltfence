import React, { useState } from 'react';
import { CompanySettings, Employee } from '../types';
import { GOOGLE_APPS_SCRIPT_TEMPLATE } from '../utils/googleSheets';
import { getPublicBaseUrl } from '../utils/workspaceSync';
import {
  X,
  Settings,
  ShieldCheck,
  DollarSign,
  Building,
  Check,
  KeyRound,
  FileSpreadsheet,
  Copy,
  ExternalLink,
  Send,
  HelpCircle,
  Share2,
  Users,
  Lock,
  Sparkles,
  Smartphone,
  Plus,
  Trash2,
  MessageSquare,
  RefreshCw,
  HardHat,
} from 'lucide-react';

interface CompanySettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: CompanySettings;
  onSave: (newSettings: CompanySettings) => void;
  managerPin: string;
  onUpdatePin: (newPin: string) => void;
  employees?: Employee[];
  initialTab?: 'passkeys' | 'company' | 'sheets' | 'epf';
}

const CURRENCY_PRESETS = [
  { symbol: '₹', code: 'INR', label: 'Indian Rupee (₹ INR)' },
  { symbol: '$', code: 'USD', label: 'US Dollar ($ USD)' },
  { symbol: '€', code: 'EUR', label: 'Euro (€ EUR)' },
  { symbol: '£', code: 'GBP', label: 'British Pound (£ GBP)' },
  { symbol: 'AED', code: 'AED', label: 'UAE Dirham (AED)' },
];

export function CompanySettingsModal({
  isOpen,
  onClose,
  settings,
  onSave,
  managerPin,
  onUpdatePin,
  employees = [],
  initialTab = 'passkeys',
}: CompanySettingsModalProps) {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'passkeys' | 'company' | 'sheets' | 'epf'>(initialTab);

  // General Settings
  const [companyName, setCompanyName] = useState(settings.companyName || 'VoltFence Electrical Contractors');
  const [currencySymbol, setCurrencySymbol] = useState(settings.currencySymbol || '₹');
  const [currencyCode, setCurrencyCode] = useState(settings.currencyCode || 'INR');
  const [defaultEpfRate, setDefaultEpfRate] = useState(settings.defaultEpfRate || 12);
  const [employerEpfRate, setEmployerEpfRate] = useState(settings.defaultEmployerEpfRate || 3.67);
  const [employerEpsRate, setEmployerEpsRate] = useState(settings.defaultEmployerEpsRate || 8.33);
  const [pin, setPin] = useState(managerPin);

  // Client Passkey & Authorized Emails State
  const [clientPasskey, setClientPasskey] = useState(
    settings.clientPasskey || 'VOLT-CLIENT-2026'
  );
  const [authorizedEmails, setAuthorizedEmails] = useState<string[]>(
    settings.authorizedEmails && settings.authorizedEmails.length > 0
      ? settings.authorizedEmails
      : ['client@voltfence.in', 'sitelead@electrical.com']
  );
  const [newEmailInput, setNewEmailInput] = useState('');
  const [allowPasskeyDirectAccess, setAllowPasskeyDirectAccess] = useState(
    settings.allowPasskeyDirectAccess !== undefined ? settings.allowPasskeyDirectAccess : true
  );

  const [copiedMagicLink, setCopiedMagicLink] = useState(false);
  const [copiedPasskey, setCopiedPasskey] = useState(false);
  const [copiedWhatsappText, setCopiedWhatsappText] = useState(false);
  const [selectedTechForLink, setSelectedTechForLink] = useState(employees[0]?.id || '');
  const [copiedTechLink, setCopiedTechLink] = useState(false);

  // Google Sheets integration state
  const [googleSheetWebhookUrl, setGoogleSheetWebhookUrl] = useState(
    settings.googleSheetWebhookUrl || ''
  );
  const [googleSheetAutoSync, setGoogleSheetAutoSync] = useState(
    settings.googleSheetAutoSync !== undefined ? settings.googleSheetAutoSync : true
  );

  const [copiedScript, setCopiedScript] = useState(false);
  const [testingSheet, setTestingSheet] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [showInstructions, setShowInstructions] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const baseUrl = getPublicBaseUrl();
  const clientMagicLink = `${baseUrl}?passkey=${encodeURIComponent(clientPasskey.trim() || 'VOLT-CLIENT-2026')}`;

  const selectedTech = employees.find((e) => e.id === selectedTechForLink) || employees[0];
  const techMagicLink = selectedTech
    ? `${baseUrl}?emp=${encodeURIComponent(selectedTech.id)}&pin=${encodeURIComponent(selectedTech.pin || '1234')}`
    : '';

  const handleCopyMagicLink = () => {
    navigator.clipboard.writeText(clientMagicLink);
    setCopiedMagicLink(true);
    setTimeout(() => setCopiedMagicLink(false), 3000);
  };

  const handleCopyPasskey = () => {
    navigator.clipboard.writeText(clientPasskey);
    setCopiedPasskey(true);
    setTimeout(() => setCopiedPasskey(false), 3000);
  };

  const handleCopyWhatsapp = () => {
    const text = `⚡ *${companyName}* - Live Project & Attendance Portal Access\n\nHello! Here is your instant access to our real-time project portal:\n\n🔗 *Direct Access Link:* ${clientMagicLink}\n🔑 *Client Passkey:* ${clientPasskey}\n\n*No Google account or app download required!* Simply tap the link in any mobile browser to view live site geofences, technician attendance, and shift compliance.`;
    navigator.clipboard.writeText(text);
    setCopiedWhatsappText(true);
    setTimeout(() => setCopiedWhatsappText(false), 3000);
  };

  const handleCopyTechLink = () => {
    if (!techMagicLink) return;
    navigator.clipboard.writeText(techMagicLink);
    setCopiedTechLink(true);
    setTimeout(() => setCopiedTechLink(false), 3000);
  };

  const handleGenerateRandomPasskey = () => {
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const prefix = companyName.split(' ')[0].toUpperCase().replace(/[^A-Z]/g, '') || 'VOLT';
    setClientPasskey(`${prefix}-CLIENT-${randomNum}`);
  };

  const handleAddEmail = () => {
    const clean = newEmailInput.trim().toLowerCase();
    if (!clean) return;
    if (!clean.includes('@')) {
      alert('Please enter a valid email address (e.g. client@gmail.com)');
      return;
    }
    if (!authorizedEmails.includes(clean)) {
      setAuthorizedEmails([...authorizedEmails, clean]);
    }
    setNewEmailInput('');
  };

  const handleRemoveEmail = (emailToRemove: string) => {
    setAuthorizedEmails(authorizedEmails.filter((e) => e !== emailToRemove));
  };

  const handleCopyScript = () => {
    navigator.clipboard.writeText(GOOGLE_APPS_SCRIPT_TEMPLATE);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 3000);
  };

  const handleTestPing = async () => {
    if (!googleSheetWebhookUrl || !googleSheetWebhookUrl.startsWith('http')) {
      setTestResult('Please enter a valid Google Web App URL first.');
      return;
    }

    setTestingSheet(true);
    setTestResult(null);

    try {
      await fetch(googleSheetWebhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8',
        },
        body: JSON.stringify({
          employeeId: 'TEST-001',
          employeeName: 'VoltFence Connection Test',
          siteId: 'SITE-TEST',
          siteName: 'Google Sheet Ping Test',
          date: new Date().toISOString().split('T')[0],
          checkInTime: new Date().toISOString(),
          checkInDistanceMeters: 0,
          geofenceVerified: true,
          status: 'verified_test',
          ppeConfirmed: true,
          taskDescription: 'Connection ping test from VoltFence App',
          checkInCoords: { lat: 28.5355, lng: 77.3910 },
          deviceNotes: 'Test Ping',
        }),
      });

      setTestResult('✅ Success! Test row sent to your Google Sheet.');
    } catch {
      setTestResult('✅ Request sent to Google Sheet (check your sheet for the test row).');
    } finally {
      setTestingSheet(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const cleanEmails = authorizedEmails
      .map((e) => e.trim().toLowerCase())
      .filter((e) => e.length > 0 && e.includes('@'));

    const updatedSettings: CompanySettings = {
      companyName: companyName.trim() || 'VoltFence Electrical Contractors',
      currencySymbol,
      currencyCode,
      defaultEpfRate: Number(defaultEpfRate) || 12,
      defaultEmployerEpfRate: Number(employerEpfRate) || 3.67,
      defaultEmployerEpsRate: Number(employerEpsRate) || 8.33,
      googleSheetWebhookUrl: googleSheetWebhookUrl.trim(),
      googleSheetAutoSync,
      clientPasskey: clientPasskey.trim() || 'VOLT-CLIENT-2026',
      authorizedEmails: cleanEmails.length > 0 ? cleanEmails : ['client@voltfence.in'],
      allowPasskeyDirectAccess,
    };

    onSave(updatedSettings);

    if (pin.trim() && pin.length >= 4) {
      onUpdatePin(pin.trim());
    }

    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full shadow-2xl text-slate-100 max-h-[94vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-5 sm:px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/90">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Client Access &amp; App Settings</h3>
              <p className="text-xs text-slate-400">
                Manage Client Passkeys, whitelisted Gmails, instant links &amp; statutory rates
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-4 p-1.5 bg-slate-950 border-b border-slate-800 gap-1 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('passkeys')}
            className={`py-2 px-2 rounded-xl font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'passkeys'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span className="truncate">Client Passkeys</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('company')}
            className={`py-2 px-2 rounded-xl font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'company'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Building className="w-3.5 h-3.5" />
            <span className="truncate">Company &amp; ₹</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('sheets')}
            className={`py-2 px-2 rounded-xl font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'sheets'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span className="truncate">Google Sheets</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('epf')}
            className={`py-2 px-2 rounded-xl font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'epf'
                ? 'bg-indigo-500 text-white shadow-md shadow-indigo-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span className="truncate">EPF &amp; PIN</span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 text-xs overflow-y-auto flex-1">
          {savedSuccess && (
            <div className="p-3.5 rounded-2xl bg-emerald-950/90 border border-emerald-500/40 text-emerald-300 font-semibold flex items-center gap-2.5 shadow-lg">
              <Check className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>Settings and client passkeys saved successfully to Firebase Cloud!</span>
            </div>
          )}

          {/* TAB 1: CLIENT PASSKEYS & AUTHORIZED GMAILS (The User's Core Request) */}
          {activeTab === 'passkeys' && (
            <div className="space-y-4">
              {/* Highlight Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/60 to-cyan-950/60 border border-emerald-500/40 space-y-2">
                <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span>Instant Client Access (Zero Google Sign-In Required)</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Your clients and their employees don&apos;t need to log in with a Google account or encounter 403 blocks. 
                  Share the <strong>Client Passkey</strong> or send the <strong>1-Click Instant Link</strong> below. They enter directly into the dedicated Client Portal!
                </p>
              </div>

              {/* Client Passkey Input */}
              <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-slate-200 font-bold flex items-center gap-2">
                    <KeyRound className="w-4 h-4 text-emerald-400" />
                    <span>Client Master Passkey</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleGenerateRandomPasskey}
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-semibold cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Generate New Passkey</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    required
                    value={clientPasskey}
                    onChange={(e) => setClientPasskey(e.target.value.toUpperCase())}
                    placeholder="e.g. VOLT-CLIENT-2026"
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-mono font-bold tracking-wider text-sm focus:outline-hidden focus:border-emerald-400"
                  />
                  <button
                    type="button"
                    onClick={handleCopyPasskey}
                    className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center gap-1.5 border border-slate-700 transition cursor-pointer"
                    title="Copy Passkey"
                  >
                    {copiedPasskey ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-400" />}
                    <span>{copiedPasskey ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-400">
                  Clients enter this passkey in the &quot;Client / Stakeholder&quot; tab on the sign-in screen to view live project sites, attendance records, and export reports.
                </p>
              </div>

              {/* 1-Click Instant Magic Link & WhatsApp Sharing */}
              <div className="p-4 rounded-2xl bg-slate-950/90 border border-emerald-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-400 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                    <ExternalLink className="w-3.5 h-3.5" />
                    1-Click Direct Client Magic Link
                  </span>
                  <span className="text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                    Auto-Authenticates
                  </span>
                </div>

                <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between gap-2">
                  <span className="font-mono text-[11px] text-slate-300 truncate">
                    {clientMagicLink}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyMagicLink}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shrink-0 transition cursor-pointer shadow-sm"
                  >
                    {copiedMagicLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedMagicLink ? 'Link Copied!' : 'Copy Link'}</span>
                  </button>
                </div>

                {/* WhatsApp & Email message generator */}
                <button
                  type="button"
                  onClick={handleCopyWhatsapp}
                  className="w-full py-2.5 px-3 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-300 border border-emerald-500/40 font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-sm"
                >
                  <MessageSquare className="w-4 h-4 text-emerald-400" />
                  <span>
                    {copiedWhatsappText
                      ? '✓ WhatsApp Invitation Copied to Clipboard!'
                      : 'Copy WhatsApp / Email Invitation Message'}
                  </span>
                </button>
              </div>

              {/* Authorized Client & Employee Gmails / Whitelist */}
              <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-slate-200 font-bold flex items-center gap-2">
                    <Users className="w-4 h-4 text-cyan-400" />
                    <span>Authorized Client / Supervisor Gmails &amp; Emails</span>
                  </label>
                  <span className="text-[11px] text-slate-400">
                    {authorizedEmails.length} email{authorizedEmails.length !== 1 ? 's' : ''} allowed
                  </span>
                </div>

                <p className="text-[11px] text-slate-400">
                  Add specific client emails or Gmails. Anyone with an authorized email can simply type their email on the login screen to gain instant client access:
                </p>

                {/* Add Email input */}
                <div className="flex items-center gap-2">
                  <input
                    type="email"
                    value={newEmailInput}
                    onChange={(e) => setNewEmailInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddEmail();
                      }
                    }}
                    placeholder="e.g. client.superintendent@gmail.com"
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-white text-xs focus:outline-hidden focus:border-cyan-400"
                  />
                  <button
                    type="button"
                    onClick={handleAddEmail}
                    className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1 transition cursor-pointer shadow-sm"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Email</span>
                  </button>
                </div>

                {/* Email Tag List */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {authorizedEmails.map((email) => (
                    <div
                      key={email}
                      className="flex items-center gap-1.5 bg-slate-900 border border-slate-700 px-2.5 py-1 rounded-lg text-[11px] text-slate-200 font-mono"
                    >
                      <span>{email}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveEmail(email)}
                        className="text-slate-400 hover:text-rose-400 transition cursor-pointer p-0.5"
                        title="Remove email"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                  {authorizedEmails.length === 0 && (
                    <p className="text-[11px] text-amber-400/80 italic">
                      No emails whitelisted yet. Clients can still use the Master Passkey above.
                    </p>
                  )}
                </div>
              </div>

              {/* Technician Magic Link Generator */}
              {employees.length > 0 && (
                <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-cyan-400 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                      <HardHat className="w-3.5 h-3.5" />
                      Field Technician Instant Magic Link
                    </span>
                    <span className="text-[10px] text-slate-400">PIN Pre-Filled</span>
                  </div>

                  <p className="text-[11px] text-slate-400">
                    Send a direct link to any technician so their mobile browser opens straight into their field clock-in portal:
                  </p>

                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                    <select
                      value={selectedTechForLink}
                      onChange={(e) => setSelectedTechForLink(e.target.value)}
                      className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs font-semibold focus:outline-hidden focus:border-cyan-400 cursor-pointer"
                    >
                      {employees.map((emp) => (
                        <option key={emp.id} value={emp.id}>
                          {emp.name} ({emp.code}) — PIN: {emp.pin || '1234'}
                        </option>
                      ))}
                    </select>

                    <button
                      type="button"
                      onClick={handleCopyTechLink}
                      className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition cursor-pointer"
                    >
                      {copiedTechLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedTechLink ? 'Worker Link Copied!' : 'Copy Worker Link'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Allow direct passkey access toggle */}
              <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-950/60 border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={allowPasskeyDirectAccess}
                  onChange={(e) => setAllowPasskeyDirectAccess(e.target.checked)}
                  className="accent-emerald-500 rounded w-4 h-4"
                />
                <div className="text-[11px]">
                  <span className="font-bold text-white block">Enable Instant Direct Access Via Passkey</span>
                  <span className="text-slate-400">Allows clients and team members with the passkey to enter without managerial authorization prompts.</span>
                </div>
              </label>
            </div>
          )}

          {/* TAB 2: COMPANY & CURRENCY */}
          {activeTab === 'company' && (
            <div className="space-y-4">
              {/* Company Name */}
              <div className="space-y-1.5">
                <label className="text-slate-300 font-medium flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-amber-400" />
                  Client / Electrical Contractor Business Name
                </label>
                <input
                  type="text"
                  required
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="e.g. Apex Electrical & Substation Engineering Ltd"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white font-medium focus:outline-hidden focus:border-amber-400 text-xs"
                />
              </div>

              {/* Currency Selection */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2.5">
                <label className="text-slate-200 font-bold block uppercase tracking-wider text-[11px] flex items-center gap-1.5 text-emerald-400">
                  <DollarSign className="w-3.5 h-3.5" />
                  Currency Configuration
                </label>
                <p className="text-[11px] text-slate-400">
                  Select the currency symbol used across attendance, wage registers, and payslips:
                </p>

                <div className="grid grid-cols-2 gap-2">
                  {CURRENCY_PRESETS.map((cp) => (
                    <button
                      key={cp.code}
                      type="button"
                      onClick={() => {
                        setCurrencySymbol(cp.symbol);
                        setCurrencyCode(cp.code);
                      }}
                      className={`p-2.5 rounded-xl text-left border text-xs font-semibold transition flex items-center justify-between cursor-pointer ${
                        currencySymbol === cp.symbol
                          ? 'bg-emerald-950/60 border-emerald-500/60 text-emerald-300 shadow-sm'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span>{cp.label}</span>
                      {currencySymbol === cp.symbol && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                    </button>
                  ))}
                </div>

                <div className="flex gap-2 pt-1">
                  <div className="flex-1">
                    <label className="text-slate-400 text-[10px] block mb-1">Custom Symbol</label>
                    <input
                      type="text"
                      value={currencySymbol}
                      onChange={(e) => setCurrencySymbol(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono font-bold text-center text-sm"
                    />
                  </div>
                  <div className="flex-1">
                    <label className="text-slate-400 text-[10px] block mb-1">ISO Code</label>
                    <input
                      type="text"
                      value={currencyCode}
                      onChange={(e) => setCurrencyCode(e.target.value.toUpperCase())}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono font-bold text-center text-sm"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: GOOGLE SHEETS LIVE SYNC */}
          {activeTab === 'sheets' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-950/90 border border-emerald-500/40 space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                  <span className="font-bold text-emerald-400 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                    <FileSpreadsheet className="w-4 h-4" />
                    Google Sheets Live Sync (Zero-Database Backend)
                  </span>
                  <span className="text-[10px] font-mono text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
                    100% Free
                  </span>
                </div>

                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Whenever technicians clock in or out on their phones, the app automatically appends
                  a new row directly into your client&apos;s Google Sheet in real time without needing an external database!
                </p>

                <div className="space-y-1">
                  <label className="text-slate-300 font-medium flex items-center justify-between">
                    <span>Google Apps Script Web App URL:</span>
                    <button
                      type="button"
                      onClick={() => setShowInstructions(!showInstructions)}
                      className="text-cyan-400 hover:underline flex items-center gap-1 text-[11px] cursor-pointer"
                    >
                      <HelpCircle className="w-3 h-3" />
                      {showInstructions ? 'Hide Setup Steps' : 'How to get this URL (30s setup)'}
                    </button>
                  </label>
                  <input
                    type="url"
                    value={googleSheetWebhookUrl}
                    onChange={(e) => setGoogleSheetWebhookUrl(e.target.value)}
                    placeholder="https://script.google.com/macros/s/.../exec"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-hidden focus:border-emerald-400 placeholder-slate-600"
                  />
                </div>

                {/* Step-by-step instructions dropdown */}
                {showInstructions && (
                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-300 space-y-2">
                    <strong className="text-white block">30-Second Google Sheet Setup:</strong>
                    <ol className="list-decimal list-inside space-y-1 text-slate-400">
                      <li>Create a new spreadsheet at <strong>sheets.google.com</strong>.</li>
                      <li>Click <strong>Extensions &gt; Apps Script</strong> in the Google Sheet menu.</li>
                      <li>Delete default code, click the copy button below, and paste it into the editor.</li>
                      <li>Click <strong>Deploy &gt; New deployment</strong>, select <strong>Web app</strong>.</li>
                      <li>Set <em>Execute as:</em> <strong>Me</strong> and <em>Who has access:</em> <strong>Anyone</strong>.</li>
                      <li>Click Deploy and copy the Web App URL into the field above!</li>
                    </ol>

                    <button
                      type="button"
                      onClick={handleCopyScript}
                      className="w-full py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      {copiedScript ? 'Copied Google Apps Script Code!' : 'Copy Ready-to-Paste Apps Script Code'}
                    </button>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 pt-1">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={googleSheetAutoSync}
                      onChange={(e) => setGoogleSheetAutoSync(e.target.checked)}
                      className="accent-emerald-500 rounded"
                    />
                    <span className="font-semibold text-xs">Auto-Sync on Every Check-In</span>
                  </label>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleCopyScript}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1 border border-slate-700 cursor-pointer"
                      title="Copy Google Apps Script template"
                    >
                      <Copy className="w-3 h-3 text-amber-400" />
                      <span>{copiedScript ? 'Copied!' : 'Copy Script'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleTestPing}
                      disabled={testingSheet}
                      className="px-3 py-1.5 rounded-lg bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
                    >
                      <Send className="w-3 h-3" />
                      <span>{testingSheet ? 'Sending...' : 'Test Sync'}</span>
                    </button>
                  </div>
                </div>

                {testResult && (
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-emerald-300">
                    {testResult}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: STATUTORY EPF & MANAGER PIN */}
          {activeTab === 'epf' && (
            <div className="space-y-4">
              {/* Statutory EPF Rates */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2.5">
                <label className="text-slate-200 font-bold block uppercase tracking-wider text-[11px] flex items-center gap-1.5 text-cyan-400">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Statutory EPF (Employee Provident Fund) Percentages
                </label>
                <p className="text-[11px] text-slate-400">
                  India EPFO statutory standard is 12% employee deduction and matching 12% employer
                  contribution (3.67% EPF + 8.33% EPS pension):
                </p>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-slate-400 text-[10px] block mb-1">
                      Employee EPF (%)
                    </label>
                    <input
                      type="number"
                      step="0.5"
                      min="0"
                      max="25"
                      value={defaultEpfRate}
                      onChange={(e) => setDefaultEpfRate(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono font-bold text-center"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 text-[10px] block mb-1">
                      Employer EPF (%)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="15"
                      value={employerEpfRate}
                      onChange={(e) => setEmployerEpfRate(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono font-bold text-center"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 text-[10px] block mb-1">
                      Employer EPS (%)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="15"
                      value={employerEpsRate}
                      onChange={(e) => setEmployerEpsRate(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono font-bold text-center"
                    />
                  </div>
                </div>
              </div>

              {/* Manager Access PIN */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
                <label className="text-slate-200 font-bold block uppercase tracking-wider text-[11px] flex items-center gap-1.5 text-amber-400">
                  <KeyRound className="w-3.5 h-3.5" />
                  Manager Master Access PIN
                </label>
                <p className="text-[11px] text-slate-400">
                  Protects Salaries, EPF wage registers, and site rate configurations from unauthorized view:
                </p>
                <input
                  type="text"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="e.g. 1234"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-white font-mono tracking-widest text-sm focus:outline-hidden focus:border-amber-400"
                />
              </div>
            </div>
          )}

          {/* Footer buttons */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
            <span className="text-[11px] text-slate-500 hidden sm:inline">
              Changes sync live across Firebase Firestore and all connected phones
            </span>
            <div className="flex items-center gap-2 ml-auto">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer transition"
              >
                Close
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold shadow-lg shadow-emerald-500/20 cursor-pointer transition flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Save All Settings &amp; Passkeys</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
