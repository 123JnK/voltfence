import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Download,
  X,
  CheckCircle2,
  ExternalLink,
  Copy,
  Check,
  ShieldCheck,
  Zap,
  QrCode,
  ArrowRight,
  Info,
  Layers,
  Globe,
  UploadCloud,
  AlertTriangle,
  Lock,
  Loader2,
} from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

interface InstallApkModalProps {
  isOpen: boolean;
  onClose: () => void;
  appUrl: string;
}

export function InstallApkModal({ isOpen, onClose, appUrl }: InstallApkModalProps) {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'public_deploy' | 'direct_install' | 'pwa_builder'>('public_deploy');
  const [showManualGuide, setShowManualGuide] = useState(false);

  const isInIframe = typeof window !== 'undefined' && window.self !== window.top;

  useEffect(() => {
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);

    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      try {
        await deferredPrompt.prompt();
        const choice = await deferredPrompt.userChoice;
        if (choice.outcome === 'accepted') {
          setIsInstalled(true);
        }
        setDeferredPrompt(null);
      } catch (err) {
        console.error('Install prompt error:', err);
        setShowManualGuide(true);
      }
    } else {
      setShowManualGuide(true);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const [downloadLoading, setDownloadLoading] = useState<string | null>(null);

  const handleDownloadZipArchive = async (url: string, filename: string) => {
    try {
      setDownloadLoading(filename);
      const res = await fetch(url, { credentials: 'same-origin' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
      setDownloadLoading(null);
    } catch (err) {
      console.warn('Direct fetch failed, falling back to window location:', err);
      window.location.href = url;
      setDownloadLoading(null);
    }
  };

  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(
    appUrl
  )}&bgcolor=0f172a&color=f8fafc&margin=4`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl p-5 sm:p-7 text-slate-100 my-6 max-h-[92vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Globe className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                Serve App to Clients &amp; Employees (Bypass 403)
              </h2>
              <p className="text-xs text-slate-400">
                Fix Cloud Run 403 Forbidden, download standalone web package, or install as mobile APK
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-3 rounded-2xl bg-slate-950 p-1 mb-5 border border-slate-800 gap-1 text-xs">
          <button
            onClick={() => setActiveTab('public_deploy')}
            className={`py-2 px-2 font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'public_deploy'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span className="truncate">Public Hosting (Fix 403)</span>
          </button>

          <button
            onClick={() => setActiveTab('direct_install')}
            className={`py-2 px-2 font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'direct_install'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="truncate">Phone Install (WebAPK)</span>
          </button>

          <button
            onClick={() => setActiveTab('pwa_builder')}
            className={`py-2 px-2 font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'pwa_builder'
                ? 'bg-blue-500 text-white shadow-md shadow-blue-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span className="truncate">Android .APK File</span>
          </button>
        </div>

        {/* TAB 1: PUBLIC DEPLOY / 403 FIX (The Core Solution!) */}
        {activeTab === 'public_deploy' && (
          <div className="space-y-4">
            {/* Why 403 Happens Box */}
            <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-xs text-amber-200 space-y-2">
              <div className="font-bold text-amber-300 flex items-center gap-2 text-sm">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Why Does Cloud Run Show 403 Forbidden To Your Client?</span>
              </div>
              <p className="leading-relaxed text-slate-300 text-[11px]">
                The URL ending in <code className="text-amber-300 font-mono">.run.app</code> is a private Google Cloud development container. Google Cloud blocks anyone whose Google account has not been explicitly granted IAM permission.
              </p>
              <div className="pt-1 text-slate-300 text-[11px]">
                <strong className="text-white">Here are the two working ways to serve this to your client:</strong>
              </div>
            </div>

            {/* Solution A: 1-Click Netlify / Vercel Deploy (Zero 403, 100% Free) */}
            <div className="p-5 rounded-2xl bg-slate-950/90 border border-emerald-500/40 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <span className="font-bold text-emerald-400 text-xs flex items-center gap-2 uppercase tracking-wider">
                  <Zap className="w-4 h-4 text-emerald-400" />
                  Solution 1: Download Pre-Built Web App (.ZIP) &amp; Host in 30 Seconds
                </span>
                <span className="text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                  100% Free &bull; Works On All Phones
                </span>
              </div>

              <p className="text-[11px] text-slate-300 leading-relaxed">
                The entire app has been compiled into a standalone, production-ready package. It connects directly to your live <strong>Google Cloud Firestore</strong> database. Anyone in the world can open it without any Google account!
              </p>

              {/* Download ZIP Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  onClick={() => handleDownloadZipArchive('/voltfence-source-code.zip', 'voltfence-source-code.zip')}
                  disabled={downloadLoading !== null}
                  className="py-3 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-2 cursor-pointer text-center disabled:opacity-50"
                >
                  {downloadLoading === 'voltfence-source-code.zip' ? (
                    <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                  ) : (
                    <Download className="w-4 h-4 shrink-0" />
                  )}
                  <span>Source Code ZIP (~260 KB)</span>
                </button>

                <button
                  onClick={() => handleDownloadZipArchive('/voltfence-production.zip', 'voltfence-production.zip')}
                  disabled={downloadLoading !== null}
                  className="py-3 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow-lg shadow-emerald-600/20 transition flex items-center justify-center gap-2 cursor-pointer text-center disabled:opacity-50"
                >
                  {downloadLoading === 'voltfence-production.zip' ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <Download className="w-4 h-4 shrink-0" />
                  )}
                  <span>Production Web App (~578 KB)</span>
                </button>
              </div>

              <div className="flex justify-end">
                <a
                  href="https://app.netlify.com/drop"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 text-xs font-bold rounded-xl transition inline-flex items-center gap-1.5 cursor-pointer ml-auto"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Open Free Host (app.netlify.com/drop)</span>
                </a>
              </div>

              {/* 3 Step Netlify Instructions */}
              <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl space-y-2 text-[11px] text-slate-300">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>3 Steps to Get Your Public Link (No Sign-Up or Credit Card Required):</span>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-slate-400 pl-1">
                  <li>Click <strong>&quot;Download voltfence-production.zip&quot;</strong> above and unzip it to a folder.</li>
                  <li>Go to <strong>app.netlify.com/drop</strong> in your browser.</li>
                  <li>Drag &amp; drop the unzipped folder onto the Netlify drop box.</li>
                </ol>
                <p className="text-emerald-300 font-medium pt-1">
                  &bull; Netlify instantly gives you a permanent public URL (e.g. <span className="font-mono underline">https://your-company.netlify.app</span>) that opens on every client and technician&apos;s phone with ZERO 403 error!
                </p>
              </div>
            </div>

            {/* Solution B: AI Studio Share Button */}
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
              <span className="font-bold text-cyan-400 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" />
                Solution 2: Invite Your Client&apos;s Gmail in Google AI Studio
              </span>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                If you prefer to keep using the Google Cloud Run link:
              </p>
              <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px] pl-1">
                <li>Look at the top-right corner of Google AI Studio (in this browser window).</li>
                <li>Click the <strong>&quot;Share&quot;</strong> button next to the app title.</li>
                <li>Enter your <strong>client&apos;s Gmail address</strong> and click <strong>Add / Invite</strong>.</li>
                <li>Once added, Google Cloud will allow their Gmail past the 403 firewall!</li>
              </ol>
            </div>
          </div>
        )}

        {/* TAB 2: Direct Install */}
        {activeTab === 'direct_install' && (
          <div className="space-y-4">
            {isInIframe && (
              <div className="p-3 bg-blue-950/40 border border-blue-500/30 rounded-xl text-xs text-blue-200 flex items-start gap-2.5">
                <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-white">Preview Mode Notice: </span>
                  Browsers do not allow app installation inside an embedded preview box. Open the app in its own browser tab or scan the QR code with your phone below to install!
                </div>
              </div>
            )}

            {/* Quick Action Box */}
            <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-3">
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="p-2 bg-slate-950 rounded-xl border border-slate-700 shrink-0 text-center">
                  <img
                    src={qrCodeUrl}
                    alt="Scan to open on phone"
                    className="w-28 h-28 rounded-lg mx-auto"
                  />
                  <span className="text-[10px] text-slate-400 font-medium block mt-1">Scan with Phone Camera</span>
                </div>

                <div className="space-y-2 flex-1 text-center sm:text-left">
                  <div className="flex items-center gap-1.5 justify-center sm:justify-start">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Live &amp; Verified</span>
                  </div>
                  <h4 className="text-sm font-semibold text-white">Open Directly on Mobile Phone</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Once opened in Chrome on Android, tap <strong>Install App</strong> or <strong>Add to Home Screen</strong>. Android creates an official standalone app on the technician&apos;s home screen.
                  </p>

                  <div className="flex flex-wrap gap-2 pt-1 justify-center sm:justify-start">
                    <a
                      href={appUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow transition cursor-pointer"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Open in Full Window
                    </a>

                    <button
                      onClick={handleCopyLink}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold rounded-lg transition cursor-pointer"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      {copied ? 'Copied Link!' : 'Copy Link'}
                    </button>
                  </div>
                </div>
              </div>

              {deferredPrompt && (
                <div className="pt-3 border-t border-slate-700/50">
                  <button
                    onClick={handleInstallClick}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm rounded-xl shadow-lg transition cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    {isInstalled ? 'App Already Installed' : 'Install App to Phone Home Screen Now'}
                  </button>
                </div>
              )}
            </div>

            {/* Step-by-Step Mobile Instructions */}
            <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 text-xs text-slate-300 space-y-3">
              <div className="font-semibold text-amber-400 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4" /> 3 Steps to Install on Android / iPhone:
                </span>
                <button
                  onClick={() => setShowManualGuide(!showManualGuide)}
                  className="text-[11px] text-slate-400 hover:text-white underline cursor-pointer"
                >
                  {showManualGuide ? 'Hide details' : 'Show details'}
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 space-y-1.5">
                  <div className="font-bold text-emerald-400 flex items-center gap-1">
                    <span>Android (Google Chrome)</span>
                  </div>
                  <p className="text-slate-400">1. Open the copied link in Chrome.</p>
                  <p className="text-slate-400">2. Tap the <strong>3 dots (&vellip;)</strong> at the top right.</p>
                  <p className="text-slate-400">3. Tap <strong>&quot;Install app&quot;</strong> or <strong>&quot;Add to Home screen&quot;</strong>.</p>
                  <p className="text-emerald-300 font-medium">&check; App appears on home screen with custom icon!</p>
                </div>

                <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 space-y-1.5">
                  <div className="font-bold text-blue-400 flex items-center gap-1">
                    <span>iPhone (Apple Safari)</span>
                  </div>
                  <p className="text-slate-400">1. Open the link in Safari.</p>
                  <p className="text-slate-400">2. Tap the <strong>Share button</strong> (box with arrow).</p>
                  <p className="text-slate-400">3. Scroll down and tap <strong>&quot;Add to Home Screen&quot;</strong>.</p>
                  <p className="text-blue-300 font-medium">&check; Launches full-screen like an iOS app!</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: Standalone .APK File (PWABuilder) */}
        {activeTab === 'pwa_builder' && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-3">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-blue-500/10 text-blue-400 rounded-lg shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">Generate Signed .APK File via PWABuilder</h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    PWABuilder is the official developer tool backed by Microsoft and Google to package progressive web apps into signed Android <strong className="text-slate-200">.apk</strong> and <strong className="text-slate-200">.aab</strong> files for installation or Google Play publishing.
                  </p>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] text-slate-400 font-semibold">Your Live App URL to Paste:</label>
                <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-700 flex items-center justify-between text-xs">
                  <span className="text-slate-300 truncate max-w-[340px] font-mono select-all">{appUrl}</span>
                  <button
                    onClick={handleCopyLink}
                    className="text-amber-400 hover:text-amber-300 font-semibold shrink-0 ml-2 flex items-center gap-1 cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? 'Copied!' : 'Copy'}
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <a
                  href="https://www.pwabuilder.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold rounded-xl shadow-lg shadow-blue-900/30 transition-all cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4" />
                  Open PWABuilder.com
                </a>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-800/30 border border-slate-800 text-xs text-slate-300 space-y-2">
              <div className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-amber-400" /> 3 Steps on PWABuilder:
              </div>
              <ol className="list-decimal list-inside space-y-1 text-slate-400 pl-1 text-[11px]">
                <li>Paste the copied URL into the box on <strong>pwabuilder.com</strong> and click <strong>Start</strong>.</li>
                <li>Review the verified manifest &amp; icons score, then click <strong>&quot;Package for Stores&quot;</strong> &rarr; select <strong>&quot;Android&quot;</strong>.</li>
                <li>Click <strong>&quot;Generate&quot;</strong> to download your signed <strong>.apk</strong> package file!</li>
              </ol>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span>VoltFence Enterprise &bull; Real-Time Cloud Synchronization</span>
          <button
            onClick={onClose}
            className="py-1.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
