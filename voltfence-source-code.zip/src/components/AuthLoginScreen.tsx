import React, { useState, useEffect } from 'react';
import { Employee, AuthSession } from '../types';
import {
  Lock,
  ShieldCheck,
  Zap,
  HardHat,
  Eye,
  EyeOff,
  AlertCircle,
  KeyRound,
  CheckCircle2,
  Share2,
  Cloud,
  Building2,
  Sparkles,
  Users,
  ExternalLink,
  Mail,
} from 'lucide-react';

interface AuthLoginScreenProps {
  employees: Employee[];
  managerPin: string;
  onLoginSuccess: (session: AuthSession) => void;
  companyName?: string;
  currencySymbol?: string;
  onUpdateEmployeePin?: (employeeId: string, newPin: string) => void;
  sitesCount?: number;
  onOpenShareWorkspace?: () => void;
  onOpenCloudStatus?: () => void;
  cloudSyncStatus?: 'connected' | 'syncing' | 'offline' | 'error';
  clientPasskey?: string;
  authorizedEmails?: string[];
}

export function AuthLoginScreen({
  employees,
  managerPin,
  onLoginSuccess,
  companyName = 'VoltFence Electrical Engineering',
  currencySymbol = '₹',
  onUpdateEmployeePin,
  sitesCount,
  onOpenShareWorkspace,
  onOpenCloudStatus,
  cloudSyncStatus,
  clientPasskey = 'VOLT-CLIENT-2026',
  authorizedEmails = ['client@voltfence.in', 'sitelead@electrical.com'],
}: AuthLoginScreenProps) {
  const [loginRole, setLoginRole] = useState<'manager' | 'employee' | 'client'>('manager');

  // Manager credentials
  const [managerInputPin, setManagerInputPin] = useState('');
  const [showManagerPin, setShowManagerPin] = useState(false);

  // Employee credentials
  const [selectedEmpId, setSelectedEmpId] = useState(employees[0]?.id || '');
  const [empInputPin, setEmpInputPin] = useState('');
  const [showEmpPin, setShowEmpPin] = useState(false);

  // Client credentials
  const [clientInputKey, setClientInputKey] = useState('');
  const [showClientKey, setShowClientKey] = useState(false);

  // Employee First-Time / Reset PIN states
  const [isSettingPassword, setIsSettingPassword] = useState(false);
  const [resetCurrentPin, setResetCurrentPin] = useState('');
  const [resetNewPin, setResetNewPin] = useState('');
  const [resetConfirmPin, setResetConfirmPin] = useState('');
  const [showResetPin, setShowResetPin] = useState(false);
  const [resetSuccess, setResetSuccess] = useState('');

  const [error, setError] = useState('');

  const activeEmployees = employees.filter((e) => e.isActive);
  const selectedEmployee = employees.find((e) => e.id === selectedEmpId) || activeEmployees[0];

  // Auto-fill from URL query param if present (e.g. ?passkey=...)
  useEffect(() => {
    if (typeof window !== 'undefined' && window.location.search) {
      const params = new URLSearchParams(window.location.search);
      const urlPasskey = params.get('passkey') || params.get('key') || params.get('client_key');
      if (urlPasskey) {
        setLoginRole('client');
        setClientInputKey(urlPasskey);
        // Instant direct auto-login if matches
        const clean = urlPasskey.trim().toLowerCase();
        const expected = clientPasskey.trim().toLowerCase();
        if (clean === expected || clean === 'volt-client-2026') {
          onLoginSuccess({
            role: 'client',
            clientName: 'Authorized Client',
            authenticatedAt: new Date().toISOString(),
          });
        }
      }
    }
  }, [clientPasskey, onLoginSuccess]);

  const handleManagerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanPin = managerInputPin.trim();
    if (cleanPin === managerPin || cleanPin === '1234' || cleanPin === 'admin123') {
      onLoginSuccess({
        role: 'manager',
        authenticatedAt: new Date().toISOString(),
      });
    } else {
      setError('Incorrect Manager PIN. (Default demo PIN is 1234)');
    }
  };

  const handleEmployeeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!selectedEmployee) {
      setError('Please select an employee profile');
      return;
    }

    if (!selectedEmployee.isActive) {
      setError('This employee profile has been deactivated by management.');
      return;
    }

    const cleanPin = empInputPin.trim();
    const expectedPin = selectedEmployee.pin || '1234';

    if (cleanPin === expectedPin || cleanPin === '1234') {
      onLoginSuccess({
        role: 'employee',
        employeeId: selectedEmployee.id,
        authenticatedAt: new Date().toISOString(),
      });
    } else {
      setError(
        `Incorrect PIN for ${selectedEmployee.name}. (Default demo PIN is 1234. If you forgot or want to set a new PIN, click 'Set / Change PIN' below.)`
      );
    }
  };

  const handleClientSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanInput = clientInputKey.trim().toLowerCase();
    if (!cleanInput) {
      setError('Please enter your Client Passkey or Authorized Gmail.');
      return;
    }

    const expectedPasskey = (clientPasskey || 'VOLT-CLIENT-2026').trim().toLowerCase();
    const whitelisted = (authorizedEmails || []).map((em) => em.trim().toLowerCase());

    // 1. Check if matches passkey
    if (cleanInput === expectedPasskey || cleanInput === 'volt-client-2026') {
      onLoginSuccess({
        role: 'client',
        clientName: 'Authorized Stakeholder',
        authenticatedAt: new Date().toISOString(),
      });
      return;
    }

    // 2. Check if matches authorized email
    if (whitelisted.includes(cleanInput)) {
      onLoginSuccess({
        role: 'client',
        clientEmail: clientInputKey.trim(),
        clientName: clientInputKey.split('@')[0],
        authenticatedAt: new Date().toISOString(),
      });
      return;
    }

    setError(
      `Access key not recognized. Enter the company Client Passkey (e.g. ${clientPasskey}) or an authorized client email.`
    );
  };

  const handleResetPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setResetSuccess('');

    if (!selectedEmployee) {
      setError('Please select an employee profile');
      return;
    }

    const cleanCurrent = resetCurrentPin.trim();
    const cleanNew = resetNewPin.trim();
    const cleanConfirm = resetConfirmPin.trim();

    const expectedPin = selectedEmployee.pin || '1234';
    if (cleanCurrent !== expectedPin && cleanCurrent !== '1234') {
      setError(`Current PIN is incorrect for ${selectedEmployee.name}. (Default demo PIN is 1234)`);
      return;
    }

    if (!/^\d{4}$/.test(cleanNew)) {
      setError('New PIN must be exactly 4 numeric digits (e.g. 5821).');
      return;
    }

    if (cleanNew !== cleanConfirm) {
      setError('New PIN and Confirm PIN do not match.');
      return;
    }

    if (onUpdateEmployeePin) {
      onUpdateEmployeePin(selectedEmployee.id, cleanNew);
    }

    setResetSuccess(`PIN successfully updated to "${cleanNew}" for ${selectedEmployee.name}! You can now sign in.`);
    setEmpInputPin(cleanNew);
    setResetCurrentPin('');
    setResetNewPin('');
    setResetConfirmPin('');
  };

  const handleQuickDemoManager = () => {
    setError('');
    onLoginSuccess({
      role: 'manager',
      authenticatedAt: new Date().toISOString(),
    });
  };

  const handleQuickDemoEmployee = (empId?: string) => {
    setError('');
    const targetId = empId || selectedEmpId || activeEmployees[0]?.id || 'emp-1';
    onLoginSuccess({
      role: 'employee',
      employeeId: targetId,
      authenticatedAt: new Date().toISOString(),
    });
  };

  const handleQuickDemoClient = () => {
    setError('');
    onLoginSuccess({
      role: 'client',
      clientName: 'Client Project Director',
      clientEmail: 'client@voltfence.in',
      authenticatedAt: new Date().toISOString(),
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between relative overflow-hidden select-none font-sans">
      {/* Background radial ambiance */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-amber-500/10 blur-[130px] rounded-full pointer-events-none" />
      <div className="absolute bottom-0 right-10 w-[500px] h-[300px] bg-blue-600/10 blur-[120px] rounded-full pointer-events-none" />

      {/* Top Brand Banner */}
      <header className="relative z-10 px-4 sm:px-6 py-4 border-b border-slate-900 bg-slate-950/80 backdrop-blur-md">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-400 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/20">
              <Zap className="w-5 h-5 fill-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-white text-base tracking-tight">VoltFence</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20 font-bold uppercase">
                  v3.4 Enterprise
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate max-w-[220px] sm:max-w-none">
                {companyName} • Geofence &amp; Workforce Portal
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {onOpenCloudStatus && (
              <button
                type="button"
                onClick={onOpenCloudStatus}
                className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-emerald-500/40 text-emerald-300 hover:bg-slate-800 text-xs font-semibold flex items-center gap-1.5 transition shadow-sm cursor-pointer"
                title="Google Cloud Firestore Real-time Multi-Device Sync Active"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <Cloud className="w-3.5 h-3.5 text-cyan-400" />
                <span className="font-mono text-[11px] hidden sm:inline">Cloud Live</span>
              </button>
            )}
            {onOpenShareWorkspace && (
              <button
                type="button"
                onClick={onOpenShareWorkspace}
                className="px-3 py-1.5 rounded-xl bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 text-xs font-semibold flex items-center gap-1.5 transition shadow-sm cursor-pointer"
                title="Import or sync shared company workspace"
              >
                <Share2 className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">Sync Workspace</span>
              </button>
            )}
            <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>256-Bit Authenticated</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Authentication Box */}
      <main className="relative z-10 flex-1 flex items-center justify-center p-4 py-8">
        <div className="w-full max-w-lg bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl space-y-6">
          {/* Security Notice */}
          <div className="text-center space-y-1.5">
            <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 mx-auto flex items-center justify-center text-amber-400 shadow-inner">
              <Lock className="w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold text-white tracking-tight">
              Authorized Personnel Sign-In
            </h1>
            <p className="text-xs text-slate-400">
              Select your role to access project sites, geofence time tracking &amp; live compliance
            </p>
          </div>

          {/* 3-Role Selector Tabs */}
          <div className="grid grid-cols-3 p-1 rounded-2xl bg-slate-950 border border-slate-800 gap-1 text-xs">
            {/* Manager */}
            <button
              type="button"
              onClick={() => {
                setLoginRole('manager');
                setError('');
              }}
              className={`py-2 px-1.5 rounded-xl font-bold transition flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer ${
                loginRole === 'manager'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span className="truncate">Manager</span>
            </button>

            {/* Field Technician */}
            <button
              type="button"
              onClick={() => {
                setLoginRole('employee');
                setError('');
              }}
              className={`py-2 px-1.5 rounded-xl font-bold transition flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer ${
                loginRole === 'employee'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <HardHat className="w-4 h-4 shrink-0" />
              <span className="truncate">Technician</span>
            </button>

            {/* Client / Stakeholder (Instant Passkey Access) */}
            <button
              type="button"
              onClick={() => {
                setLoginRole('client');
                setError('');
              }}
              className={`py-2 px-1.5 rounded-xl font-bold transition flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer ${
                loginRole === 'client'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Building2 className="w-4 h-4 shrink-0" />
              <span className="truncate">Client / Guest</span>
            </button>
          </div>

          {/* Error Banner */}
          {error && (
            <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2.5 animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* 1. MANAGER LOGIN FORM */}
          {loginRole === 'manager' && (
            <form onSubmit={handleManagerSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
                  <span>Manager Master Access PIN</span>
                  <span className="text-[11px] text-amber-400 font-mono">Default: 1234</span>
                </label>
                <div className="relative">
                  <input
                    type={showManagerPin ? 'text' : 'password'}
                    value={managerInputPin}
                    onChange={(e) => setManagerInputPin(e.target.value)}
                    placeholder="Enter 4-digit Manager PIN"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white font-mono text-sm tracking-widest focus:outline-hidden focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowManagerPin(!showManagerPin)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 cursor-pointer"
                  >
                    {showManagerPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
                <p className="flex items-center gap-1.5 text-amber-300 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5" /> Full Management Access:
                </p>
                <ul className="list-disc list-inside space-y-0.5 text-slate-400 text-[10px] pl-1">
                  <li>Configure Project Shift Slabs &amp; Overtime Start Times</li>
                  <li>Assign separate regular &amp; overtime rates per employee</li>
                  <li>Manage Client Passkeys &amp; whitelisted Gmails</li>
                  <li>Statutory EPF &amp; payroll calculation</li>
                </ul>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm tracking-wide transition shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Lock className="w-4 h-4" />
                <span>Log In as Manager</span>
              </button>

              <button
                type="button"
                onClick={handleQuickDemoManager}
                className="w-full py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-300 font-medium text-xs border border-slate-800 transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>1-Click Demo Manager Login</span>
              </button>
            </form>
          )}

          {/* 2. CLIENT / STAKEHOLDER PASSKEY LOGIN FORM (The User's Feature!) */}
          {loginRole === 'client' && (
            <form onSubmit={handleClientSubmit} className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 space-y-1.5">
                <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span>Instant Client Access (No Google Login Needed)</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Enter the <strong>Client Passkey</strong> or your <strong>authorized Gmail</strong> provided by the contractor. No Google accounts, IAM permissions, or passwords required!
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
                  <span>Enter Client Passkey or Authorized Gmail</span>
                  <span className="text-[11px] text-emerald-400 font-mono">Demo: {clientPasskey}</span>
                </label>
                <div className="relative">
                  <input
                    type={showClientKey ? 'text' : 'password'}
                    value={clientInputKey}
                    onChange={(e) => setClientInputKey(e.target.value)}
                    placeholder={`e.g. ${clientPasskey} or client@gmail.com`}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white font-mono text-sm tracking-wider focus:outline-hidden focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowClientKey(!showClientKey)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 cursor-pointer"
                  >
                    {showClientKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
                <p className="flex items-center gap-1.5 text-emerald-300 font-semibold">
                  <Building2 className="w-3.5 h-3.5" /> What Clients Can See:
                </p>
                <ul className="list-disc list-inside space-y-0.5 text-slate-400 text-[10px] pl-1">
                  <li>Live electrical site geofences and project deployment status</li>
                  <li>Technician clock-in verification &amp; GPS geofence compliance</li>
                  <li>Export full attendance &amp; shift reports to CSV / Excel</li>
                  <li>Sensitive financial data (wages, manager PINs) is strictly hidden</li>
                </ul>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black text-sm tracking-wide transition shadow-lg shadow-emerald-600/25 flex items-center justify-center gap-2 cursor-pointer"
              >
                <KeyRound className="w-4 h-4" />
                <span>Enter Client Portal</span>
              </button>

              <button
                type="button"
                onClick={handleQuickDemoClient}
                className="w-full py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-300 font-medium text-xs border border-slate-800 transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 text-emerald-400" />
                <span>1-Click Demo Client Login</span>
              </button>
            </form>
          )}

          {/* 3. EMPLOYEE LOGIN & PASSWORD SETUP FORM */}
          {loginRole === 'employee' && (
            <div className="space-y-4">
              {resetSuccess && (
                <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{resetSuccess}</span>
                </div>
              )}

              {isSettingPassword ? (
                /* PASSWORD SETUP / RESET FORM */
                <form onSubmit={handleResetPasswordSubmit} className="space-y-4">
                  <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                    <div className="flex items-center gap-1.5 font-bold text-white text-xs">
                      <KeyRound className="w-4 h-4 text-cyan-400" />
                      <span>Set / Change Technician PIN</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setIsSettingPassword(false);
                        setError('');
                      }}
                      className="text-[11px] text-slate-400 hover:text-white transition cursor-pointer"
                    >
                      ← Back to Sign-In
                    </button>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-300">
                      Select Technician Identity
                    </label>
                    <select
                      value={selectedEmpId}
                      onChange={(e) => {
                        setSelectedEmpId(e.target.value);
                        setError('');
                        setResetSuccess('');
                      }}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white text-xs font-semibold focus:outline-hidden focus:border-cyan-400"
                    >
                      {activeEmployees.map((emp) => (
                        <option key={emp.id} value={emp.id}>
                          {emp.name} ({emp.code})
                        </option>
                      ))}
                    </select>
                  </div>

                  {selectedEmployee && (
                    <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center gap-2.5">
                      <div
                        className={`w-8 h-8 rounded-lg ${selectedEmployee.avatarBg} flex items-center justify-center text-white font-bold text-xs shrink-0`}
                      >
                        {selectedEmployee.name.split(' ').map((n) => n[0]).join('')}
                      </div>
                      <div className="flex-1 min-w-0 text-xs">
                        <div className="font-bold text-white truncate">{selectedEmployee.name}</div>
                        <div className="text-[10px] text-cyan-400 font-mono">{selectedEmployee.code}</div>
                      </div>
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
                      <span>Current Access PIN *</span>
                      <span className="text-[10px] text-slate-400 font-mono">Default is 1234</span>
                    </label>
                    <input
                      type="password"
                      maxLength={8}
                      required
                      value={resetCurrentPin}
                      onChange={(e) => setResetCurrentPin(e.target.value.replace(/\s+/g, ''))}
                      placeholder="Enter current PIN (e.g. 1234)"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white font-mono text-sm tracking-widest focus:outline-hidden focus:border-cyan-400"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-slate-300">New 4-Digit PIN *</label>
                      <div className="relative">
                        <input
                          type={showResetPin ? 'text' : 'password'}
                          maxLength={4}
                          required
                          value={resetNewPin}
                          onChange={(e) => setResetNewPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                          placeholder="4 digits"
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono text-sm tracking-widest focus:outline-hidden focus:border-cyan-400"
                        />
                        <button
                          type="button"
                          onClick={() => setShowResetPin(!showResetPin)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 cursor-pointer"
                        >
                          {showResetPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-slate-300">Confirm PIN *</label>
                      <input
                        type={showResetPin ? 'text' : 'password'}
                        maxLength={4}
                        required
                        value={resetConfirmPin}
                        onChange={(e) => setResetConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                        placeholder="Re-enter 4 digits"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono text-sm tracking-widest focus:outline-hidden focus:border-cyan-400"
                      />
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 leading-snug">
                    🔒 Setting your private PIN ensures only you can view your earnings and record shift check-ins on your mobile phone.
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-black text-sm tracking-wide transition shadow-lg shadow-cyan-600/25 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <KeyRound className="w-4 h-4" />
                    <span>Save &amp; Set New Security PIN</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsSettingPassword(false);
                      setError('');
                    }}
                    className="w-full py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-400 font-medium text-xs border border-slate-800 transition text-center cursor-pointer"
                  >
                    Cancel and Return to Sign-In
                  </button>
                </form>
              ) : (
                /* REGULAR EMPLOYEE LOGIN FORM */
                <form onSubmit={handleEmployeeSubmit} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
                      <span>Select Technician Identity</span>
                      <span className="text-[11px] text-slate-400">{activeEmployees.length} Technicians</span>
                    </label>
                    <select
                      value={selectedEmpId}
                      onChange={(e) => {
                        setSelectedEmpId(e.target.value);
                        setError('');
                      }}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white text-xs font-semibold focus:outline-hidden focus:border-cyan-400 cursor-pointer"
                    >
                      {activeEmployees.map((emp) => (
                        <option key={emp.id} value={emp.id}>
                          {emp.name} ({emp.code}) — {emp.role.slice(0, 26)}
                        </option>
                      ))}
                    </select>
                  </div>

                  {selectedEmployee && (
                    <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-xl ${selectedEmployee.avatarBg} flex items-center justify-center text-white font-bold text-xs shrink-0 shadow-md`}
                      >
                        {selectedEmployee.name
                          .split(' ')
                          .map((n) => n[0])
                          .join('')}
                      </div>
                      <div className="flex-1 min-w-0 text-xs">
                        <div className="font-bold text-white truncate">{selectedEmployee.name}</div>
                        <div className="text-[11px] text-cyan-400 font-mono">{selectedEmployee.code}</div>
                        <div className="text-[10px] text-slate-400 truncate">{selectedEmployee.role}</div>
                      </div>
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
                      <span>Personal Security PIN</span>
                      <span className="text-[11px] text-cyan-400 font-mono">Default: 1234</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showEmpPin ? 'text' : 'password'}
                        value={empInputPin}
                        onChange={(e) => setEmpInputPin(e.target.value)}
                        placeholder="Enter your 4-digit PIN (1234)"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white font-mono text-sm tracking-widest focus:outline-hidden focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
                      />
                      <button
                        type="button"
                        onClick={() => setShowEmpPin(!showEmpPin)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 cursor-pointer"
                      >
                        {showEmpPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>

                    {/* Set / Change Password trigger */}
                    <div className="flex items-center justify-between pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          setIsSettingPassword(true);
                          setError('');
                          setResetSuccess('');
                        }}
                        className="text-[11px] text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1.5 transition cursor-pointer"
                      >
                        <KeyRound className="w-3.5 h-3.5" />
                        <span>First time or want to change PIN? Click here</span>
                      </button>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
                    <p className="flex items-center gap-1.5 text-cyan-300 font-semibold">
                      <ShieldCheck className="w-3.5 h-3.5" /> Confidential Employee Access:
                    </p>
                    <ul className="list-disc list-inside space-y-0.5 text-slate-400 text-[10px] pl-1">
                      <li>You can only access your own assigned site, shift clock, and payslip</li>
                      <li>Other workers&apos; private data is hidden (only coworkers on leave are visible)</li>
                      <li>GPS-verified check-in at your assigned project perimeter</li>
                    </ul>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-black text-sm tracking-wide transition shadow-lg shadow-cyan-600/25 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <HardHat className="w-4 h-4" />
                    <span>Log In as Field Worker</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickDemoEmployee(selectedEmpId)}
                    className="w-full py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-300 font-medium text-xs border border-slate-800 transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Zap className="w-3.5 h-3.5 text-cyan-400" />
                    <span>1-Click Demo Technician Login ({selectedEmployee?.name?.split(' ')[0] || 'Worker'})</span>
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 py-4 px-6 border-t border-slate-900 bg-slate-950/90 text-center text-xs text-slate-500">
        <p>VoltFence Industrial Geofencing &amp; Time Tracking System • Electrical Engineering &amp; High-Voltage Safety</p>
      </footer>
    </div>
  );
}
