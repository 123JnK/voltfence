import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  ElectricalSite,
  Employee,
  AttendanceRecord,
  UserLocation,
  LeaveRequest,
  LeaveType,
} from '../types';
import { calculateDistanceMeters, formatDistance } from '../utils/geo';
import {
  ShieldAlert,
  MapPin,
  CheckCircle2,
  AlertOctagon,
  Clock,
  Compass,
  Radio,
  FileCheck2,
  HardHat,
  Lock,
  Battery,
  Wifi,
  ChevronRight,
  LogOut,
  LogIn,
  RotateCcw,
  Calendar,
  DollarSign,
  UserX,
  FileText,
  Plus,
  Crosshair,
  Building,
  AlertTriangle,
  Check,
  X,
  RefreshCw,
  Zap,
  Key,
  Eye,
  EyeOff,
  ShieldCheck,
} from 'lucide-react';

interface FieldWorkerPortalProps {
  employees: Employee[];
  sites: ElectricalSite[];
  attendanceRecords: AttendanceRecord[];
  leaves: LeaveRequest[];
  userLocation: UserLocation;
  setUserLocation: React.Dispatch<React.SetStateAction<UserLocation>>;
  onClockIn: (record: Omit<AttendanceRecord, 'id'>) => void;
  onClockOut: (recordId: string, notes?: string) => void;
  onApplyLeave: (newLeave: Omit<LeaveRequest, 'id'>) => void;
  selectedWorkerId: string;
  setSelectedWorkerId: (id: string) => void;
  currencySymbol?: string;
  isLockedToEmployee?: boolean;
  onUpdatePin?: (employeeId: string, newPin: string) => void;
}

export function FieldWorkerPortal({
  employees,
  sites,
  attendanceRecords,
  leaves,
  userLocation,
  setUserLocation,
  onClockIn,
  onClockOut,
  onApplyLeave,
  selectedWorkerId,
  setSelectedWorkerId,
  currencySymbol = '₹',
  isLockedToEmployee = false,
  onUpdatePin,
}: FieldWorkerPortalProps) {
  const currentWorker = employees.find((e) => e.id === selectedWorkerId) || employees[0];

  const todayStr = new Date().toISOString().split('T')[0];

  // Colleagues currently on leave (only colleagues on leave are visible to employees)
  const colleaguesOnLeave = employees.filter((emp) => {
    if (emp.id === currentWorker?.id) return false;
    const hasApprovedLeaveToday = leaves.some(
      (l) => l.employeeId === emp.id && l.status === 'approved' && l.startDate <= todayStr && l.endDate >= todayStr
    );
    return emp.status === 'on_leave' || hasApprovedLeaveToday;
  });

  // Mobile App Sub-tab (Attendance / Leaves / EPF / Security)
  const [mobileTab, setMobileTab] = useState<'radar' | 'leaves' | 'epf' | 'security'>('radar');

  // Security & PIN Management states
  const [currentPinInput, setCurrentPinInput] = useState('');
  const [newPinInput, setNewPinInput] = useState('');
  const [confirmPinInput, setConfirmPinInput] = useState('');
  const [showCurrentPin, setShowCurrentPin] = useState(false);
  const [showNewPin, setShowNewPin] = useState(false);
  const [pinChangeError, setPinChangeError] = useState('');
  const [pinChangeSuccess, setPinChangeSuccess] = useState('');

  // Active sites
  const activeSites = sites.filter((s) => s.status === 'active');

  // Find if current worker is currently clocked in today
  const activeShift = attendanceRecords.find(
    (r) => r.employeeId === currentWorker?.id && r.status === 'active_shift'
  );

  // Shift Timer
  const [shiftSeconds, setShiftSeconds] = useState(0);

  useEffect(() => {
    if (!activeShift) {
      setShiftSeconds(0);
      return;
    }

    const start = new Date(activeShift.checkInTime).getTime();
    const update = () => {
      const now = Date.now();
      setShiftSeconds(Math.max(0, Math.floor((now - start) / 1000)));
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [activeShift]);

  // REQUIREMENT 1: Employee check-in/check-out is locked to their ASSIGNED project location
  const assignedSite = sites.find((s) => s.id === currentWorker?.primarySiteId) || activeSites[0];
  const [selectedSiteId, setSelectedSiteId] = useState<string | null>(null);
  const targetSiteId = activeShift ? activeShift.siteId : (selectedSiteId || currentWorker?.primarySiteId || activeSites[0]?.id);
  const targetSite = sites.find((s) => s.id === targetSiteId) || assignedSite;

  // Calculate distance to target site
  const distanceToTarget = targetSite
    ? calculateDistanceMeters(
        userLocation.lat,
        userLocation.lng,
        targetSite.location.lat,
        targetSite.location.lng
      )
    : 9999;

  const isWithinGeofence = targetSite ? distanceToTarget <= targetSite.geofenceRadius : false;

  // Proximity to all active sites (Smart Site Matcher)
  const siteDistances = activeSites.map((s) => {
    const dist = calculateDistanceMeters(
      userLocation.lat,
      userLocation.lng,
      s.location.lat,
      s.location.lng
    );
    return {
      site: s,
      distance: dist,
      isInside: dist <= s.geofenceRadius,
    };
  }).sort((a, b) => a.distance - b.distance);

  const nearestSiteMatch = siteDistances[0];
  const isAssignedToTargetSite =
    targetSite &&
    (currentWorker?.primarySiteId === targetSite.id ||
      targetSite.assignedEmployeeIds?.includes(currentWorker?.id));

  // Safety checklist states
  const [ppeChecked, setPpeChecked] = useState(true);
  const [lotoChecked, setLotoChecked] = useState(true);
  const [taskNotes, setTaskNotes] = useState('');
  const [showOverrideModal, setShowOverrideModal] = useState(false);

  // Indoor / Weak GPS Check-In Modal state
  const [isIndoorModalOpen, setIsIndoorModalOpen] = useState(false);
  const [indoorReason, setIndoorReason] = useState('Underground / Basement Transformer Room');
  const [indoorSupervisor, setIndoorSupervisor] = useState('Foreman Rajesh Approved');
  const [indoorNotes, setIndoorNotes] = useState('');
  const [isRefreshingGps, setIsRefreshingGps] = useState(false);
  const [gpsStatusMessage, setGpsStatusMessage] = useState<string | null>(null);

  // Leave application modal in mobile view
  const [isLeaveModalOpen, setIsLeaveModalOpen] = useState(false);
  const [leaveType, setLeaveType] = useState<LeaveType>('casual');
  const [leaveStartDate, setLeaveStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [leaveEndDate, setLeaveEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [leaveReason, setLeaveReason] = useState('');

  // Worker leaves
  const myLeaves = leaves.filter((l) => l.employeeId === currentWorker?.id);

  // Teleport simulator presets
  const handleTeleport = (site: ElectricalSite, offsetMeters = 20) => {
    const latOffset = (offsetMeters / 111111) * (Math.random() > 0.5 ? 0.7 : -0.7);
    const lngOffset =
      (offsetMeters / (111111 * Math.cos((site.location.lat * Math.PI) / 180))) *
      (Math.random() > 0.5 ? 0.7 : -0.7);

    setUserLocation({
      lat: Number((site.location.lat + latOffset).toFixed(6)),
      lng: Number((site.location.lng + lngOffset).toFixed(6)),
      accuracy: 4,
      isSimulated: true,
      sourceDescription: `Simulated inside ${site.name}`,
    });
    setSelectedSiteId(site.id);
  };

  const handleTeleportOffsite = () => {
    if (!targetSite) return;
    setUserLocation({
      lat: Number((targetSite.location.lat + 0.015).toFixed(6)),
      lng: Number((targetSite.location.lng + 0.012).toFixed(6)),
      accuracy: 6,
      isSimulated: true,
      sourceDescription: 'Simulated 1.8km off-site',
    });
  };

  const handleUseRealGps = () => {
    if ('geolocation' in navigator) {
      setIsRefreshingGps(true);
      setGpsStatusMessage('📡 Acquiring fresh satellite GPS signal...');

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setIsRefreshingGps(false);
          const acc = Math.round(pos.coords.accuracy);
          setUserLocation({
            lat: Number(pos.coords.latitude.toFixed(6)),
            lng: Number(pos.coords.longitude.toFixed(6)),
            accuracy: acc,
            isSimulated: false,
            sourceDescription: 'Hardware GPS',
          });
          setGpsStatusMessage(`✅ GPS refreshed: ±${acc}m accuracy`);
        },
        (err) => {
          setIsRefreshingGps(false);
          console.warn('Geolocation error:', err.message);
          setGpsStatusMessage(`⚠️ GPS Notice: ${err.message}. Using cached coordinates.`);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    }
  };

  // Regular Clock In Action
  const handlePerformClockIn = (override = false) => {
    if (!targetSite || !currentWorker || !currentWorker.isActive) return;

    if (!isWithinGeofence && !override) {
      setShowOverrideModal(true);
      return;
    }

    const todayStr = new Date().toISOString().split('T')[0];
    const newRecord: Omit<AttendanceRecord, 'id'> = {
      employeeId: currentWorker.id,
      employeeName: currentWorker.name,
      siteId: targetSite.id,
      siteName: targetSite.name,
      date: todayStr,
      checkInTime: new Date().toISOString(),
      checkInCoords: { lat: userLocation.lat, lng: userLocation.lng },
      checkInDistanceMeters: distanceToTarget,
      geofenceVerified: isWithinGeofence,
      status: isWithinGeofence ? 'active_shift' : 'flagged_mismatch',
      ppeConfirmed: ppeChecked,
      taskDescription: taskNotes.trim() || 'Electrical maintenance & inspection shift.',
      deviceNotes: `${userLocation.isSimulated ? 'Simulated GPS' : 'Real Hardware GPS'} (±${userLocation.accuracy}m accuracy)`,
    };

    onClockIn(newRecord);

    if (isWithinGeofence) {
      try {
        confetti({
          particleCount: 60,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {
        // ignore
      }
    }

    setTaskNotes('');
    setShowOverrideModal(false);
  };

  // Indoor / Weak GPS Check-In Action
  const handlePerformIndoorClockIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetSite || !currentWorker || !currentWorker.isActive) return;

    const todayStr = new Date().toISOString().split('T')[0];
    const newRecord: Omit<AttendanceRecord, 'id'> = {
      employeeId: currentWorker.id,
      employeeName: currentWorker.name,
      siteId: targetSite.id,
      siteName: targetSite.name,
      date: todayStr,
      checkInTime: new Date().toISOString(),
      checkInCoords: { lat: userLocation.lat, lng: userLocation.lng },
      checkInDistanceMeters: distanceToTarget,
      geofenceVerified: false, // Flagged for manager confirmation
      status: 'flagged_mismatch',
      ppeConfirmed: ppeChecked,
      taskDescription: `${indoorNotes.trim() || 'On-site maintenance'} | Location: ${indoorReason}`,
      deviceNotes: `Indoor/Weak GPS Entry: ${indoorReason} (Supervisor: ${indoorSupervisor})`,
    };

    onClockIn(newRecord);
    setIsIndoorModalOpen(false);
    setIndoorNotes('');
  };

  // Clock Out Action
  const handlePerformClockOut = () => {
    if (!activeShift) return;
    onClockOut(activeShift.id, taskNotes.trim() || undefined);
    setTaskNotes('');
  };

  // Submit Leave from Mobile
  const handleMobileApplyLeave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentWorker) return;

    const start = new Date(leaveStartDate).getTime();
    const end = new Date(leaveEndDate).getTime();
    const diffDays = Math.max(1, Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1);

    onApplyLeave({
      employeeId: currentWorker.id,
      employeeName: currentWorker.name,
      employeeCode: currentWorker.code,
      type: leaveType,
      startDate: leaveStartDate,
      endDate: leaveEndDate,
      totalDays: diffDays,
      reason: leaveReason.trim() || 'Personal leave requested via mobile app.',
      status: 'pending',
      appliedDate: new Date().toISOString().split('T')[0],
    });

    setLeaveReason('');
    setIsLeaveModalOpen(false);
  };

  const handleChangePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPinChangeError('');
    setPinChangeSuccess('');

    const cleanCurrent = currentPinInput.trim();
    const cleanNew = newPinInput.trim();
    const cleanConfirm = confirmPinInput.trim();

    const expectedCurrent = currentWorker?.pin || '1234';
    if (cleanCurrent !== expectedCurrent && cleanCurrent !== '1234') {
      setPinChangeError('Current PIN does not match your existing PIN.');
      return;
    }

    if (!/^\d{4}$/.test(cleanNew)) {
      setPinChangeError('New PIN must be exactly 4 numeric digits (e.g. 5821).');
      return;
    }

    if (cleanNew !== cleanConfirm) {
      setPinChangeError('New PIN and Confirm PIN do not match.');
      return;
    }

    if (onUpdatePin && currentWorker) {
      onUpdatePin(currentWorker.id, cleanNew);
    }
    setPinChangeSuccess(`PIN successfully updated to "${cleanNew}"! Remember this 4-digit PIN for future sign-ins.`);
    setCurrentPinInput('');
    setNewPinInput('');
    setConfirmPinInput('');
    try {
      confetti({ particleCount: 35, spread: 60, origin: { y: 0.8 } });
    } catch {
      // ignore
    }
  };

  // Format timer
  const formatTimer = (totalSec: number) => {
    const hrs = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (!currentWorker) {
    return <div className="text-center p-8 text-slate-400">No employee profile available.</div>;
  }

  // Check if Employee has been REMOVED / DEACTIVATED by manager:
  const isDeactivated = !currentWorker.isActive;

  return (
    <div className="w-full max-w-md mx-auto space-y-4">
      {/* Worker Device Mockup Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl text-slate-100 space-y-4 relative overflow-hidden">
        {/* Top Phone Status Bar */}
        <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800/80 pb-2.5">
          <div className="flex items-center gap-1.5 font-mono">
            <Radio
              className={`w-3.5 h-3.5 ${
                isDeactivated ? 'text-rose-500' : 'text-cyan-400 animate-pulse'
              }`}
            />
            <span>VoltFence ID: {currentWorker.code}</span>
          </div>
          <div className="flex items-center gap-2">
            {/* Live GPS Accuracy Gauge */}
            <span
              className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono ${
                userLocation.accuracy <= 10
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                  : userLocation.accuracy <= 30
                  ? 'bg-amber-950 text-amber-400 border border-amber-500/30'
                  : 'bg-rose-950 text-rose-400 border border-rose-500/30'
              }`}
            >
              <Crosshair className="w-2.5 h-2.5" />
              ±{userLocation.accuracy}m
            </span>
            <span className="flex items-center gap-1">
              <Wifi className="w-3 h-3 text-emerald-400" /> 5G
            </span>
            <span className="flex items-center gap-1">
              <Battery className="w-3.5 h-3.5 text-slate-300" /> 88%
            </span>
          </div>
        </div>

        {/* Worker Profile Header & Simulation Selector */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Field Technician Profile
            </span>
            <span
              className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                isDeactivated
                  ? 'bg-rose-950 text-rose-400 border border-rose-500/30'
                  : 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
              }`}
            >
              {isDeactivated ? 'ACCOUNT REVOKED' : 'AUTHORIZED DEVICE'}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div
              className={`w-11 h-11 rounded-2xl ${
                isDeactivated ? 'bg-slate-800 text-rose-400' : currentWorker.avatarBg
              } flex items-center justify-center text-white font-bold text-sm shadow-md shrink-0`}
            >
              {currentWorker.name
                .split(' ')
                .map((n) => n[0])
                .join('')}
            </div>

            <div className="flex-1 min-w-0">
              {isLockedToEmployee ? (
                <div className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 flex items-center justify-between text-xs">
                  <span className="font-bold text-white truncate">{currentWorker.name}</span>
                  <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-500/30">
                    {currentWorker.code}
                  </span>
                </div>
              ) : (
                <select
                  value={selectedWorkerId}
                  onChange={(e) => setSelectedWorkerId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs font-semibold text-white focus:outline-hidden focus:border-cyan-400 cursor-pointer truncate"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} {emp.isActive ? '' : '(REVOKED)'} — {emp.code}
                    </option>
                  ))}
                </select>
              )}
              <div className="flex items-center justify-between text-[10px] text-slate-400 mt-0.5">
                <span className="truncate">{currentWorker.role}</span>
                {assignedSite && (
                  <span className="text-amber-400/90 font-medium truncate max-w-[130px]">
                    Assigned: {assignedSite.name.split(' ')[0]}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* CRITICAL: IF EMPLOYEE IS REMOVED BY MANAGER, SHOW IMPASSABLE LOCKOUT SCREEN */}
        {isDeactivated ? (
          <div className="p-6 rounded-2xl bg-gradient-to-b from-rose-950/80 to-slate-950 border-2 border-rose-500/80 text-center space-y-4 shadow-xl">
            <div className="w-16 h-16 rounded-full bg-rose-500/20 border-2 border-rose-500 flex items-center justify-center mx-auto text-rose-400 shadow-lg shadow-rose-500/30 animate-pulse">
              <Lock className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-black text-white tracking-tight uppercase">
                Access Revoked on This Device
              </h3>
              <p className="text-xs text-rose-300 font-semibold">
                Employee Profile Deactivated by Management
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/90 border border-rose-500/30 text-left text-xs text-slate-300 space-y-2">
              <p className="leading-relaxed">
                Your employee profile (<strong>{currentWorker.code}</strong>) has been removed or
                terminated from the VoltFence company workforce roster.
              </p>
              <ul className="list-disc list-inside space-y-1 text-slate-400 text-[11px]">
                <li>Geofence clock-in is permanently disabled</li>
                <li>Site access authorizations revoked</li>
                <li>EPF &amp; payroll disbursement closed</li>
              </ul>
            </div>

            <p className="text-[11px] text-slate-400">
              If you believe this is in error, please contact your company field superintendent or
              operations manager.
            </p>
          </div>
        ) : (
          /* ACTIVE EMPLOYEE PHONE EXPERIENCE */
          <>
            {/* Phone Navigation Tabs */}
            <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                onClick={() => setMobileTab('radar')}
                className={`flex-1 py-1.5 rounded-lg font-semibold transition flex items-center justify-center gap-1.5 ${
                  mobileTab === 'radar'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Compass className="w-3.5 h-3.5" />
                <span>Radar &amp; Shift</span>
              </button>
              <button
                onClick={() => setMobileTab('leaves')}
                className={`flex-1 py-1.5 rounded-lg font-semibold transition flex items-center justify-center gap-1.5 ${
                  mobileTab === 'leaves'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>My Leaves</span>
              </button>
              <button
                onClick={() => setMobileTab('epf')}
                className={`flex-1 py-1.5 rounded-lg font-semibold transition flex items-center justify-center gap-1.5 ${
                  mobileTab === 'epf'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <DollarSign className="w-3.5 h-3.5" />
                <span>EPF &amp; Pay</span>
              </button>
              <button
                onClick={() => setMobileTab('security')}
                className={`flex-1 py-1.5 rounded-lg font-semibold transition flex items-center justify-center gap-1.5 ${
                  mobileTab === 'security'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Key className="w-3.5 h-3.5" />
                <span>Security</span>
              </button>
            </div>

            {/* TAB 1: RADAR & CLOCK IN */}
            {mobileTab === 'radar' && (
              <>
                {/* Active Shift Card or Target Site Selector */}
                {activeShift ? (
                  <div className="bg-gradient-to-br from-emerald-950/60 to-slate-950 border border-emerald-500/40 rounded-2xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                        <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                          Shift In Progress
                        </span>
                      </div>
                      <span className="text-[11px] font-mono text-emerald-300">
                        {activeShift.geofenceVerified ? 'Verified Geofence' : 'Manager Override Active'}
                      </span>
                    </div>

                    <div className="text-center py-2 bg-slate-950/60 rounded-xl border border-emerald-500/20">
                      <span className="text-[10px] uppercase tracking-widest text-slate-400 block font-semibold">
                        Shift Elapsed Time
                      </span>
                      <span className="text-3xl font-black font-mono text-white tracking-wider">
                        {formatTimer(shiftSeconds)}
                      </span>
                    </div>

                    <div className="text-xs space-y-1">
                      <div className="text-slate-300 font-medium">{activeShift.siteName}</div>
                      <div className="text-slate-400 text-[11px]">
                        Clocked in at:{' '}
                        {new Date(activeShift.checkInTime).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                    </div>

                    {/* Shift Notes before Clock Out */}
                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-300">
                        End-of-Shift Work Summary (Optional):
                      </label>
                      <input
                        type="text"
                        value={taskNotes}
                        onChange={(e) => setTaskNotes(e.target.value)}
                        placeholder="e.g. Completed cable termination & tested insulation resistance."
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500"
                      />
                    </div>

                    {/* Clock Out Button */}
                    <button
                      onClick={handlePerformClockOut}
                      className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 transition cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" />
                      Clock Out &amp; Complete Shift
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {/* HOW APP VERIFIES RIGHT SITE: Smart Nearest Site Radar & Site Match Banner */}
                    {nearestSiteMatch && nearestSiteMatch.site.id !== targetSiteId && nearestSiteMatch.isInside && (
                      <div className="p-3 rounded-xl bg-cyan-950/60 border border-cyan-500/50 text-xs space-y-1.5 shadow-md">
                        <div className="flex items-center justify-between text-cyan-300 font-bold">
                          <span className="flex items-center gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                            GPS Auto-Detected Project Site!
                          </span>
                          <span className="font-mono text-[10px] text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-500/30">
                            Inside Perimeter
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-300">
                          You are standing at <strong>{nearestSiteMatch.site.name}</strong> ({Math.round(nearestSiteMatch.distance)}m away).
                        </p>
                        <button
                          type="button"
                          onClick={() => setSelectedSiteId(nearestSiteMatch.site.id)}
                          className="w-full py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-[11px] transition shadow-xs"
                        >
                          Switch to {nearestSiteMatch.site.name.split(' ')[0]} Site
                        </button>
                      </div>
                    )}

                    {/* REQUIREMENT 1: Assigned Project Site Box (Locked to Assigned Site) */}
                    <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-amber-400" />
                          Assigned Project Job Site
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-md font-mono bg-emerald-950 text-emerald-400 border border-emerald-500/30 font-bold">
                          ✓ Assigned Location
                        </span>
                      </div>

                      <div>
                        <h4 className="text-sm font-bold text-white">{targetSite?.name}</h4>
                        <p className="text-[11px] text-slate-400 mt-0.5 font-mono">
                          {targetSite?.code} • {targetSite?.geofenceRadius}m Perimeter • {targetSite?.category}
                        </p>
                      </div>

                      <div className="text-[10px] text-slate-400 bg-slate-900/80 p-2 rounded-lg border border-slate-800/80">
                        🔒 Check-in &amp; check-out are restricted to this assigned project location.
                      </div>
                    </div>

                    {/* Geofence Radar / Validation Card */}
                    {targetSite && (
                      <div
                        className={`p-4 rounded-2xl border transition-all ${
                          isWithinGeofence
                            ? 'bg-emerald-950/40 border-emerald-500/50 shadow-lg shadow-emerald-950/50'
                            : 'bg-rose-950/30 border-rose-500/50 shadow-lg shadow-rose-950/50'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            {isWithinGeofence ? (
                              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                            ) : (
                              <AlertOctagon className="w-5 h-5 text-rose-400 animate-bounce" />
                            )}
                            <div>
                              <span
                                className={`text-xs font-black uppercase tracking-wider ${
                                  isWithinGeofence ? 'text-emerald-400' : 'text-rose-400'
                                }`}
                              >
                                {isWithinGeofence
                                  ? 'Inside Geofence Zone'
                                  : 'Outside Geofence Perimeter'}
                              </span>
                              <p className="text-[10px] text-slate-400">
                                Site Perimeter: {targetSite.geofenceRadius}m radius
                              </p>
                            </div>
                          </div>

                          <span
                            className={`font-mono text-xs font-bold px-2 py-1 rounded-lg ${
                              isWithinGeofence
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            }`}
                          >
                            {formatDistance(distanceToTarget)} away
                          </span>
                        </div>

                        {/* Progress Visualizer of Geofence Radius */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                            <span>Center (0m)</span>
                            <span className="text-amber-400">
                              Boundary ({targetSite.geofenceRadius}m)
                            </span>
                            <span>Your GPS ({distanceToTarget}m)</span>
                          </div>
                          <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
                            <div
                              className={`h-full rounded-full transition-all duration-300 ${
                                isWithinGeofence ? 'bg-emerald-400' : 'bg-rose-500'
                              }`}
                              style={{
                                width: `${Math.min(
                                  100,
                                  Math.max(8, (distanceToTarget / targetSite.geofenceRadius) * 100)
                                )}%`,
                              }}
                            />
                          </div>
                        </div>

                        <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-800/80 text-[11px]">
                          <span className={isWithinGeofence ? 'text-emerald-300' : 'text-rose-300'}>
                            {isWithinGeofence
                              ? '✓ Position certified inside site perimeter.'
                              : `⚠️ Outside authorized boundary by ${formatDistance(distanceToTarget - targetSite.geofenceRadius)}.`}
                          </span>

                          {/* Quick GPS Refresh */}
                          <button
                            type="button"
                            onClick={handleUseRealGps}
                            disabled={isRefreshingGps}
                            className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1 transition"
                            title="Re-query phone GPS hardware for fresh satellite reading"
                          >
                            <RefreshCw className={`w-3 h-3 ${isRefreshingGps ? 'animate-spin' : ''}`} />
                            Refresh GPS
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Pre-Shift Checklist */}
                    <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 space-y-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                        <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                        Pre-Shift Electrical Safety Check
                      </span>
                      <div className="space-y-1.5 text-xs">
                        <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={ppeChecked}
                            onChange={(e) => setPpeChecked(e.target.checked)}
                            className="accent-amber-500 rounded"
                          />
                          <span>Arc Flash / Voltage-rated PPE donned</span>
                        </label>
                        <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={lotoChecked}
                            onChange={(e) => setLotoChecked(e.target.checked)}
                            className="accent-amber-500 rounded"
                          />
                          <span>Lockout/Tagout (LOTO) verified if de-energizing</span>
                        </label>
                      </div>
                    </div>

                    {/* CLOCK IN BUTTONS & INDOOR FALLBACK */}
                    <div className="space-y-2">
                      <button
                        onClick={() => handlePerformClockIn(false)}
                        className={`w-full py-3.5 rounded-2xl font-bold text-xs uppercase tracking-wider shadow-xl flex items-center justify-center gap-2 transition cursor-pointer ${
                          isWithinGeofence
                            ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/25 ring-2 ring-emerald-400/30'
                            : 'bg-amber-600 hover:bg-amber-500 text-slate-950 shadow-amber-600/25'
                        }`}
                      >
                        <LogIn className="w-4 h-4" />
                        {isWithinGeofence
                          ? 'Verified Clock In (Inside Fence)'
                          : 'Clock In (Outside Fence - Flagged)'}
                      </button>

                      {/* FALLBACK FOR WEAK GPS / INDOOR WORK */}
                      <button
                        type="button"
                        onClick={() => setIsIndoorModalOpen(true)}
                        className="w-full py-2 px-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[11px] font-medium transition flex items-center justify-center gap-1.5"
                      >
                        <Building className="w-3.5 h-3.5 text-amber-400" />
                        <span>Indoor / Shielded Room Check-In (Weak GPS Fallback)</span>
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}

            {/* TAB 2: MY LEAVES */}
            {mobileTab === 'leaves' && (
              <div className="space-y-3">
                {/* Leave Balance Row */}
                <div className="grid grid-cols-3 gap-2">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 block">Casual (CL)</span>
                    <span className="text-lg font-bold text-amber-400 font-mono">
                      {currentWorker.leaveBalance?.casual || 0}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 block">Sick (SL)</span>
                    <span className="text-lg font-bold text-emerald-400 font-mono">
                      {currentWorker.leaveBalance?.sick || 0}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 block">Earned (EL)</span>
                    <span className="text-lg font-bold text-cyan-400 font-mono">
                      {currentWorker.leaveBalance?.earned || 0}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => setIsLeaveModalOpen(true)}
                  className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-cyan-600/20 transition"
                >
                  <Plus className="w-3.5 h-3.5" /> Request Leave
                </button>

                {/* My Recent Leaves */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                    My Leave Requests
                  </span>
                  {myLeaves.length > 0 ? (
                    myLeaves.map((l) => (
                      <div
                        key={l.id}
                        className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white capitalize">{l.type} Leave</span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              l.status === 'approved'
                                ? 'bg-emerald-500/20 text-emerald-400'
                                : l.status === 'rejected'
                                ? 'bg-rose-500/20 text-rose-400'
                                : 'bg-amber-500/20 text-amber-400'
                            }`}
                          >
                            {l.status}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {l.startDate} to {l.endDate} ({l.totalDays} days)
                        </div>
                        <p className="text-[11px] text-slate-500 italic">"{l.reason}"</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-slate-500 text-center py-4">
                      No leave requests submitted yet.
                    </p>
                  )}
                </div>

                {/* REQUIREMENT 3: Employees can't access each other's info — only employees on leave are visible */}
                <div className="space-y-2 pt-3 border-t border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-amber-400" />
                      Colleagues Currently On Leave ({colleaguesOnLeave.length})
                    </span>
                    <span className="text-[9px] font-mono text-slate-500">Site Notice</span>
                  </div>

                  <p className="text-[10px] text-slate-400">
                    Confidentiality Shield: Only coworkers currently away on approved leave are displayed for site schedule coordination.
                  </p>

                  {colleaguesOnLeave.length > 0 ? (
                    <div className="space-y-1.5">
                      {colleaguesOnLeave.map((c) => {
                        const empLeave = leaves.find(
                          (l) =>
                            l.employeeId === c.id &&
                            l.status === 'approved' &&
                            l.startDate <= todayStr &&
                            l.endDate >= todayStr
                        );
                        return (
                          <div
                            key={c.id}
                            className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs"
                          >
                            <div className="flex items-center gap-2">
                              <div
                                className={`w-7 h-7 rounded-lg ${c.avatarBg} flex items-center justify-center text-white font-bold text-[10px]`}
                              >
                                {c.name.split(' ').map((n) => n[0]).join('')}
                              </div>
                              <div>
                                <div className="font-bold text-slate-200">{c.name}</div>
                                <div className="text-[10px] text-slate-500 font-mono">{c.code}</div>
                              </div>
                            </div>

                            <div className="text-right">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-500/10 text-amber-400 border border-amber-500/20">
                                {empLeave ? `${empLeave.type} Leave` : 'On Leave'}
                              </span>
                              {empLeave && (
                                <div className="text-[9px] text-slate-400 mt-0.5">
                                  Until {empLeave.endDate}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800/80 text-center text-xs text-slate-500">
                      All other teammates are available on duty today.
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB 3: MY EPF & PAYSLIP */}
            {mobileTab === 'epf' && (
              <div className="space-y-3 text-xs">
                {/* EPF Membership Card */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/50 to-slate-950 border border-emerald-500/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                      Provident Fund Account
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">Status: Active</span>
                  </div>

                  <div>
                    <span className="text-slate-400 text-[10px] block">EPF Universal Account (UAN)</span>
                    <span className="text-lg font-black font-mono text-white tracking-wider">
                      {currentWorker.epfUan || 'Not Enrolled'}
                    </span>
                  </div>

                  <div className="flex justify-between text-[11px] pt-1 border-t border-emerald-500/20">
                    <span className="text-slate-400">Contribution Rate:</span>
                    <span className="font-bold text-emerald-300 font-mono">
                      {currentWorker.epfRate}% Employee / 12% Employer
                    </span>
                  </div>
                </div>

                {/* Wage & Overtime Rates Assigned to this Employee */}
                <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2.5">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                      Your Wage &amp; Overtime Pay Structure
                    </span>
                    {assignedSite?.employeeProjectRates?.[currentWorker.id] ? (
                      <span className="text-[9px] font-mono text-cyan-300 bg-cyan-950/80 border border-cyan-500/30 px-1.5 py-0.5 rounded">
                        Project Specific Rate
                      </span>
                    ) : (
                      <span className="text-[9px] font-mono text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded">
                        Standard Company Rate
                      </span>
                    )}
                  </div>

                  {/* Shift Time Slab Notice */}
                  {assignedSite?.shiftConfig && (
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-[10px] text-slate-300 space-y-0.5">
                      <div className="text-amber-300 font-bold flex items-center gap-1">
                        <Clock className="w-3 h-3 text-amber-400" />
                        Shift Slab: {assignedSite.shiftConfig.shiftName} ({assignedSite.shiftConfig.shiftStartTime} - {assignedSite.shiftConfig.shiftEndTime})
                      </div>
                      <div className="text-slate-400">
                        Overtime calculation begins at <strong>{assignedSite.shiftConfig.overtimeStartTime}</strong> (or past {assignedSite.shiftConfig.regularShiftHours}h regular shift limit).
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">Daily Wage (Regular)</span>
                      <strong className="text-white font-mono text-xs">
                        {currencySymbol}
                        {assignedSite?.employeeProjectRates?.[currentWorker.id]?.dailyWage ||
                          currentWorker.dailyWage ||
                          1200}
                      </strong>
                      <span className="text-[9px] text-slate-500 block">
                        ({assignedSite?.shiftConfig?.regularShiftHours || currentWorker.regularShiftHours || 8}h regular shift)
                      </span>
                    </div>

                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">Regular Hourly Rate</span>
                      <strong className="text-emerald-400 font-mono text-xs">
                        {currencySymbol}
                        {assignedSite?.employeeProjectRates?.[currentWorker.id]?.regularHourlyRate ||
                          currentWorker.regularHourlyRate ||
                          150}
                        /hr
                      </strong>
                      <span className="text-[9px] text-slate-500 block">Regular shift hours</span>
                    </div>
                  </div>

                  <div className="p-2 rounded-xl bg-amber-950/40 border border-amber-500/30 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-amber-300 block flex items-center gap-1">
                        <Zap className="w-3.5 h-3.5 text-amber-400" />
                        Overtime (OT) Hourly Rate:
                      </span>
                      <span className="text-[10px] text-amber-400/80">
                        Paid for hours worked beyond {assignedSite?.shiftConfig?.regularShiftHours || currentWorker.regularShiftHours || 8}h
                      </span>
                    </div>
                    <span className="font-mono font-black text-amber-400 text-sm">
                      {currencySymbol}
                      {assignedSite?.employeeProjectRates?.[currentWorker.id]?.overtimeHourlyRate ||
                        currentWorker.overtimeHourlyRate ||
                        250}
                      /hr
                    </span>
                  </div>

                  <div className="space-y-1.5 text-[11px] pt-1 border-t border-slate-800">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Hazard Allowance:</span>
                      <span className="font-mono text-cyan-400">
                        +{currencySymbol}{currentWorker.hazardAllowance.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">EPF Deducted (12%):</span>
                      <span className="font-mono text-rose-400">
                        -{currencySymbol}
                        {((currentWorker.basicSalary * currentWorker.epfRate) / 100).toFixed(0)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="text-[10px] text-slate-500 text-center italic">
                  🔒 Confidential: Visible only on your verified mobile device.
                </div>
              </div>
            )}

            {/* TAB 4: SECURITY & PIN MANAGEMENT */}
            {mobileTab === 'security' && (
              <div className="space-y-4">
                {/* Security Identity Header */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-950 to-slate-900 border border-cyan-500/30 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                        <Key className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-bold text-white text-xs">Device Security &amp; Credentials</h4>
                        <p className="text-[10px] text-slate-400">Manage your private mobile sign-in PIN</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/30 font-bold flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      Active
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                    <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Employee Code</span>
                      <span className="font-mono font-bold text-cyan-400">{currentWorker.code}</span>
                    </div>
                    <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Current PIN Status</span>
                      <span className="font-mono font-bold text-white">•••• (Configured)</span>
                    </div>
                  </div>
                </div>

                {/* Form: Change Security PIN */}
                <form
                  onSubmit={handleChangePinSubmit}
                  className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3.5"
                >
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="font-bold text-white text-xs flex items-center gap-1.5 uppercase tracking-wider">
                      <Lock className="w-3.5 h-3.5 text-cyan-400" />
                      Change Your 4-Digit PIN
                    </span>
                    <span className="text-[10px] font-mono text-cyan-400">Numeric (0-9)</span>
                  </div>

                  {/* Feedback alerts */}
                  {pinChangeError && (
                    <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                      <span>{pinChangeError}</span>
                    </div>
                  )}

                  {pinChangeSuccess && (
                    <div className="p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span>{pinChangeSuccess}</span>
                    </div>
                  )}

                  {/* Current PIN Input */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-slate-300 flex items-center justify-between">
                      <span>Current Access PIN *</span>
                      <span className="text-[10px] text-slate-400 font-mono">Default is 1234</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showCurrentPin ? 'text' : 'password'}
                        maxLength={8}
                        required
                        value={currentPinInput}
                        onChange={(e) => setCurrentPinInput(e.target.value.replace(/\s+/g, ''))}
                        placeholder="Enter current PIN (e.g. 1234)"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-sm tracking-widest focus:outline-hidden focus:border-cyan-400"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCurrentPin(!showCurrentPin)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                      >
                        {showCurrentPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* New PIN & Confirm PIN */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div className="space-y-1">
                      <label className="text-[11px] font-medium text-slate-300 flex items-center justify-between">
                        <span>New 4-Digit PIN *</span>
                      </label>
                      <div className="relative">
                        <input
                          type={showNewPin ? 'text' : 'password'}
                          maxLength={4}
                          required
                          value={newPinInput}
                          onChange={(e) => setNewPinInput(e.target.value.replace(/\D/g, '').slice(0, 4))}
                          placeholder="4 digits (e.g. 7492)"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-sm tracking-widest focus:outline-hidden focus:border-cyan-400"
                        />
                        <button
                          type="button"
                          onClick={() => setShowNewPin(!showNewPin)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                        >
                          {showNewPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-medium text-slate-300">
                        Confirm New PIN *
                      </label>
                      <input
                        type={showNewPin ? 'text' : 'password'}
                        maxLength={4}
                        required
                        value={confirmPinInput}
                        onChange={(e) => setConfirmPinInput(e.target.value.replace(/\D/g, '').slice(0, 4))}
                        placeholder="Re-enter 4 digits"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-sm tracking-widest focus:outline-hidden focus:border-cyan-400"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs tracking-wide transition shadow-lg shadow-cyan-600/20 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Key className="w-3.5 h-3.5" />
                    <span>Save &amp; Update My Security PIN</span>
                  </button>
                </form>

                {/* Privacy & Authentication Guidelines */}
                <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 text-[11px] text-slate-400 space-y-2">
                  <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
                    <ShieldCheck className="w-4 h-4 text-cyan-400" />
                    <span>How Your Access Is Protected</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-slate-400 text-[10px] pl-1 leading-relaxed">
                    <li>
                      <strong>Confidential Earnings:</strong> Only you can see your daily wage, overtime rates, and EPF savings.
                    </li>
                    <li>
                      <strong>Coworker Privacy:</strong> You cannot see other technicians&apos; wages or live movements. Only colleagues on approved leave are visible.
                    </li>
                    <li>
                      <strong>Assigned Project Lock:</strong> Check-in is strictly verified against your designated project perimeter.
                    </li>
                    <li>
                      <strong>Forgot PIN:</strong> If you forget your PIN, your Operations Manager can reset it for you in the Command Center.
                    </li>
                  </ul>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* GPS Simulation Toolbar (Manager/Tester helper) */}
      <div className="bg-slate-900/90 border border-cyan-500/30 rounded-2xl p-3.5 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Compass className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Field GPS Simulation Tester
            </span>
          </div>
          <span className="text-[10px] font-mono text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/30">
            {userLocation.isSimulated ? 'Simulated' : 'Device GPS'}
          </span>
        </div>

        <p className="text-[11px] text-slate-400">
          Simulate being on-site or off-site to test geofencing boundaries without traveling:
        </p>

        <div className="grid grid-cols-2 gap-1.5 text-xs">
          {activeSites.slice(0, 4).map((site) => (
            <button
              key={`teleport-${site.id}`}
              onClick={() => handleTeleport(site, 25)}
              className="py-1.5 px-2 bg-slate-950 hover:bg-slate-800 border border-slate-700 rounded-lg text-slate-200 text-[11px] truncate text-left transition flex items-center gap-1.5"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span className="truncate">{site.name.split(' ')[0]} (On-Site)</span>
            </button>
          ))}
        </div>

        <div className="flex gap-2 pt-1">
          <button
            onClick={handleTeleportOffsite}
            className="flex-1 py-1.5 px-2 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 border border-rose-500/40 text-rose-300 text-[11px] font-medium transition"
          >
            ⚠️ Move 1.5km Away
          </button>
          <button
            onClick={handleUseRealGps}
            disabled={isRefreshingGps}
            className="flex-1 py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-[11px] font-medium transition flex items-center justify-center gap-1"
          >
            <RefreshCw className={`w-3 h-3 ${isRefreshingGps ? 'animate-spin' : ''}`} />
            📍 Use Real Device GPS
          </button>
        </div>

        {gpsStatusMessage && (
          <div className="text-[10px] text-cyan-300 font-mono pt-1 text-center">
            {gpsStatusMessage}
          </div>
        )}
      </div>

      {/* INDOOR / WEAK GPS FALLBACK MODAL */}
      {isIndoorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 max-w-sm w-full space-y-4 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
                  <Building className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">Indoor / Weak GPS Check-In</h3>
                  <p className="text-[10px] text-slate-400">
                    For underground vaults, shielded substations, or concrete panel rooms
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsIndoorModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handlePerformIndoorClockIn} className="space-y-3 text-xs">
              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[11px] leading-relaxed">
                ℹ️ This will record your check-in time immediately. The shift will be flagged with your indoor reason and sent to the manager portal for 1-click verification.
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Indoor Work Location / Reason *</label>
                <select
                  value={indoorReason}
                  onChange={(e) => setIndoorReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  <option value="Underground / Basement Transformer Room">
                    Underground / Basement Transformer Vault
                  </option>
                  <option value="Substation Switchgear Shielded Room">
                    Substation Switchgear Shielded Room (Faraday effect)
                  </option>
                  <option value="MCC & Generator Enclosure">
                    MCC &amp; Generator Steel Enclosure
                  </option>
                  <option value="Control Building (Thick Concrete Walls)">
                    Control Building (Thick Concrete Walls)
                  </option>
                  <option value="Device GPS Satellite Drift on Site">
                    Device GPS Satellite Drift on Site
                  </option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-medium">On-Site Supervisor / Approver *</label>
                <input
                  type="text"
                  required
                  value={indoorSupervisor}
                  onChange={(e) => setIndoorSupervisor(e.target.value)}
                  placeholder="e.g. Foreman Sharma verbal approval"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white placeholder-slate-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Work Notes / Tasks</label>
                <input
                  type="text"
                  value={indoorNotes}
                  onChange={(e) => setIndoorNotes(e.target.value)}
                  placeholder="e.g. 11kV busbar insulation testing"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white placeholder-slate-500"
                />
              </div>

              <div className="flex gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsIndoorModalOpen(false)}
                  className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold shadow-md shadow-amber-500/20"
                >
                  Submit Indoor Shift
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Mobile Leave Modal */}
      {isLeaveModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 max-w-sm w-full space-y-3 shadow-2xl text-slate-100">
            <h3 className="font-bold text-sm text-white">Submit Leave Request</h3>
            <form onSubmit={handleMobileApplyLeave} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300">Category</label>
                <select
                  value={leaveType}
                  onChange={(e) => setLeaveType(e.target.value as LeaveType)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  <option value="casual">Casual Leave</option>
                  <option value="sick">Sick Leave</option>
                  <option value="earned">Earned Leave</option>
                  <option value="unpaid">Loss of Pay</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-300">From</label>
                  <input
                    type="date"
                    value={leaveStartDate}
                    onChange={(e) => setLeaveStartDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2 py-1.5 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300">To</label>
                  <input
                    type="date"
                    value={leaveEndDate}
                    onChange={(e) => setLeaveEndDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2 py-1.5 text-white"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-slate-300">Reason</label>
                <textarea
                  rows={2}
                  required
                  value={leaveReason}
                  onChange={(e) => setLeaveReason(e.target.value)}
                  placeholder="Reason for leave"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                />
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsLeaveModalOpen(false)}
                  className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                >
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Override Warning Modal if outside fence */}
      {showOverrideModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="bg-slate-900 border border-rose-500/50 rounded-2xl p-5 max-w-sm w-full space-y-4 shadow-2xl">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
              <AlertOctagon className="w-5 h-5" />
              <span>Geofence Boundary Warning</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              You are currently <strong className="text-white">{formatDistance(distanceToTarget)}</strong> from{' '}
              <strong className="text-white">{targetSite?.name}</strong>, which exceeds the authorized{' '}
              {targetSite?.geofenceRadius}m geofence radius.
            </p>
            <p className="text-[11px] text-slate-400">
              Clocking in outside the perimeter will flag this shift on the manager dashboard with your GPS coordinates and audit timestamp.
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowOverrideModal(false)}
                className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={() => handlePerformClockIn(true)}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg shadow-rose-600/30"
              >
                Submit Flagged Shift
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
