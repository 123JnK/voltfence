import React, { useState } from 'react';
import { LeaveRequest, Employee, LeaveType, LeaveStatus } from '../types';
import {
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  Plus,
  Filter,
  UserCheck,
  AlertCircle,
  FileText,
  Search,
} from 'lucide-react';

interface LeaveManagementProps {
  leaves: LeaveRequest[];
  employees: Employee[];
  onApproveLeave: (leaveId: string, note?: string) => void;
  onRejectLeave: (leaveId: string, note?: string) => void;
  onApplyLeave: (newLeave: Omit<LeaveRequest, 'id'>) => void;
  isManagerLoggedIn: boolean;
  onRequestManagerLogin: () => void;
}

export function LeaveManagement({
  leaves,
  employees,
  onApproveLeave,
  onRejectLeave,
  onApplyLeave,
  isManagerLoggedIn,
  onRequestManagerLogin,
}: LeaveManagementProps) {
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);

  // New leave form state
  const [selectedEmpId, setSelectedEmpId] = useState(employees[0]?.id || '');
  const [leaveType, setLeaveType] = useState<LeaveType>('casual');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [reason, setReason] = useState('');

  const filteredLeaves = leaves.filter((l) => {
    if (statusFilter !== 'all' && l.status !== statusFilter) return false;
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      l.employeeName.toLowerCase().includes(term) ||
      l.employeeCode.toLowerCase().includes(term) ||
      l.reason.toLowerCase().includes(term)
    );
  });

  const pendingCount = leaves.filter((l) => l.status === 'pending').length;
  const approvedCount = leaves.filter((l) => l.status === 'approved').length;
  const todayStr = new Date().toISOString().split('T')[0];
  const onLeaveTodayCount = leaves.filter(
    (l) => l.status === 'approved' && l.startDate <= todayStr && l.endDate >= todayStr
  ).length;

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = employees.find((e) => e.id === selectedEmpId);
    if (!emp) return;

    const start = new Date(startDate).getTime();
    const end = new Date(endDate).getTime();
    const diffDays = Math.max(1, Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1);

    onApplyLeave({
      employeeId: emp.id,
      employeeName: emp.name,
      employeeCode: emp.code,
      type: leaveType,
      startDate,
      endDate,
      totalDays: diffDays,
      reason: reason.trim() || 'Medical or personal leave.',
      status: 'pending',
      appliedDate: todayStr,
    });

    setReason('');
    setIsApplyModalOpen(false);
  };

  return (
    <div className="space-y-4">
      {/* KPI Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Pending Approval
          </span>
          <div className="flex items-center gap-2 mt-1">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-2xl font-black text-amber-400 font-mono">{pendingCount}</span>
            <span className="text-xs text-slate-400">Requests</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            On Leave Today
          </span>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-2xl font-black text-white font-mono">{onLeaveTodayCount}</span>
            <span className="text-xs text-slate-400">Electricians</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Total Approved
          </span>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-2xl font-black text-emerald-400 font-mono">{approvedCount}</span>
            <span className="text-xs text-slate-400">Requests</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col justify-between">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Leave Action
          </span>
          <button
            onClick={() => setIsApplyModalOpen(true)}
            className="mt-1 w-full py-1.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20"
          >
            <Plus className="w-3.5 h-3.5" />
            Submit Leave Request
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by technician or reason..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-amber-400"
            />
          </div>

          <div className="bg-slate-950 p-1 rounded-xl border border-slate-800 flex text-xs">
            {(['all', 'pending', 'approved', 'rejected'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1 rounded-lg capitalize transition ${
                  statusFilter === st
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {!isManagerLoggedIn && (
          <div className="text-[11px] text-amber-400 bg-amber-500/10 border border-amber-500/30 px-3 py-1.5 rounded-xl flex items-center gap-2">
            <span>Approval actions require Manager Login</span>
            <button
              onClick={onRequestManagerLogin}
              className="underline font-bold hover:text-amber-300"
            >
              Login
            </button>
          </div>
        )}
      </div>

      {/* Leave Requests List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filteredLeaves.map((req) => {
          const emp = employees.find((e) => e.id === req.employeeId);

          return (
            <div
              key={req.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between shadow-md space-y-3"
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-2 pb-2.5 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-8 h-8 rounded-lg ${
                        emp?.avatarBg || 'bg-blue-600'
                      } flex items-center justify-center text-white text-xs font-bold`}
                    >
                      {req.employeeName[0]}
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-xs leading-tight">
                        {req.employeeName}
                      </h4>
                      <span className="text-[10px] font-mono text-cyan-400">
                        {req.employeeCode}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      req.status === 'approved'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : req.status === 'rejected'
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                        : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                    }`}
                  >
                    {req.status}
                  </span>
                </div>

                {/* Dates & Type */}
                <div className="pt-2 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 text-[11px] capitalize">
                      Type: <strong className="text-white">{req.type} Leave</strong>
                    </span>
                    <span className="font-mono text-amber-400 font-bold bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {req.totalDays} {req.totalDays === 1 ? 'Day' : 'Days'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-[11px] text-slate-300">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>
                      {req.startDate} {req.startDate !== req.endDate ? `to ${req.endDate}` : ''}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-400 bg-slate-950/60 p-2 rounded-xl border border-slate-800/80 italic">
                    "{req.reason}"
                  </p>

                  {req.reviewNote && (
                    <div className="text-[10px] text-slate-400 border-l-2 border-emerald-500 pl-2 mt-1">
                      <strong className="text-slate-300">Manager Note:</strong> {req.reviewNote}
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons for Manager */}
              {req.status === 'pending' && (
                <div className="pt-2 border-t border-slate-800 flex items-center gap-2">
                  {isManagerLoggedIn ? (
                    <>
                      <button
                        onClick={() => onApproveLeave(req.id, 'Approved by Operations Manager')}
                        className="flex-1 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-sm"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                      </button>
                      <button
                        onClick={() => onRejectLeave(req.id, 'Site coverage shortage')}
                        className="flex-1 py-1.5 rounded-xl bg-rose-950/60 hover:bg-rose-900 border border-rose-500/40 text-rose-300 font-bold text-xs flex items-center justify-center gap-1"
                      >
                        <XCircle className="w-3.5 h-3.5" /> Reject
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={onRequestManagerLogin}
                      className="w-full py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700 flex items-center justify-center gap-1"
                    >
                      Login as Manager to Approve
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Apply Leave Modal */}
      {isApplyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 max-w-md w-full space-y-4 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white">Apply For Leave</h3>
              <button
                onClick={() => setIsApplyModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleApplySubmit} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Select Electrician</label>
                <select
                  value={selectedEmpId}
                  onChange={(e) => setSelectedEmpId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.code}) — CL: {emp.leaveBalance?.casual || 0}, SL:{' '}
                      {emp.leaveBalance?.sick || 0}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Leave Category</label>
                <select
                  value={leaveType}
                  onChange={(e) => setLeaveType(e.target.value as LeaveType)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  <option value="casual">Casual Leave (CL)</option>
                  <option value="sick">Sick / Medical Leave (SL)</option>
                  <option value="earned">Earned / Annual Leave (EL)</option>
                  <option value="unpaid">Loss of Pay (Unpaid)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-slate-300">From Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-300">To Date</label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300">Reason / Details</label>
                <textarea
                  rows={2}
                  required
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="e.g. Fever, dental appointment, family emergency"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsApplyModalOpen(false)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
                >
                  Submit Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
