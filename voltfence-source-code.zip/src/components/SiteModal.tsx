import React, { useState, useEffect } from 'react';
import { APIProvider, Map, AdvancedMarker } from '@vis.gl/react-google-maps';
import {
  ElectricalSite,
  Employee,
  SiteCategory,
  SiteStatus,
  ProjectShiftConfig,
  EmployeeProjectRate,
} from '../types';
import { MapCircle } from './MapCircle';
import {
  X,
  MapPin,
  ShieldAlert,
  Users,
  Calendar,
  Layers,
  Crosshair,
  Compass,
  Check,
  Search,
  Satellite,
  Building,
  Info,
  Clock,
  DollarSign,
  Zap,
} from 'lucide-react';

interface SiteModalProps {
  site?: ElectricalSite | null;
  employees: Employee[];
  isOpen: boolean;
  onClose: () => void;
  onSave: (siteData: Partial<ElectricalSite>) => void;
  currentWorkerLocation?: { lat: number; lng: number };
  apiKey?: string;
}

const COMMON_HAZARDS = [
  'Arc Flash PPE Cat 4 Required',
  '11kV / Medium Voltage',
  '480V 3-Phase Live Riser',
  'Lockout/Tagout (LOTO) Mandatory',
  'Confined Switchgear Trench',
  'Emergency Backup Life-Safety Load',
  '1500V DC String Arrays',
  'Working at Heights (>10 ft)',
  'Third Rail Proximity (Transit)',
];

const QUICK_LOCATIONS = [
  { name: 'Delhi / NCR Substation', lat: 28.6139, lng: 77.209 },
  { name: 'Mumbai Industrial MIDC', lat: 19.076, lng: 72.8777 },
  { name: 'Bengaluru Tech Park', lat: 12.9716, lng: 77.5946 },
  { name: 'Hyderabad Power Grid', lat: 17.385, lng: 78.4867 },
  { name: 'San Francisco MCC', lat: 37.7749, lng: -122.4194 },
];

export function SiteModal({
  site,
  employees,
  isOpen,
  onClose,
  onSave,
  currentWorkerLocation,
  apiKey = 'AIzaSyAIDQ8nQBS2lWnuoonmT76KhECKlnzn7VI',
}: SiteModalProps) {
  if (!isOpen) return null;

  const isEditing = !!site;

  const [name, setName] = useState(site?.name || '');
  const [code, setCode] = useState(site?.code || `ELEC-ST-${Math.floor(100 + Math.random() * 900)}`);
  const [clientName, setClientName] = useState(site?.clientName || '');
  const [address, setAddress] = useState(site?.address || '');
  const [category, setCategory] = useState<SiteCategory>(site?.category || 'industrial');
  const [status, setStatus] = useState<SiteStatus>(site?.status || 'active');
  const [lat, setLat] = useState<number>(site?.location.lat || 28.6139);
  const [lng, setLng] = useState<number>(site?.location.lng || 77.209);
  const [radius, setRadius] = useState<number>(site?.geofenceRadius || 120);
  const [contactPerson, setContactPerson] = useState(site?.contactPerson || '');
  const [contactPhone, setContactPhone] = useState(site?.contactPhone || '');
  const [startDate, setStartDate] = useState(
    site?.startDate || new Date().toISOString().split('T')[0]
  );
  const [targetEndDate, setTargetEndDate] = useState(
    site?.targetEndDate ||
      new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [assignedEmployeeIds, setAssignedEmployeeIds] = useState<string[]>(
    site?.assignedEmployeeIds || []
  );
  const [hazards, setHazards] = useState<string[]>(site?.hazards || []);
  const [notes, setNotes] = useState(site?.notes || '');
  const [budgetHours, setBudgetHours] = useState(site?.estimatedBudgetHours || 160);

  // Requirement 4: Project-Specific Shift Time Slab & Overtime Start Time
  const [shiftName, setShiftName] = useState(
    site?.shiftConfig?.shiftName || 'Standard Day Shift'
  );
  const [shiftStartTime, setShiftStartTime] = useState(
    site?.shiftConfig?.shiftStartTime || '08:30'
  );
  const [shiftEndTime, setShiftEndTime] = useState(
    site?.shiftConfig?.shiftEndTime || '17:30'
  );
  const [breakMinutes, setBreakMinutes] = useState<number>(
    site?.shiftConfig?.breakMinutes || 60
  );
  const [regularShiftHours, setRegularShiftHours] = useState<number>(
    site?.shiftConfig?.regularShiftHours || 8.0
  );
  const [overtimeStartTime, setOvertimeStartTime] = useState(
    site?.shiftConfig?.overtimeStartTime || '17:30'
  );
  const [overtimeGraceMinutes, setOvertimeGraceMinutes] = useState<number>(
    site?.shiftConfig?.overtimeGraceMinutes || 15
  );

  // Requirement 5: Project-Specific Custom Hourly & Overtime Rates per Employee
  const [employeeProjectRates, setEmployeeProjectRates] = useState<
    Record<string, EmployeeProjectRate>
  >(site?.employeeProjectRates || {});

  const handleUpdateEmpRate = (
    empId: string,
    field: 'regularHourlyRate' | 'overtimeHourlyRate',
    val: number
  ) => {
    const emp = employees.find((e) => e.id === empId);
    setEmployeeProjectRates((prev) => {
      const existing = prev[empId] || {
        regularHourlyRate: emp?.regularHourlyRate || 150,
        overtimeHourlyRate: emp?.overtimeHourlyRate || 250,
        dailyWage: emp?.dailyWage || 1200,
      };
      return {
        ...prev,
        [empId]: {
          ...existing,
          [field]: val,
        },
      };
    });
  };

  // Map state
  const [mapType, setMapType] = useState<'roadmap' | 'hybrid'>('roadmap');
  const [gpsCaptureStatus, setGpsCaptureStatus] = useState<string | null>(null);
  const [isCapturingGps, setIsCapturingGps] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // If new site and current worker location is available, initialize near it
  useEffect(() => {
    if (!site && currentWorkerLocation) {
      setLat(currentWorkerLocation.lat);
      setLng(currentWorkerLocation.lng);
    }
  }, [site, currentWorkerLocation]);

  const toggleEmployee = (empId: string) => {
    setAssignedEmployeeIds((prev) =>
      prev.includes(empId) ? prev.filter((id) => id !== empId) : [...prev, empId]
    );
  };

  const toggleHazard = (hazard: string) => {
    setHazards((prev) =>
      prev.includes(hazard) ? prev.filter((h) => h !== hazard) : [...prev, hazard]
    );
  };

  // Physical On-Site GPS capture
  const handleCapturePhysicalGps = () => {
    if (!('geolocation' in navigator)) {
      setGpsCaptureStatus('❌ Hardware Geolocation not supported on this device/browser.');
      return;
    }

    setIsCapturingGps(true);
    setGpsCaptureStatus('📡 Acquiring high-precision GPS lock from satellites...');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const newLat = Number(pos.coords.latitude.toFixed(6));
        const newLng = Number(pos.coords.longitude.toFixed(6));
        const accuracy = Math.round(pos.coords.accuracy);

        setLat(newLat);
        setLng(newLng);
        setIsCapturingGps(false);
        setGpsCaptureStatus(
          `✅ High-Accuracy Physical GPS Captured! (Lat: ${newLat}, Lng: ${newLng}, Accuracy: ±${accuracy}m)`
        );
      },
      (err) => {
        setIsCapturingGps(false);
        console.warn('GPS capture error:', err);
        // Fallback to worker location if available
        if (currentWorkerLocation) {
          setLat(currentWorkerLocation.lat);
          setLng(currentWorkerLocation.lng);
          setGpsCaptureStatus('⚠️ Using current application position (±10m)');
        } else {
          setGpsCaptureStatus(`⚠️ GPS Error: ${err.message}. Please check location permission.`);
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  };

  const handleJumpToPreset = (targetLat: number, targetLng: number, presetName: string) => {
    setLat(targetLat);
    setLng(targetLng);
    setGpsCaptureStatus(`📍 Centered map on ${presetName}`);
  };

  const handleMapClick = (e: any) => {
    if (e.detail?.latLng) {
      const clickedLat = Number(e.detail.latLng.lat.toFixed(6));
      const clickedLng = Number(e.detail.latLng.lng.toFixed(6));
      setLat(clickedLat);
      setLng(clickedLng);
      setGpsCaptureStatus(`📍 Pin relocated to clicked coordinates (${clickedLat}, ${clickedLng})`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onSave({
      id: site?.id,
      name,
      code,
      clientName,
      address,
      category,
      status,
      location: { lat, lng },
      geofenceRadius: radius,
      contactPerson,
      contactPhone,
      startDate,
      targetEndDate,
      assignedEmployeeIds,
      hazards,
      notes,
      estimatedBudgetHours: Number(budgetHours) || 0,
      shiftConfig: {
        shiftName,
        shiftStartTime,
        shiftEndTime,
        breakMinutes: Number(breakMinutes) || 0,
        regularShiftHours: Number(regularShiftHours) || 8.0,
        overtimeStartTime,
        overtimeGraceMinutes: Number(overtimeGraceMinutes) || 0,
      },
      employeeProjectRates,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-3xl max-h-[94vh] flex flex-col shadow-2xl text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                {isEditing ? 'Edit Maintenance Site & Geofence' : 'Create New Electrical Work Site'}
              </h2>
              <p className="text-xs text-slate-400">
                Visual map geofencing, physical on-site GPS calibration, and technician assignments
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-6 space-y-5 text-sm">
          {/* Status banner */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/80 border border-slate-800">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Site Project Status:
            </span>
            <div className="flex gap-2">
              {(['active', 'paused', 'completed'] as SiteStatus[]).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatus(st)}
                  className={`px-3 py-1 text-xs font-semibold rounded-lg uppercase tracking-wider transition ${
                    status === st
                      ? st === 'active'
                        ? 'bg-emerald-500 text-slate-950 shadow-sm shadow-emerald-500/30'
                        : st === 'completed'
                        ? 'bg-slate-600 text-white'
                        : 'bg-amber-500 text-slate-950'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {st === 'active' ? '● Active' : st === 'completed' ? '✓ Completed' : '⏸ Paused'}
                </button>
              ))}
            </div>
          </div>

          {/* Basic Site Info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="md:col-span-2 space-y-1">
              <label className="text-xs font-medium text-slate-300">Site / Project Title *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Metro Substation 11kV Overhaul"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-white placeholder-slate-500 focus:outline-hidden focus:border-amber-400 transition"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Site Code</label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="ELEC-ST-101"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-white font-mono text-xs placeholder-slate-500 focus:outline-hidden focus:border-amber-400 transition"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Client / Facility Owner</label>
              <input
                type="text"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="e.g. Apex Industrial Power LLC"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-white placeholder-slate-500 focus:outline-hidden focus:border-amber-400 transition"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Category / Facility Type</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as SiteCategory)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-white focus:outline-hidden focus:border-amber-400 transition"
              >
                <option value="substation">Substation / Utility Power</option>
                <option value="industrial">Industrial Facility / MCCs</option>
                <option value="commercial">Commercial / Hospital / Mall</option>
                <option value="residential">Residential / High-Rise</option>
                <option value="solar_renewable">Solar &amp; Renewable Energy</option>
                <option value="municipal">Municipal / Transit</option>
              </select>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Physical Address / Street Location</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g. Plot 42, Sector 18, Industrial Area"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-white placeholder-slate-500 focus:outline-hidden focus:border-amber-400 transition"
            />
          </div>

          {/* ======================================================== */}
          {/* INTERACTIVE GOOGLE MAP & GEOFENCING SECTION              */}
          {/* ======================================================== */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-3.5 shadow-inner">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-amber-400" />
                <span className="font-bold text-white text-xs uppercase tracking-wider">
                  Interactive Geofence Boundary Map
                </span>
                <span className="text-[10px] bg-amber-500/10 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-mono">
                  {radius}m Radius Circle
                </span>
              </div>

              {/* Physical GPS Capture Button */}
              <button
                type="button"
                onClick={handleCapturePhysicalGps}
                disabled={isCapturingGps}
                className="text-xs text-slate-950 bg-amber-400 hover:bg-amber-300 font-bold px-3 py-1.5 rounded-xl transition shadow-md shadow-amber-400/20 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Crosshair className={`w-3.5 h-3.5 ${isCapturingGps ? 'animate-spin' : ''}`} />
                {isCapturingGps ? 'Locking Satellites...' : '📍 Capture Physical On-Site GPS'}
              </button>
            </div>

            {/* Explanatory helper */}
            <div className="flex items-start gap-2 text-xs bg-slate-900/90 border border-slate-800 p-2.5 rounded-xl text-slate-300">
              <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <div className="text-[11px] leading-relaxed">
                <strong className="text-white">How to position the site:</strong>
                <ul className="list-disc list-inside mt-0.5 text-slate-400 space-y-0.5">
                  <li><strong>Physical Site Visit (Highest Accuracy):</strong> Stand physically on the project site and click <span className="text-amber-300 font-medium">"Capture Physical On-Site GPS"</span> to lock the center pin with device satellite accuracy.</li>
                  <li><strong>Click or Drag on Map:</strong> Click anywhere on the map or drag the pin to position the geofence center.</li>
                </ul>
              </div>
            </div>

            {/* GPS Feedback Banner */}
            {gpsCaptureStatus && (
              <div className="text-xs p-2.5 rounded-xl bg-slate-900 border border-cyan-500/40 text-cyan-200 font-mono flex items-center justify-between">
                <span>{gpsCaptureStatus}</span>
                <button
                  type="button"
                  onClick={() => setGpsCaptureStatus(null)}
                  className="text-slate-400 hover:text-white text-xs ml-2"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Map Controls & Presets Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-slate-400">Quick Jump:</span>
                <div className="flex flex-wrap gap-1">
                  {QUICK_LOCATIONS.map((loc) => (
                    <button
                      key={loc.name}
                      type="button"
                      onClick={() => handleJumpToPreset(loc.lat, loc.lng, loc.name)}
                      className="px-2 py-0.5 rounded text-[10px] bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 transition"
                    >
                      {loc.name.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Map Type Switcher */}
              <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
                <button
                  type="button"
                  onClick={() => setMapType('roadmap')}
                  className={`px-2 py-0.5 rounded text-[10px] font-medium transition ${
                    mapType === 'roadmap'
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Roadmap
                </button>
                <button
                  type="button"
                  onClick={() => setMapType('hybrid')}
                  className={`px-2 py-0.5 rounded text-[10px] font-medium transition flex items-center gap-1 ${
                    mapType === 'hybrid'
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Satellite className="w-2.5 h-2.5" />
                  Satellite
                </button>
              </div>
            </div>

            {/* Google Map Display */}
            <div className="relative w-full h-64 rounded-2xl overflow-hidden border border-slate-800 shadow-md">
              <APIProvider apiKey={apiKey}>
                <Map
                  internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                  mapId="DEMO_MAP_ID"
                  center={{ lat, lng }}
                  zoom={16}
                  mapTypeId={mapType}
                  gestureHandling="greedy"
                  disableDefaultUI={false}
                  onClick={handleMapClick}
                  className="w-full h-full"
                  style={{ width: '100%', height: '100%' }}
                >
                  <AdvancedMarker
                    position={{ lat, lng }}
                    title={name || 'Site Center Pin'}
                  />
                  <MapCircle
                    center={{ lat, lng }}
                    radius={radius}
                    strokeColor="#f59e0b"
                    strokeWeight={2.5}
                    fillColor="#f59e0b"
                    fillOpacity={0.25}
                  />
                </Map>
              </APIProvider>

              {/* Pin indicator badge overlaid on map */}
              <div className="absolute top-2 left-2 bg-slate-950/85 backdrop-blur-xs border border-amber-500/40 px-2.5 py-1 rounded-lg text-[10px] font-mono text-amber-300 pointer-events-none shadow-md">
                📍 Pin: {lat.toFixed(5)}, {lng.toFixed(5)} (±{radius}m boundary)
              </div>
            </div>

            {/* Latitude and Longitude Exact Numbers */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Center Latitude</label>
                <input
                  type="number"
                  step="0.000001"
                  value={lat}
                  onChange={(e) => setLat(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Center Longitude</label>
                <input
                  type="number"
                  step="0.000001"
                  value={lng}
                  onChange={(e) => setLng(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                />
              </div>
            </div>

            {/* Radius Slider & Quick Radii */}
            <div className="space-y-2 pt-1 border-t border-slate-800">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-300 font-medium">Geofence Radius (Tolerance Zone):</span>
                <span className="font-mono font-bold text-amber-400 bg-amber-950/60 px-2.5 py-0.5 rounded-lg border border-amber-500/30">
                  {radius} meters ({Math.round(radius * 3.28084)} feet)
                </span>
              </div>
              <input
                type="range"
                min="30"
                max="800"
                step="10"
                value={radius}
                onChange={(e) => setRadius(parseInt(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer h-2 bg-slate-800 rounded-lg"
              />
              <div className="flex flex-wrap gap-2 pt-1">
                {[50, 80, 100, 150, 250, 400, 600].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRadius(r)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-mono border transition ${
                      radius === r
                        ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-xs'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {r}m {r <= 80 ? '(Compact)' : r === 150 ? '(Standard)' : r >= 400 ? '(Campus)' : ''}
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-slate-400 italic">
                💡 Technicians must be within {radius}m of this center pin to verify clock-in. Check-ins
                outside this circle trigger geo-mismatch flags for manager review.
              </p>
            </div>
          </div>

          {/* Project Dates & Contact */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" /> Start Date
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white focus:outline-hidden focus:border-amber-400"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" /> Target Completion Date
              </label>
              <input
                type="date"
                value={targetEndDate}
                onChange={(e) => setTargetEndDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white focus:outline-hidden focus:border-amber-400"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Site Contact / Superintendent</label>
              <input
                type="text"
                value={contactPerson}
                onChange={(e) => setContactPerson(e.target.value)}
                placeholder="e.g. Rajesh Sharma"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white focus:outline-hidden"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-slate-300">Contact Phone / Radios</label>
              <input
                type="text"
                value={contactPhone}
                onChange={(e) => setContactPhone(e.target.value)}
                placeholder="+91 98000 00000"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white focus:outline-hidden"
              />
            </div>
          </div>

          {/* Electrical Safety Hazards */}
          <div className="space-y-2">
            <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" /> Electrical Safety Hazards &amp; PPE Requirements
            </label>
            <div className="flex flex-wrap gap-1.5">
              {COMMON_HAZARDS.map((hz) => (
                <button
                  key={hz}
                  type="button"
                  onClick={() => toggleHazard(hz)}
                  className={`px-2.5 py-1 rounded-lg text-xs transition border flex items-center gap-1 ${
                    hazards.includes(hz)
                      ? 'bg-amber-500/20 border-amber-500/60 text-amber-300 font-medium'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {hazards.includes(hz) && <Check className="w-3 h-3 text-amber-400" />}
                  {hz}
                </button>
              ))}
            </div>
          </div>

          {/* Assigned Electricians from Employee Pool */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-blue-400" /> Assigned Electricians ({assignedEmployeeIds.length} selected)
              </label>
              <button
                type="button"
                onClick={() =>
                  setAssignedEmployeeIds(
                    assignedEmployeeIds.length === employees.length ? [] : employees.map((e) => e.id)
                  )
                }
                className="text-[11px] text-blue-400 hover:underline"
              >
                {assignedEmployeeIds.length === employees.length ? 'Deselect All' : 'Select All'}
              </button>
            </div>
            <div className="max-h-36 overflow-y-auto bg-slate-950 border border-slate-800 rounded-xl p-2 grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {employees.map((emp) => {
                const isSelected = assignedEmployeeIds.includes(emp.id);
                return (
                  <div
                    key={emp.id}
                    onClick={() => toggleEmployee(emp.id)}
                    className={`flex items-center gap-2 p-1.5 rounded-lg cursor-pointer text-xs transition border ${
                      isSelected
                        ? 'bg-blue-950/40 border-blue-500/40 text-blue-200'
                        : 'bg-slate-900/50 border-slate-800/80 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded flex items-center justify-center border text-[10px] ${
                        isSelected ? 'bg-blue-500 border-blue-400 text-white' : 'border-slate-600'
                      }`}
                    >
                      {isSelected && '✓'}
                    </div>
                    <div className="truncate">
                      <span className="font-medium text-slate-200">{emp.name}</span>
                      <span className="text-[10px] text-slate-500 ml-1">({emp.role.split(' ')[0]})</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* REQUIREMENT 4: Project-Specific Shift Time Slab & Overtime Start Time */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-3.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-400" />
                Project Shift Time Slab &amp; Overtime Rules
              </span>
              <span className="text-[10px] font-mono bg-amber-500/10 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded font-bold">
                Configured Per Project
              </span>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              Define the official regular working shift time window and exact time when overtime calculation starts for all technicians at this job site.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-300">Shift Name / Slab</label>
                <input
                  type="text"
                  value={shiftName}
                  onChange={(e) => setShiftName(e.target.value)}
                  placeholder="e.g. Day Shift 08:30-17:30"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white text-xs focus:border-amber-400"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-300">Shift Start Time (HH:MM)</label>
                <input
                  type="time"
                  value={shiftStartTime}
                  onChange={(e) => setShiftStartTime(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono text-xs focus:border-amber-400"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-300">Shift End Time (HH:MM)</label>
                <input
                  type="time"
                  value={shiftEndTime}
                  onChange={(e) => setShiftEndTime(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono text-xs focus:border-amber-400"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 border-t border-slate-900">
              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-300">Break / Lunch Duration (Mins)</label>
                <input
                  type="number"
                  min="0"
                  max="120"
                  step="15"
                  value={breakMinutes}
                  onChange={(e) => setBreakMinutes(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono text-xs focus:border-amber-400"
                />
                <span className="text-[10px] text-slate-500">Deducted from gross duration</span>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-300">Regular Shift Hours (Hrs)</label>
                <input
                  type="number"
                  min="4"
                  max="12"
                  step="0.5"
                  value={regularShiftHours}
                  onChange={(e) => setRegularShiftHours(parseFloat(e.target.value) || 8)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono text-xs focus:border-amber-400"
                />
                <span className="text-[10px] text-emerald-400">Regular pay rate applies up to this limit</span>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-amber-300 flex items-center justify-between">
                  <span>Overtime Start Time *</span>
                  <span className="text-[10px] text-amber-400/80 font-normal">Auto-Triggers OT</span>
                </label>
                <input
                  type="time"
                  value={overtimeStartTime}
                  onChange={(e) => setOvertimeStartTime(e.target.value)}
                  className="w-full bg-slate-900 border border-amber-500/50 rounded-xl px-3 py-1.5 text-amber-300 font-mono text-xs font-bold focus:border-amber-400"
                />
                <span className="text-[10px] text-amber-400">Hours worked past this time are logged as Overtime</span>
              </div>
            </div>
          </div>

          {/* REQUIREMENT 5: Project-Specific Regular & Overtime Rates per Employee */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-blue-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-blue-400" />
                Assign Separate Regular &amp; Overtime Rates for this Project
              </span>
              <span className="text-[10px] font-mono bg-blue-500/10 text-blue-300 border border-blue-500/30 px-2 py-0.5 rounded font-bold">
                Per-Employee Rates
              </span>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              Customize the regular hourly rate and overtime rate for each electrician working on this project (e.g. hazardous substation hazard differential):
            </p>

            {assignedEmployeeIds.length === 0 ? (
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 text-center">
                Please select assigned electricians above to configure their project-specific rates.
              </div>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {assignedEmployeeIds.map((empId) => {
                  const emp = employees.find((e) => e.id === empId);
                  if (!emp) return null;
                  const currentRates = employeeProjectRates[empId] || {
                    regularHourlyRate: emp.regularHourlyRate || 150,
                    overtimeHourlyRate: emp.overtimeHourlyRate || 250,
                  };

                  return (
                    <div
                      key={empId}
                      className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <div
                          className={`w-7 h-7 rounded-lg ${emp.avatarBg} flex items-center justify-center text-white font-bold text-[10px] shrink-0`}
                        >
                          {emp.name.split(' ').map((n) => n[0]).join('')}
                        </div>
                        <div className="truncate">
                          <div className="font-bold text-white truncate">{emp.name}</div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            {emp.code} • Global: ₹{emp.regularHourlyRate}/h reg | ₹{emp.overtimeHourlyRate}/h OT
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <div className="flex items-center gap-1">
                          <span className="text-[10px] text-slate-400">Regular:</span>
                          <div className="relative">
                            <span className="absolute left-2 top-1 text-[10px] text-slate-500">₹</span>
                            <input
                              type="number"
                              min="50"
                              step="10"
                              value={currentRates.regularHourlyRate}
                              onChange={(e) =>
                                handleUpdateEmpRate(
                                  empId,
                                  'regularHourlyRate',
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              className="w-20 pl-4 pr-1 py-1 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono text-xs focus:border-blue-400"
                            />
                          </div>
                          <span className="text-[10px] text-slate-500">/h</span>
                        </div>

                        <div className="flex items-center gap-1">
                          <span className="text-[10px] text-amber-400 font-medium">OT:</span>
                          <div className="relative">
                            <span className="absolute left-2 top-1 text-[10px] text-amber-500/70">₹</span>
                            <input
                              type="number"
                              min="50"
                              step="10"
                              value={currentRates.overtimeHourlyRate}
                              onChange={(e) =>
                                handleUpdateEmpRate(
                                  empId,
                                  'overtimeHourlyRate',
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              className="w-20 pl-4 pr-1 py-1 bg-slate-950 border border-amber-500/50 rounded-lg text-amber-300 font-mono text-xs font-bold focus:border-amber-400"
                            />
                          </div>
                          <span className="text-[10px] text-amber-400">/h</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Scope Notes */}
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Scope of Work / Special Procedures</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Busbar thermal scanning scheduled this Thursday; utility permit #882-B."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-hidden"
            />
          </div>

          {/* Footer buttons */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-300 hover:bg-slate-800 text-xs font-medium transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition shadow-lg shadow-amber-500/20"
            >
              {isEditing ? 'Save Site & Geofence Changes' : 'Create Electrical Work Site'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
