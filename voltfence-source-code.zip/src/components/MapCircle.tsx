import { useEffect, useRef } from 'react';
import { useMap } from '@vis.gl/react-google-maps';

export interface MapCircleProps {
  center: { lat: number; lng: number };
  radius: number; // in meters
  strokeColor?: string;
  strokeOpacity?: number;
  strokeWeight?: number;
  fillColor?: string;
  fillOpacity?: number;
  editable?: boolean;
  draggable?: boolean;
  onRadiusChanged?: (radius: number) => void;
  onCenterChanged?: (center: { lat: number; lng: number }) => void;
  onClick?: () => void;
}

export function MapCircle({
  center,
  radius,
  strokeColor = '#10b981',
  strokeOpacity = 0.8,
  strokeWeight = 2,
  fillColor = '#10b981',
  fillOpacity = 0.2,
  editable = false,
  draggable = false,
  onRadiusChanged,
  onCenterChanged,
  onClick,
}: MapCircleProps) {
  const map = useMap();
  const circleRef = useRef<google.maps.Circle | null>(null);

  // Initialize Circle
  useEffect(() => {
    if (!map) return;

    const circle = new google.maps.Circle({
      map,
      center,
      radius,
      strokeColor,
      strokeOpacity,
      strokeWeight,
      fillColor,
      fillOpacity,
      editable,
      draggable,
    });

    circleRef.current = circle;

    const listeners: google.maps.MapsEventListener[] = [];

    if (onClick) {
      listeners.push(circle.addListener('click', onClick));
    }

    if (onRadiusChanged) {
      listeners.push(
        circle.addListener('radius_changed', () => {
          onRadiusChanged(circle.getRadius());
        })
      );
    }

    if (onCenterChanged) {
      listeners.push(
        circle.addListener('center_changed', () => {
          const c = circle.getCenter();
          if (c) {
            onCenterChanged({ lat: c.lat(), lng: c.lng() });
          }
        })
      );
    }

    return () => {
      listeners.forEach((l) => google.maps.event.removeListener(l));
      circle.setMap(null);
      circleRef.current = null;
    };
  }, [map]);

  // Update properties if changed
  useEffect(() => {
    if (!circleRef.current) return;
    circleRef.current.setCenter(center);
    circleRef.current.setRadius(radius);
    circleRef.current.setOptions({
      strokeColor,
      strokeOpacity,
      strokeWeight,
      fillColor,
      fillOpacity,
      editable,
      draggable,
    });
  }, [center, radius, strokeColor, strokeOpacity, strokeWeight, fillColor, fillOpacity, editable, draggable]);

  return null;
}
