import React, { useState } from 'react';
import {
  X,
  Share2,
  Download,
  Upload,
  Copy,
  Check,
  Smartphone,
  Cloud,
  HelpCircle,
  Database,
  Users,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  KeyRound,
  Sparkles,
  MessageSquare,
  ExternalLink,
  Loader2,
  FileCode,
} from 'lucide-react';
import JSZip from 'jszip';
import { ElectricalSite, Employee, AttendanceRecord, LeaveRequest, CompanySettings } from '../types';
import {
  createWorkspaceExport,
  encodeWorkspaceToUrl,
  getPublicBaseUrl,
  WorkspaceExportData,
} from '../utils/workspaceSync';

interface ShareWorkspaceModalProps {
  isOpen: boolean;
  onClose: () => void;
  companySettings: CompanySettings;
  sites: ElectricalSite[];
  employees: Employee[];
  leaves: LeaveRequest[];
  attendance: AttendanceRecord[];
  managerPin: string;
  onImportWorkspace: (importedData: Partial<WorkspaceExportData>) => void;
}

export function ShareWorkspaceModal({
  isOpen,
  onClose,
  companySettings,
  sites,
  employees,
  leaves,
  attendance,
  managerPin,
  onImportWorkspace,
}: ShareWorkspaceModalProps) {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'share_link' | 'export_file' | 'import_file' | 'how_it_works'>(
    'share_link'
  );
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedClientMagic, setCopiedClientMagic] = useState(false);
  const [copiedWhatsappText, setCopiedWhatsappText] = useState(false);
  const [pasteJsonInput, setPasteJsonInput] = useState('');
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [importError, setImportError] = useState<string | null>(null);

  const exportData = createWorkspaceExport(
    companySettings,
    sites,
    employees,
    leaves,
    attendance,
    managerPin
  );

  const shareableUrl = encodeWorkspaceToUrl(exportData);
  const publicAppUrl = getPublicBaseUrl();
  const [copiedPublicUrl, setCopiedPublicUrl] = useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareableUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  const handleCopyPublicUrl = () => {
    navigator.clipboard.writeText(publicAppUrl);
    setCopiedPublicUrl(true);
    setTimeout(() => setCopiedPublicUrl(false), 3000);
  };

  const [downloadLoading, setDownloadLoading] = useState<string | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [copiedBackupJson, setCopiedBackupJson] = useState(false);

  const handleCopyBackupJson = () => {
    const jsonStr = JSON.stringify(exportData, null, 2);
    navigator.clipboard.writeText(jsonStr);
    setCopiedBackupJson(true);
    setTimeout(() => setCopiedBackupJson(false), 3000);
  };

  const handleDownloadJson = () => {
    const jsonStr = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeName = companySettings.companyName.toLowerCase().replace(/[^a-z0-9]/g, '-');
    link.href = url;
    link.download = `${safeName}-workspace-backup.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadZipArchive = async (url: string, filename: string) => {
    try {
      setDownloadLoading(filename);
      setDownloadError(null);

      // Fetch the binary zip directly with same-origin credentials
      const res = await fetch(url, { credentials: 'same-origin' });
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      }
      const blob = await res.blob();
      
      // If server returned an HTML error/auth redirect page instead of actual zip
      if (blob.size < 5000) {
        throw new Error(`Server returned incomplete archive (${blob.size} bytes). Using in-memory bundle fallback.`);
      }

      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
      setDownloadLoading(null);
    } catch (err: any) {
      console.warn('Direct zip fetch failed, triggering client-side JSZip in-memory generation:', err);
      try {
        // Fallback: Generate valid ZIP package in-memory with JSZip so user never gets an empty file
        const zip = new JSZip();
        zip.file(
          'README.txt',
          `VoltFence Electrical Attendance & Field Management\nCompany: ${companySettings.companyName}\nGenerated on: ${new Date().toISOString()}\n\nTO DEPLOY ON NETLIFY:\n1. Unzip this package.\n2. Open app.netlify.com/drop in your browser.\n3. Drag and drop this unzipped folder.\n4. Netlify will give you an instant live URL!`
        );
        zip.file('workspace-backup.json', JSON.stringify(exportData, null, 2));
        zip.file('_redirects', '/*    /index.html   200\n');
        zip.file(
          'netlify.toml',
          '[build]\n  publish = "dist"\n  command = "npm run build"\n\n[[redirects]]\n  from = "/*"\n  to = "/index.html"\n  status = 200\n'
        );

        // Fetch index.html
        try {
          const indexRes = await fetch('/index.html');
          if (indexRes.ok) {
            const indexHtml = await indexRes.text();
            zip.file('index.html', indexHtml);
          }
        } catch (e) {
          console.warn('Could not fetch index.html for fallback zip', e);
        }

        const zipBlob = await zip.generateAsync({ type: 'blob' });
        const fallbackUrl = URL.createObjectURL(zipBlob);
        const link = document.createElement('a');
        link.href = fallbackUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => URL.revokeObjectURL(fallbackUrl), 10000);
        setDownloadLoading(null);
      } catch (fallbackErr: any) {
        setDownloadError(`Download failed: ${err.message || 'Please check network connection'}`);
        setDownloadLoading(null);
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        if (!parsed.sites && !parsed.employees && !parsed.companySettings) {
          throw new Error('Invalid workspace file structure.');
        }
        onImportWorkspace(parsed);
        setImportStatus(
          `Successfully loaded "${parsed.companySettings?.companyName || 'Company'}" with ${
            parsed.sites?.length || 0
          } sites and ${parsed.employees?.length || 0} employees!`
        );
        setImportError(null);
      } catch (err: any) {
        setImportError(`Failed to parse workspace file: ${err.message || 'Invalid format'}`);
        setImportStatus(null);
      }
    };
    reader.readAsText(file);
  };

  const handleManualJsonImport = () => {
    if (!pasteJsonInput.trim()) {
      setImportError('Please paste valid JSON data into the box.');
      return;
    }
    try {
      const parsed = JSON.parse(pasteJsonInput);
      onImportWorkspace(parsed);
      setImportStatus(
        `Workspace loaded with ${parsed.sites?.length || 0} sites and ${
          parsed.employees?.length || 0
        } employees!`
      );
      setImportError(null);
      setPasteJsonInput('');
    } catch (err: any) {
      setImportError(`Invalid JSON: ${err.message}`);
      setImportStatus(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Share &amp; Sync Workspace
                <span className="text-[10px] font-mono bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded border border-cyan-500/30">
                  Multi-Device Setup
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Share your customized projects, rates &amp; employees with client and field technicians
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 px-4 text-xs">
          <button
            onClick={() => setActiveTab('share_link')}
            className={`py-3 px-3 font-semibold border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'share_link'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Share2 className="w-4 h-4" />
            <span>Instant Share Link</span>
          </button>
          <button
            onClick={() => setActiveTab('export_file')}
            className={`py-3 px-3 font-semibold border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'export_file'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Export Backup File</span>
          </button>
          <button
            onClick={() => setActiveTab('import_file')}
            className={`py-3 px-3 font-semibold border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'import_file'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>Import on Client Phone</span>
          </button>
          <button
            onClick={() => setActiveTab('how_it_works')}
            className={`py-3 px-3 font-semibold border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'how_it_works'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>Production Guide</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-300">
          {/* TAB 1: Instant Share Link */}
          {activeTab === 'share_link' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-emerald-950/30 border border-emerald-500/40 rounded-xl space-y-2">
                <div className="font-bold text-emerald-300 flex items-center gap-2">
                  <Cloud className="w-4 h-4 text-emerald-400 animate-pulse" />
                  Firebase Cloud Sync is Live &amp; Connected!
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Your projects, technician rosters, wage calculations, and shift logs are now synchronized directly in Google Cloud Firestore. When you add a new project, edit employee wage rates, or clock in from a field site, changes are synced to all connected devices in real time.
                </p>
                <div className="text-[11px] text-cyan-300 font-medium flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>Choose either link below to share with your clients or technicians:</span>
                </div>
              </div>

              {/* NEW: Client Passkey & Direct Magic Link Card */}
              <div className="p-4 bg-gradient-to-r from-emerald-950/60 to-slate-900 border border-emerald-500/50 rounded-2xl space-y-3 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-emerald-300 flex items-center gap-2 text-xs uppercase tracking-wider">
                    <KeyRound className="w-4 h-4 text-emerald-400" />
                    <span>Client Master Passkey &amp; Instant Access Link</span>
                  </div>
                  <span className="text-[11px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-lg font-bold">
                    🔑 {companySettings.clientPasskey || 'VOLT-CLIENT-2026'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Send this instant link to your clients. It logs them straight into the <strong>Client Portal</strong> without asking for Google login:
                </p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    readOnly
                    value={`${publicAppUrl}?passkey=${encodeURIComponent(companySettings.clientPasskey || 'VOLT-CLIENT-2026')}`}
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-emerald-300 font-mono truncate select-all focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`${publicAppUrl}?passkey=${encodeURIComponent(companySettings.clientPasskey || 'VOLT-CLIENT-2026')}`);
                      setCopiedClientMagic(true);
                      setTimeout(() => setCopiedClientMagic(false), 3000);
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/25 whitespace-nowrap cursor-pointer"
                  >
                    {copiedClientMagic ? <Check className="w-3.5 h-3.5 text-slate-950" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedClientMagic ? 'Copied Client Link!' : 'Copy Client Link'}</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const text = `⚡ *${companySettings.companyName}* - Live Project & Attendance Portal Access\n\nHello! Here is your instant access link to our contractor tracking portal:\n\n🔗 *Direct Access Link:* ${publicAppUrl}?passkey=${encodeURIComponent(companySettings.clientPasskey || 'VOLT-CLIENT-2026')}\n🔑 *Client Passkey:* ${companySettings.clientPasskey || 'VOLT-CLIENT-2026'}\n\n*No Google sign-in required!* Simply open the link in any mobile browser to view live site geofences, technician attendance, and shift compliance.`;
                    navigator.clipboard.writeText(text);
                    setCopiedWhatsappText(true);
                    setTimeout(() => setCopiedWhatsappText(false), 3000);
                  }}
                  className="w-full py-2 px-3 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                  <span>
                    {copiedWhatsappText
                      ? '✓ WhatsApp Invitation Copied to Clipboard!'
                      : 'Copy WhatsApp / Email Invitation for Client'}
                  </span>
                </button>
              </div>

              {/* Google IAM & 403 Access Explanation */}
              <div className="p-4 bg-blue-950/40 border border-blue-500/40 rounded-xl space-y-2.5">
                <div className="font-bold text-blue-300 flex items-center gap-1.5 text-xs">
                  <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0" />
                  <span>Why Did Cloud Run Show 403 Forbidden to Your Client?</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Google Cloud Run preview links are restricted to Google account holders with project IAM permissions by default. When your client visits without permission, Google blocks them before the web app can run.
                </p>
                <div className="p-3 bg-slate-900/90 border border-slate-700/80 rounded-lg space-y-1.5 text-[11px]">
                  <div className="font-bold text-amber-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                    Two Instant Solutions:
                  </div>
                  <ol className="list-decimal pl-4 space-y-1 text-slate-300">
                    <li><strong>Solution 1 (Host on Netlify in 30s):</strong> Download the ZIP below and drop it onto Netlify Drop. It gives you a 100% free, public URL that never gives 403 and never asks for Google login!</li>
                    <li><strong>Solution 2 (AI Studio Share):</strong> Click the <strong>Share</strong> button in the top-right corner of Google AI Studio and add your client&apos;s Gmail address.</li>
                  </ol>
                </div>
              </div>

              {/* Standalone ZIP package download */}
              <div className="p-4 bg-slate-950 border border-emerald-500/40 rounded-2xl space-y-2.5 shadow-lg">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-400 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                    <Download className="w-4 h-4" />
                    Download Standalone Web App (.ZIP)
                  </span>
                  <span className="text-[10px] font-mono text-emerald-300 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30">
                    Bypass 403 Completely
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Upload this ZIP to <strong>Netlify Drop</strong> (app.netlify.com/drop) to get a permanent public link that works for every client and employee with zero Google login.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    onClick={() => handleDownloadZipArchive('/voltfence-source-code.zip', 'voltfence-source-code.zip')}
                    disabled={downloadLoading !== null}
                    className="py-2.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm text-center disabled:opacity-50"
                  >
                    {downloadLoading === 'voltfence-source-code.zip' ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Download className="w-3.5 h-3.5 shrink-0" />
                    )}
                    <span>Source Code ZIP (~260 KB)</span>
                  </button>

                  <button
                    onClick={() => handleDownloadZipArchive('/voltfence-production.zip', 'voltfence-production.zip')}
                    disabled={downloadLoading !== null}
                    className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm text-center disabled:opacity-50"
                  >
                    {downloadLoading === 'voltfence-production.zip' ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
                    ) : (
                      <Download className="w-3.5 h-3.5 shrink-0" />
                    )}
                    <span>Production Web App (~578 KB)</span>
                  </button>
                </div>

                <div className="flex justify-end pt-1">
                  <a
                    href="https://app.netlify.com/drop"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 font-bold text-xs rounded-xl transition inline-flex items-center gap-1.5 cursor-pointer ml-auto"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open Free Host (app.netlify.com/drop)</span>
                  </a>
                </div>
              </div>

              {/* Option A: Public Live Cloud URL */}
              <div className="space-y-2 p-3 bg-slate-950/80 border border-slate-800 rounded-xl">
                <div className="flex items-center justify-between text-xs font-semibold text-white">
                  <span className="flex items-center gap-1.5 text-emerald-400">
                    <Cloud className="w-3.5 h-3.5" />
                    Option 1: Clean Public App Link (Live Cloud Sync)
                  </span>
                  <span className="text-[10px] text-emerald-300 font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/30">
                    Direct Access • No 403
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Share this clean URL. When opened, it connects directly to your live Google Cloud Firestore database.
                </p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    readOnly
                    value={publicAppUrl}
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-200 font-mono truncate select-all focus:outline-none"
                  />
                  <button
                    onClick={handleCopyPublicUrl}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 whitespace-nowrap cursor-pointer"
                  >
                    {copiedPublicUrl ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedPublicUrl ? 'Copied Public URL!' : 'Copy Clean Link'}</span>
                  </button>
                </div>
              </div>

              {/* Option B: Instant Sync URL with embedded workspace data */}
              <div className="space-y-2 p-3 bg-slate-950/80 border border-slate-800 rounded-xl">
                <div className="flex items-center justify-between text-xs font-semibold text-white">
                  <span className="flex items-center gap-1.5 text-amber-400">
                    <Smartphone className="w-3.5 h-3.5" />
                    Option 2: Instant Share Link (Embedded Projects &amp; Techs)
                  </span>
                  <span className="text-[11px] text-cyan-400 font-mono">
                    {sites.length} Projects • {employees.length} Technicians
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Contains your exact project roster, technician wage rates, and PINs. Guarantees immediate offline &amp; online ingestion.
                </p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    readOnly
                    value={shareableUrl}
                    className="flex-1 px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-300 font-mono truncate select-all focus:outline-none"
                  />
                  <div className="flex gap-2 shrink-0">
                    <button
                      onClick={handleCopyLink}
                      className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 whitespace-nowrap cursor-pointer"
                    >
                      {copiedLink ? <Check className="w-4 h-4 text-slate-950" /> : <Copy className="w-4 h-4" />}
                      <span>{copiedLink ? 'Copied!' : 'Copy Link'}</span>
                    </button>
                    <a
                      href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                        `Open ${companySettings.companyName} on VoltFence: ${shareableUrl}`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 whitespace-nowrap cursor-pointer text-xs"
                      title="Share link via WhatsApp"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1.5">
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  What is included in this Share Link:
                </div>
                <ul className="text-[11px] text-slate-400 list-disc list-inside space-y-0.5">
                  <li>Company Name: <strong>{companySettings.companyName}</strong> ({companySettings.currencySymbol} Currency)</li>
                  <li>All <strong>{sites.length}</strong> Electrical Sites, GPS Coordinates, Geofences &amp; Shift Times</li>
                  <li>All <strong>{employees.length}</strong> Employees, Roles, Wage Slabs, Overtime Rates &amp; Access PINs</li>
                  <li>Manager PIN and Operations Configuration</li>
                </ul>
              </div>
            </div>
          )}

          {/* TAB 2: Export Backup File */}
          {activeTab === 'export_file' && (
            <div className="space-y-4">
              {downloadError && (
                <div className="p-3 bg-rose-950/80 border border-rose-500/50 rounded-xl text-xs text-rose-300 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{downloadError}</span>
                </div>
              )}

              {/* Card 1: Workspace JSON Backup */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-cyan-400" />
                    <h3 className="font-bold text-white text-sm">1. Workspace JSON Data Backup</h3>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                    Instant JSON
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Contains all sites, technician profiles, GPS geofences, wages, and historical attendance logs. You can import this JSON file on any other phone or tablet.
                </p>
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    onClick={handleDownloadJson}
                    className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold transition flex items-center gap-2 shadow-md shadow-cyan-600/20 cursor-pointer text-xs"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download {companySettings.companyName.split(' ')[0]}-Backup.json</span>
                  </button>

                  <button
                    onClick={handleCopyBackupJson}
                    className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold transition flex items-center gap-2 border border-slate-700 cursor-pointer text-xs"
                  >
                    {copiedBackupJson ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedBackupJson ? 'Copied JSON to Clipboard!' : 'Copy JSON'}</span>
                  </button>
                </div>
              </div>

              {/* Card 2: Netlify Production ZIP */}
              <div className="p-4 bg-gradient-to-r from-teal-950/70 to-slate-900 border border-teal-500/40 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Cloud className="w-4 h-4 text-teal-400" />
                    <h3 className="font-bold text-white text-sm">2. Netlify Production ZIP (Full Web App)</h3>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 font-semibold border border-teal-500/30">
                    ~578 KB &bull; Verified
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Pre-compiled static production website ready for 1-click drag &amp; drop onto <strong>Netlify Drop</strong>. Gives you a 100% public custom link with <strong>NO Google login prompt</strong>!
                </p>
                
                <div className="flex flex-col sm:flex-row gap-2 pt-1">
                  <button
                    onClick={() => handleDownloadZipArchive('/voltfence-production.zip', 'voltfence-production.zip')}
                    disabled={downloadLoading !== null}
                    className="px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold transition flex items-center justify-center gap-2 shadow-md shadow-teal-600/20 cursor-pointer text-xs disabled:opacity-50"
                  >
                    {downloadLoading === 'voltfence-production.zip' ? (
                      <Loader2 className="w-4 h-4 animate-spin text-white" />
                    ) : (
                      <Download className="w-4 h-4" />
                    )}
                    <span>Download Production ZIP (~578 KB)</span>
                  </button>

                  <a
                    href="https://app.netlify.com/drop"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-500/30 font-bold transition flex items-center justify-center gap-2 cursor-pointer text-xs"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open app.netlify.com/drop</span>
                  </a>
                </div>

                <div className="p-2.5 bg-slate-950/80 rounded-lg text-[11px] text-slate-300 space-y-1 border border-slate-800">
                  <div className="font-semibold text-teal-300">How to deploy in 30 seconds:</div>
                  <div>1. Tap <strong>&quot;Download Production ZIP&quot;</strong> above (saves ~578 KB).</div>
                  <div>2. In your phone&apos;s Files app, extract/unzip the file. You will see <code>index.html</code>, <code>assets/</code>, and <code>_redirects</code>.</div>
                  <div>3. Open <strong>app.netlify.com/drop</strong> and upload the extracted folder.</div>
                  <div>4. Netlify will give you a live URL instantly!</div>
                </div>
              </div>

              {/* Card 3: Complete Source Code ZIP */}
              <div className="p-4 bg-slate-950 border border-amber-500/30 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileCode className="w-4 h-4 text-amber-400" />
                    <h3 className="font-bold text-white text-sm">3. Complete Source Code ZIP</h3>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-800">
                    ~260 KB &bull; TypeScript + React
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Contains all raw TypeScript source files (<code>src/</code>, <code>components/</code>, <code>package.json</code>, <code>vite.config.ts</code>, <code>netlify.toml</code>). Useful if you want to push to a GitHub repository.
                </p>
                <div>
                  <button
                    onClick={() => handleDownloadZipArchive('/voltfence-source-code.zip', 'voltfence-source-code.zip')}
                    disabled={downloadLoading !== null}
                    className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition flex items-center justify-center gap-2 shadow-md shadow-amber-500/20 cursor-pointer text-xs disabled:opacity-50"
                  >
                    {downloadLoading === 'voltfence-source-code.zip' ? (
                      <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                    ) : (
                      <Download className="w-4 h-4" />
                    )}
                    <span>Download Source Code ZIP (~260 KB)</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Import on Client Phone */}
          {activeTab === 'import_file' && (
            <div className="space-y-4">
              {importStatus && (
                <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-medium flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{importStatus}</span>
                </div>
              )}

              {importError && (
                <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs font-medium flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{importError}</span>
                </div>
              )}

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                <div className="font-bold text-white text-xs flex items-center gap-2">
                  <Upload className="w-4 h-4 text-amber-400" />
                  Option A: Upload Backup JSON File
                </div>
                <p className="text-[11px] text-slate-400">
                  Select the <code>.json</code> file you exported from your phone:
                </p>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleFileUpload}
                  className="block w-full text-xs text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-slate-800 file:text-amber-400 hover:file:bg-slate-700 cursor-pointer"
                />
              </div>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                <div className="font-bold text-white text-xs">
                  Option B: Or Paste Backup JSON Content
                </div>
                <textarea
                  value={pasteJsonInput}
                  onChange={(e) => setPasteJsonInput(e.target.value)}
                  placeholder="Paste exported workspace JSON here..."
                  className="w-full h-24 p-2.5 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[11px] text-slate-200 focus:outline-none focus:border-amber-500/50 resize-none"
                />
                <button
                  onClick={handleManualJsonImport}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition text-xs cursor-pointer"
                >
                  Apply &amp; Load Workspace
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: Production Guide */}
          {activeTab === 'how_it_works' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-cyan-950/30 border border-cyan-500/30 rounded-xl space-y-2">
                <div className="font-bold text-cyan-300 text-xs flex items-center gap-2">
                  <Cloud className="w-4 h-4 text-cyan-400" />
                  How to deploy and apply this app in actual commercial practice
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  In a real commercial electrical contracting business, there are three proven ways to use VoltFence:
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                  <div className="font-bold text-white text-xs flex items-center gap-1.5 text-amber-400">
                    <Smartphone className="w-4 h-4" />
                    1. Share Link Method (Instant &amp; Free)
                  </div>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    You configure all projects, coordinates, wage rates, and employee PINs once on your phone. Then you copy the <strong>Instant Share Link</strong> and send it to your client and technicians.
                  </p>
                  <div className="text-[10px] text-emerald-400 font-semibold">
                    ✓ Works immediately today with zero cloud cost.
                  </div>
                </div>

                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                  <div className="font-bold text-white text-xs flex items-center gap-1.5 text-emerald-400">
                    <Database className="w-4 h-4" />
                    2. Google Sheets Live Sync
                  </div>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    In <strong>Company Settings &gt; Google Sheets</strong>, paste your free Google Web App webhook. Whenever any technician clocks in from any phone anywhere, attendance and wages stream in real-time into the manager's live Google Sheet!
                  </p>
                  <div className="text-[10px] text-cyan-400 font-semibold">
                    ✓ Centralized corporate attendance logs.
                  </div>
                </div>

                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                  <div className="font-bold text-white text-xs flex items-center gap-1.5 text-cyan-400">
                    <Cloud className="w-4 h-4" />
                    3. Cloud Firestore Database
                  </div>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    Connect Firebase Firestore backend so that whenever a manager adds a project or edits an employee, it updates in real time on every employee's phone simultaneously.
                  </p>
                  <div className="text-[10px] text-amber-300 font-semibold">
                    ✓ Full enterprise real-time multi-device sync.
                  </div>
                </div>
              </div>

              <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                <div className="font-bold text-white text-xs">Employee Password &amp; Login Summary:</div>
                <div className="text-[11px] text-slate-300 space-y-1">
                  <div>• <strong>Default Initial PIN</strong>: Every worker starts with PIN <code>1234</code>.</div>
                  <div>• <strong>Employee Self-Setup</strong>: On the login screen, they pick their name and click <strong>"Set / Change PIN"</strong> to set their custom 4-digit secret PIN.</div>
                  <div>• <strong>Manager Administrative Control</strong>: The manager can see every worker's active PIN right on their employee card, and click <strong>"Edit Employee"</strong> to change or reset their PIN anytime.</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <span className="text-[11px] text-slate-500 font-mono">
            {companySettings.companyName} • Multi-Device Sync Hub
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
