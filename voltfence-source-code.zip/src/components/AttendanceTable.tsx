import React, { useState } from 'react';
import { AttendanceRecord, ElectricalSite, Employee, CompanySettings } from '../types';
import { downloadCSV, formatDuration } from '../utils/geo';
import { syncBatchToGoogleSheet } from '../utils/googleSheets';
import { ExportPayrollModal } from './ExportPayrollModal';
import { getStandardPayPeriods, exportAttendancePayrollCSV } from '../utils/payrollReport';
import {
  FileText,
  Download,
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ShieldCheck,
  MapPin,
  Calendar,
  Filter,
  FileSpreadsheet,
  Check,
  Plus,
  Trash2,
  UserCheck,
  X,
  Radio,
  Building,
} from 'lucide-react';

interface AttendanceTableProps {
  records: AttendanceRecord[];
  sites: ElectricalSite[];
  employees: Employee[];
  companySettings?: CompanySettings;
  onOpenSettings?: () => void;
  onVerifyRecord?: (recordId: string) => void;
  onAddManualRecord?: (record: AttendanceRecord) => void;
  onDeleteRecord?: (recordId: string) => void;
}

export function AttendanceTable({
  records,
  sites,
  employees,
  companySettings,
  onOpenSettings,
  onVerifyRecord,
  onAddManualRecord,
  onDeleteRecord,
}: AttendanceTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [siteFilter, setSiteFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'verified' | 'flagged'>('all');

  // Manual Time Entry Modal state
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [manualEmpId, setManualEmpId] = useState(employees[0]?.id || '');
  const [manualSiteId, setManualSiteId] = useState(sites[0]?.id || '');
  const [manualDate, setManualDate] = useState(new Date().toISOString().split('T')[0]);
  const [manualCheckInTime, setManualCheckInTime] = useState('08:30');
  const [manualCheckOutTime, setManualCheckOutTime] = useState('17:00');
  const [manualReason, setManualReason] = useState('Indoor Substation Shift (GPS blocked by concrete/faraday walls)');
  const [manualSupervisor, setManualSupervisor] = useState('Field Supervisor Approved');

  // Full Attendance & Payroll Export Modal state
  const [isPayrollModalOpen, setIsPayrollModalOpen] = useState(false);
  const standardPeriods = getStandardPayPeriods();
  const currentPayPeriod = standardPeriods[0];

  const filteredRecords = records.filter((rec) => {
    if (siteFilter !== 'all' && rec.siteId !== siteFilter) return false;
    if (statusFilter === 'verified' && !rec.geofenceVerified) return false;
    if (statusFilter === 'flagged' && rec.geofenceVerified) return false;

    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      rec.employeeName.toLowerCase().includes(term) ||
      rec.siteName.toLowerCase().includes(term) ||
      (rec.taskDescription && rec.taskDescription.toLowerCase().includes(term)) ||
      (rec.deviceNotes && rec.deviceNotes.toLowerCase().includes(term))
    );
  });

  // Calculate compliance stats
  const totalRecords = records.length;
  const verifiedCount = records.filter((r) => r.geofenceVerified).length;
  const complianceRate = totalRecords > 0 ? Math.round((verifiedCount / totalRecords) * 100) : 100;
  const activeNowCount = records.filter((r) => r.status === 'active_shift').length;
  const flaggedCount = records.filter((r) => !r.geofenceVerified).length;

  const handleExportCSV = () => {
    const headers = [
      'Log ID',
      'Employee Name',
      'Site Name',
      'Date',
      'Check-In Time',
      'Check-Out Time',
      'Distance from Site Center (m)',
      'Geofence Verified',
      'Status',
      'PPE Confirmed',
      'Task Notes',
      'Device Specs / GPS Resolution',
    ];

    const rows = filteredRecords.map((r) => [
      r.id,
      r.employeeName,
      r.siteName,
      r.date,
      new Date(r.checkInTime).toLocaleTimeString(),
      r.checkOutTime ? new Date(r.checkOutTime).toLocaleTimeString() : 'In Progress',
      r.checkInDistanceMeters.toString(),
      r.geofenceVerified ? 'YES' : 'NO (FLAGGED/OVERRIDE)',
      r.status,
      r.ppeConfirmed ? 'YES' : 'NO',
      r.taskDescription || '',
      r.deviceNotes || '',
    ]);

    downloadCSV(`VoltFence_Attendance_${new Date().toISOString().split('T')[0]}.csv`, [
      headers,
      ...rows,
    ]);
  };

  const handleCreateManualEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onAddManualRecord) return;

    const emp = employees.find((e) => e.id === manualEmpId) || employees[0];
    const targetSite = sites.find((s) => s.id === manualSiteId) || sites[0];

    const checkInDateTime = new Date(`${manualDate}T${manualCheckInTime}:00`).toISOString();
    const checkOutDateTime = manualCheckOutTime
      ? new Date(`${manualDate}T${manualCheckOutTime}:00`).toISOString()
      : undefined;

    const startMs = new Date(checkInDateTime).getTime();
    const endMs = checkOutDateTime ? new Date(checkOutDateTime).getTime() : startMs;
    const durationMinutes = Math.max(0, Math.round((endMs - startMs) / 60000));

    const newRecord: AttendanceRecord = {
      id: `manual-${Date.now()}`,
      employeeId: emp.id,
      employeeName: emp.name,
      siteId: targetSite.id,
      siteName: targetSite.name,
      date: manualDate,
      checkInTime: checkInDateTime,
      checkOutTime: checkOutDateTime,
      checkInCoords: targetSite.location,
      checkInDistanceMeters: 0,
      geofenceVerified: true, // Marked verified by manager
      status: checkOutDateTime ? 'completed' : 'active_shift',
      ppeConfirmed: true,
      taskDescription: manualReason,
      durationMinutes,
      deviceNotes: `Manual Entry / GPS Fallback: ${manualSupervisor}`,
    };

    onAddManualRecord(newRecord);
    setIsManualModalOpen(false);
  };

  return (
    <div className="space-y-4">
      {/* KPI Stats Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Currently Clocked In
          </span>
          <div className="flex items-center gap-2 mt-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-2xl font-black text-white font-mono">{activeNowCount}</span>
            <span className="text-xs text-slate-400">/ {employees.length} Techs</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Geofence Compliance
          </span>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-2xl font-black text-emerald-400 font-mono">
              {complianceRate}%
            </span>
            <span className="text-xs text-slate-400">Verified</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Flagged / Weak GPS Shifts
          </span>
          <div className="flex items-center gap-2 mt-1">
            <span className={`text-2xl font-black font-mono ${flaggedCount > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
              {flaggedCount}
            </span>
            <span className="text-xs text-slate-400">Need Review</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Total Shifts Recorded
          </span>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-2xl font-black text-cyan-400 font-mono">
              {records.length}
            </span>
            <span className="text-xs text-slate-400">Logs</span>
          </div>
        </div>
      </div>

      {/* Filter and Export Toolbar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full sm:w-auto">
          {/* Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search technician, site, notes..."
              className="bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-amber-400 w-full sm:w-60"
            />
          </div>

          {/* Site Filter */}
          <select
            value={siteFilter}
            onChange={(e) => setSiteFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-hidden focus:border-amber-400"
          >
            <option value="all">All Sites ({sites.length})</option>
            {sites.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-hidden focus:border-amber-400"
          >
            <option value="all">All Geofence Statuses</option>
            <option value="verified">Verified Inside Geofence Only</option>
            <option value="flagged">Flagged / Indoor / Weak GPS Shifts</option>
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-end sm:self-auto">
          {/* Export Full Attendance & Payroll Report Button */}
          <button
            onClick={() => setIsPayrollModalOpen(true)}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer"
            title="Export full attendance and payroll report for current pay period as CSV"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-100" />
            <span>Export Payroll CSV</span>
            <span className="hidden sm:inline px-1.5 py-0.5 rounded text-[10px] bg-black/25 text-emerald-100 font-mono">
              Pay Period: {currentPayPeriod.label.replace('Current Month (', '').replace(')', '')}
            </span>
          </button>

          {/* Add Manual Shift Entry Button */}
          {onAddManualRecord && (
            <button
              onClick={() => setIsManualModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-amber-500/20 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Manual Shift
            </button>
          )}

          <button
            onClick={handleExportCSV}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition flex items-center gap-1.5 border border-slate-700 cursor-pointer"
            title="Export raw shift logs as basic CSV"
          >
            <Download className="w-3.5 h-3.5 text-slate-400" />
            <span className="hidden sm:inline">Raw</span> Logs CSV
          </button>
        </div>
      </div>

      {/* Attendance Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-[10px] uppercase font-bold tracking-wider text-slate-400">
              <tr>
                <th className="py-3 px-4">Technician</th>
                <th className="py-3 px-4">Work Site</th>
                <th className="py-3 px-4">Time &amp; Duration</th>
                <th className="py-3 px-4">Geofence Status &amp; Accuracy</th>
                <th className="py-3 px-4">Safety PPE</th>
                <th className="py-3 px-4">Field Task &amp; Audit Notes</th>
                <th className="py-3 px-4 text-right">Manager Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {filteredRecords.map((record) => {
                const isIndoorOrWeak =
                  record.deviceNotes?.toLowerCase().includes('indoor') ||
                  record.deviceNotes?.toLowerCase().includes('manual') ||
                  record.deviceNotes?.toLowerCase().includes('override');

                return (
                  <tr key={record.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4">
                      <div className="font-bold text-white leading-tight">
                        {record.employeeName}
                      </div>
                      <span className="text-[10px] font-mono text-slate-400">
                        {record.employeeId}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-200 truncate max-w-[180px]">
                        {record.siteName}
                      </div>
                      <span className="text-[10px] text-amber-400/80 font-mono">
                        {record.siteId}
                      </span>
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-slate-200">
                          {new Date(record.checkInTime).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                        <span className="text-slate-500">→</span>
                        {record.checkOutTime ? (
                          <span className="text-slate-200">
                            {new Date(record.checkOutTime).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold text-[10px] animate-pulse">
                            On-Site Now
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        {record.date} {record.durationMinutes ? `• ${Math.floor(record.durationMinutes / 60)}h ${record.durationMinutes % 60}m` : ''}
                      </div>
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap">
                      {record.geofenceVerified ? (
                        <div className="space-y-0.5">
                          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-[10px]">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Verified GPS ({record.checkInDistanceMeters}m from center)</span>
                          </div>
                          {record.deviceNotes?.includes('[Verified by Manager]') && (
                            <span className="block text-[9px] text-cyan-300 font-mono">
                              ✓ Manager Approved
                            </span>
                          )}
                        </div>
                      ) : (
                        <div className="space-y-0.5">
                          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 font-bold text-[10px]">
                            <AlertTriangle className="w-3 h-3" />
                            <span>{isIndoorOrWeak ? 'Indoor / Weak GPS Signal' : `Outside Fence (${record.checkInDistanceMeters}m away)`}</span>
                          </div>
                          <span className="block text-[10px] text-slate-400">
                            Pending Manager Approval
                          </span>
                        </div>
                      )}
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap">
                      {record.ppeConfirmed ? (
                        <span className="text-[11px] text-emerald-400 flex items-center gap-1">
                          <ShieldCheck className="w-3.5 h-3.5" /> Donned
                        </span>
                      ) : (
                        <span className="text-[11px] text-amber-400">Unconfirmed</span>
                      )}
                    </td>

                    <td className="py-3 px-4">
                      <p className="text-[11px] text-slate-300 max-w-[200px] truncate">
                        {record.taskDescription || 'Electrical maintenance shift.'}
                      </p>
                      <span className="text-[10px] text-slate-500 font-mono block truncate max-w-[200px]">
                        {record.deviceNotes || 'GPS ±4m'}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* 1-Click Approve / Verify Shift */}
                        {!record.geofenceVerified && onVerifyRecord && (
                          <button
                            onClick={() => onVerifyRecord(record.id)}
                            title="Verify and Approve this shift (e.g. for indoor basement work or GPS drift)"
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] transition flex items-center gap-1 shadow-sm shadow-emerald-600/30"
                          >
                            <Check className="w-3 h-3" />
                            Approve Shift
                          </button>
                        )}

                        {/* Delete Record */}
                        {onDeleteRecord && (
                          <button
                            onClick={() => onDeleteRecord(record.id)}
                            title="Delete this attendance record"
                            className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredRecords.length === 0 && (
          <div className="p-8 text-center text-slate-400 text-xs">
            No attendance records match the selected search or filters.
          </div>
        )}
      </div>

      {/* Manual Time Entry Modal (When worker phone had no GPS or battery dead) */}
      {isManualModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 max-w-md w-full space-y-4 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
                  <UserCheck className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">Add Manual Shift Entry</h3>
                  <p className="text-[11px] text-slate-400">
                    Use when technician worked indoors without GPS or had phone hardware issues
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsManualModalOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateManualEntry} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Select Electrician *</label>
                <select
                  value={manualEmpId}
                  onChange={(e) => setManualEmpId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.code}) — {emp.role.split(' ')[0]}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Project Work Site *</label>
                <select
                  value={manualSiteId}
                  onChange={(e) => setManualSiteId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                >
                  {sites.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.code})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div className="space-y-1">
                  <label className="text-slate-300">Date</label>
                  <input
                    type="date"
                    value={manualDate}
                    onChange={(e) => setManualDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-300">Clock In</label>
                  <input
                    type="time"
                    value={manualCheckInTime}
                    onChange={(e) => setManualCheckInTime(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-300">Clock Out</label>
                  <input
                    type="time"
                    value={manualCheckOutTime}
                    onChange={(e) => setManualCheckOutTime(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300">Reason / Work Performed</label>
                <input
                  type="text"
                  required
                  value={manualReason}
                  onChange={(e) => setManualReason(e.target.value)}
                  placeholder="e.g. Basement transformer maintenance; GPS blocked"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300">Supervisor / Authorizer Note</label>
                <input
                  type="text"
                  value={manualSupervisor}
                  onChange={(e) => setManualSupervisor(e.target.value)}
                  placeholder="e.g. Approved on-site by Foreman Rajesh"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500"
                />
              </div>

              <div className="flex gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsManualModalOpen(false)}
                  className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition shadow-lg shadow-amber-500/20"
                >
                  Save Verified Shift
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Full Attendance & Payroll Export Modal */}
      {isPayrollModalOpen && (
        <ExportPayrollModal
          isOpen={isPayrollModalOpen}
          onClose={() => setIsPayrollModalOpen(false)}
          records={records}
          employees={employees}
          sites={sites}
          companySettings={
            companySettings || {
              companyName: 'VoltFence Electrical Engineering',
              currencySymbol: '₹',
              currencyCode: 'INR',
              defaultEpfRate: 12,
              defaultEmployerEpfRate: 3.67,
              defaultEmployerEpsRate: 8.33,
            }
          }
        />
      )}
    </div>
  );
}
