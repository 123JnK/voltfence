import React, { useState } from 'react';
import { APIProvider, Map, AdvancedMarker, InfoWindow } from '@vis.gl/react-google-maps';
import { ElectricalSite, Employee, AttendanceRecord, UserLocation } from '../types';
import { MapCircle } from './MapCircle';
import { calculateDistanceMeters, formatDistance } from '../utils/geo';
import {
  Zap,
  Building2,
  Factory,
  Home,
  Sun,
  Layers,
  MapPin,
  CheckCircle2,
  Navigation,
  ShieldAlert,
  Users,
  Compass,
  Radio,
  Battery,
  Clock,
  LogIn,
  LogOut,
  ChevronRight,
  ChevronLeft,
  Crosshair,
  ExternalLink,
} from 'lucide-react';

interface MapViewProps {
  apiKey: string;
  sites: ElectricalSite[];
  employees: Employee[];
  attendanceRecords: AttendanceRecord[];
  userLocation: UserLocation;
  selectedSiteId: string | null;
  onSelectSite: (siteId: string | null) => void;
  onEditSite?: (site: ElectricalSite) => void;
  onSimulateAtSite: (site: ElectricalSite) => void;
  showCompletedSites?: boolean;
  onManagerCheckIn?: (employeeId: string, siteId: string) => void;
  onManagerCheckOut?: (employeeId: string) => void;
  currencySymbol?: string;
}

export function MapView({
  apiKey,
  sites,
  employees,
  attendanceRecords,
  userLocation,
  selectedSiteId,
  onSelectSite,
  onEditSite,
  onSimulateAtSite,
  showCompletedSites = true,
  onManagerCheckIn,
  onManagerCheckOut,
  currencySymbol = '₹',
}: MapViewProps) {
  const [showGeofences, setShowGeofences] = useState(true);
  const [showLiveFleet, setShowLiveFleet] = useState(true);
  const [selectedEmpId, setSelectedEmpId] = useState<string | null>(null);
  const [isFleetRadarOpen, setIsFleetRadarOpen] = useState(false);
  const [hoveredSiteId, setHoveredSiteId] = useState<string | null>(null);

  // Active records lookup
  const activeShiftMap = new globalThis.Map<string, AttendanceRecord>();
  attendanceRecords.forEach((r) => {
    if (r.status === 'active_shift') {
      activeShiftMap.set(r.employeeId, r);
    }
  });

  // Filter sites according to toggle
  const visibleSites = sites.filter((s) => (showCompletedSites ? true : s.status !== 'completed'));
  const selectedSite = sites.find((s) => s.id === selectedSiteId) || null;
  const selectedEmp = employees.find((e) => e.id === selectedEmpId) || null;

  const getSiteCategoryIcon = (category: string) => {
    switch (category) {
      case 'substation':
        return <Zap className="w-3.5 h-3.5 text-amber-400" />;
      case 'industrial':
        return <Factory className="w-3.5 h-3.5 text-blue-400" />;
      case 'commercial':
      case 'municipal':
        return <Building2 className="w-3.5 h-3.5 text-emerald-400" />;
      case 'solar_renewable':
        return <Sun className="w-3.5 h-3.5 text-yellow-400" />;
      case 'residential':
        return <Home className="w-3.5 h-3.5 text-indigo-400" />;
      default:
        return <Zap className="w-3.5 h-3.5 text-amber-400" />;
    }
  };

  const mapCenter = selectedSite
    ? selectedSite.location
    : selectedEmp?.currentLocation
    ? { lat: selectedEmp.currentLocation.lat, lng: selectedEmp.currentLocation.lng }
    : userLocation
    ? { lat: userLocation.lat, lng: userLocation.lng }
    : { lat: 28.5355, lng: 77.3910 };

  return (
    <div className="relative w-full h-full min-h-[500px] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-inner">
      <APIProvider apiKey={apiKey}>
        <Map
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          mapId="DEMO_MAP_ID"
          defaultCenter={mapCenter}
          defaultZoom={12}
          center={
            selectedSite
              ? selectedSite.location
              : selectedEmp?.currentLocation
              ? { lat: selectedEmp.currentLocation.lat, lng: selectedEmp.currentLocation.lng }
              : undefined
          }
          gestureHandling="greedy"
          disableDefaultUI={false}
          className="w-full h-full"
          style={{ width: '100%', height: '100%', minHeight: '500px' }}
        >
          {/* Geofence Circles */}
          {showGeofences &&
            visibleSites.map((site) => {
              const isSelected = site.id === selectedSiteId;
              const isCompleted = site.status === 'completed';

              const strokeColor = isSelected
                ? '#38bdf8'
                : isCompleted
                ? '#64748b'
                : site.category === 'substation'
                ? '#f59e0b'
                : '#10b981';

              const fillColor = isSelected
                ? '#38bdf8'
                : isCompleted
                ? '#475569'
                : site.category === 'substation'
                ? '#f59e0b'
                : '#10b981';

              return (
                <MapCircle
                  key={`circle-${site.id}-${site.geofenceRadius}`}
                  center={site.location}
                  radius={site.geofenceRadius}
                  strokeColor={strokeColor}
                  strokeOpacity={isSelected ? 0.95 : 0.75}
                  strokeWeight={isSelected ? 3 : 2}
                  fillColor={fillColor}
                  fillOpacity={isSelected ? 0.28 : isCompleted ? 0.08 : 0.16}
                  onClick={() => {
                    setSelectedEmpId(null);
                    onSelectSite(site.id);
                  }}
                />
              );
            })}

          {/* Project Site Markers */}
          {visibleSites.map((site) => {
            const isSelected = site.id === selectedSiteId;
            const isCompleted = site.status === 'completed';
            const activeWorkers = attendanceRecords.filter(
              (r) => r.siteId === site.id && r.status === 'active_shift'
            );

            return (
              <AdvancedMarker
                key={`site-marker-${site.id}`}
                position={site.location}
                title={site.name}
                onClick={() => {
                  setSelectedEmpId(null);
                  onSelectSite(site.id);
                }}
              >
                <div
                  className={`group relative cursor-pointer transform transition-all duration-200 ${
                    isSelected ? 'scale-110 z-30' : 'hover:scale-105 z-10'
                  }`}
                  onMouseEnter={() => setHoveredSiteId(site.id)}
                  onMouseLeave={() => setHoveredSiteId(null)}
                >
                  <div
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl shadow-lg border backdrop-blur-md transition ${
                      isSelected
                        ? 'bg-slate-900 border-sky-400 ring-2 ring-sky-400/40 text-white'
                        : isCompleted
                        ? 'bg-slate-900/90 border-slate-700 text-slate-400'
                        : 'bg-slate-900/95 border-amber-500/50 text-slate-100'
                    }`}
                  >
                    <div
                      className={`p-1 rounded-lg ${
                        isCompleted
                          ? 'bg-slate-800'
                          : isSelected
                          ? 'bg-sky-500/20 text-sky-400'
                          : 'bg-amber-500/20 text-amber-400'
                      }`}
                    >
                      {getSiteCategoryIcon(site.category)}
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[11px] font-bold leading-tight truncate max-w-[120px]">
                        {site.name}
                      </span>
                      <span className="text-[9px] font-mono text-slate-400">
                        {site.code} • {site.geofenceRadius}m fence
                      </span>
                    </div>

                    {activeWorkers.length > 0 && (
                      <span className="ml-1 px-1.5 py-0.5 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-black animate-pulse shadow-xs">
                        {activeWorkers.length}
                      </span>
                    )}
                  </div>
                  <div className="w-2 h-2 bg-slate-900 border-r border-b border-amber-500/50 rotate-45 mx-auto -mt-1" />
                </div>
              </AdvancedMarker>
            );
          })}

          {/* ==================================================================== */}
          {/* REQUIREMENT 2: LIVE LOCATION OF ALL EMPLOYEES EVEN WHEN NOT SIGNED IN */}
          {/* ==================================================================== */}
          {showLiveFleet &&
            employees
              .filter((e) => e.isActive && e.currentLocation)
              .map((emp) => {
                const isSelected = emp.id === selectedEmpId;
                const activeShift = activeShiftMap.get(emp.id);
                const isOnDuty = !!activeShift;
                const loc = emp.currentLocation!;
                const assignedSite = sites.find((s) => s.id === emp.primarySiteId);

                return (
                  <AdvancedMarker
                    key={`emp-live-${emp.id}`}
                    position={{ lat: loc.lat, lng: loc.lng }}
                    title={`${emp.name} (${isOnDuty ? 'On-Duty' : 'Off-Duty Live GPS'})`}
                    onClick={() => {
                      onSelectSite(null);
                      setSelectedEmpId(emp.id);
                    }}
                  >
                    <div
                      className={`relative cursor-pointer transition-transform duration-200 ${
                        isSelected ? 'scale-125 z-40' : 'hover:scale-110 z-20'
                      }`}
                    >
                      {/* Pulse ring if on duty */}
                      {isOnDuty && (
                        <div className="absolute -inset-1 rounded-full bg-emerald-500/40 animate-ping" />
                      )}

                      {/* Technician Avatar Marker */}
                      <div
                        className={`relative w-8 h-8 rounded-full border-2 flex items-center justify-center text-white text-[10px] font-black shadow-xl ${
                          isOnDuty
                            ? 'bg-emerald-600 border-emerald-300 ring-2 ring-emerald-400/50'
                            : 'bg-slate-800 border-amber-400/70 text-amber-200'
                        }`}
                      >
                        {emp.name
                          .split(' ')
                          .map((n) => n[0])
                          .join('')}
                      </div>

                      {/* Small Live Status Badge */}
                      <div
                        className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-slate-900 flex items-center justify-center ${
                          isOnDuty ? 'bg-emerald-400' : 'bg-amber-500'
                        }`}
                        title={isOnDuty ? 'On-Site Clocked In' : 'Off-Duty Live Ping'}
                      />

                      {/* Name Label */}
                      <div className="absolute top-9 left-1/2 -translate-x-1/2 whitespace-nowrap px-1.5 py-0.5 rounded bg-slate-950/90 border border-slate-800 text-[9px] font-mono text-slate-200 pointer-events-none shadow-md">
                        {emp.code}
                      </div>
                    </div>
                  </AdvancedMarker>
                );
              })}

          {/* Selected Site InfoWindow */}
          {selectedSite && (
            <InfoWindow
              position={selectedSite.location}
              onCloseClick={() => onSelectSite(null)}
              pixelOffset={[0, -25]}
            >
              <div className="p-1 max-w-[280px] text-slate-900">
                <div className="flex items-center justify-between pb-1 mb-1 border-b border-slate-200">
                  <span className="text-[10px] font-mono font-bold text-amber-700 uppercase">
                    {selectedSite.code} • {selectedSite.category}
                  </span>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                      selectedSite.status === 'active'
                        ? 'bg-emerald-100 text-emerald-800'
                        : selectedSite.status === 'completed'
                        ? 'bg-slate-200 text-slate-700'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {selectedSite.status}
                  </span>
                </div>

                <h3 className="font-bold text-xs text-slate-900 leading-snug">
                  {selectedSite.name}
                </h3>
                <p className="text-[11px] text-slate-600 mt-0.5">{selectedSite.clientName}</p>
                <p className="text-[10px] text-slate-500 mt-0.5 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-slate-400 shrink-0 inline" /> {selectedSite.address}
                </p>

                <div className="pt-2 border-t border-slate-200 flex flex-col gap-1.5">
                  <button
                    onClick={() => onSimulateAtSite(selectedSite)}
                    className="w-full py-1.5 px-2 rounded-lg bg-cyan-600 hover:bg-cyan-700 text-white text-[11px] font-bold flex items-center justify-center gap-1.5 shadow-xs transition"
                  >
                    <Compass className="w-3.5 h-3.5" />
                    Teleport GPS Here (Worker Mode)
                  </button>

                  {onEditSite && (
                    <button
                      onClick={() => onEditSite(selectedSite)}
                      className="w-full py-1 px-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-medium transition"
                    >
                      Edit Site &amp; Geofence Boundary
                    </button>
                  )}
                </div>
              </div>
            </InfoWindow>
          )}

          {/* ==================================================================== */}
          {/* REQUIREMENT 2 & 3: EMPLOYEE LIVE TRACKING INFOWINDOW & REMOTE OVERRIDE */}
          {/* ==================================================================== */}
          {selectedEmp && selectedEmp.currentLocation && (
            <InfoWindow
              position={{ lat: selectedEmp.currentLocation.lat, lng: selectedEmp.currentLocation.lng }}
              onCloseClick={() => setSelectedEmpId(null)}
              pixelOffset={[0, -25]}
            >
              <div className="p-1 max-w-[280px] text-slate-900">
                <div className="flex items-center justify-between pb-1 mb-1 border-b border-slate-200">
                  <span className="text-[10px] font-mono font-bold text-cyan-700 uppercase">
                    {selectedEmp.code} • {selectedEmp.role.split(' ')[0]}
                  </span>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                      activeShiftMap.has(selectedEmp.id)
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-amber-100 text-amber-800 border border-amber-300'
                    }`}
                  >
                    {activeShiftMap.has(selectedEmp.id) ? '● On-Site' : '○ Off-Duty (Live GPS)'}
                  </span>
                </div>

                <h3 className="font-bold text-sm text-slate-900 leading-snug">
                  {selectedEmp.name}
                </h3>
                <p className="text-[11px] text-slate-600">{selectedEmp.phone}</p>

                {/* Distance to Assigned Project Location */}
                {(() => {
                  const assigned = sites.find((s) => s.id === selectedEmp.primarySiteId);
                  const dist = assigned
                    ? calculateDistanceMeters(
                        selectedEmp.currentLocation!.lat,
                        selectedEmp.currentLocation!.lng,
                        assigned.location.lat,
                        assigned.location.lng
                      )
                    : null;
                  const isInsideFence = assigned && dist !== null ? dist <= assigned.geofenceRadius : false;

                  return (
                    <div className="my-2 p-2 rounded-lg bg-slate-50 border border-slate-200 text-[11px] space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-500">Assigned Project:</span>
                        <strong className="text-slate-800 truncate max-w-[140px]">
                          {assigned?.name.split(' ')[0] || 'Unassigned'}
                        </strong>
                      </div>
                      {dist !== null && (
                        <div className="flex justify-between items-center">
                          <span className="text-slate-500">Distance to Site:</span>
                          <span className={`font-mono font-bold ${isInsideFence ? 'text-emerald-700' : 'text-amber-700'}`}>
                            {formatDistance(dist)} ({isInsideFence ? 'Inside Boundary' : 'Outside Boundary'})
                          </span>
                        </div>
                      )}
                      <div className="flex justify-between items-center text-[10px] text-slate-400 pt-1 border-t border-slate-200">
                        <span>Last Ping: {selectedEmp.currentLocation?.lastPingTime || '2m ago'}</span>
                        <span>Battery: 🔋{selectedEmp.currentLocation?.battery || 85}%</span>
                      </div>
                    </div>
                  );
                })()}

                {/* REQUIREMENT 3: MANAGER REMOTE CHECK-IN / CHECK-OUT */}
                <div className="pt-1.5 border-t border-slate-200 space-y-1">
                  {activeShiftMap.has(selectedEmp.id) ? (
                    onManagerCheckOut && (
                      <button
                        onClick={() => {
                          onManagerCheckOut(selectedEmp.id);
                          setSelectedEmpId(null);
                        }}
                        className="w-full py-1.5 px-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        Remote Check-Out (Complete Shift)
                      </button>
                    )
                  ) : (
                    onManagerCheckIn && (
                      <button
                        onClick={() => {
                          const siteId = selectedEmp.primarySiteId || sites[0]?.id;
                          onManagerCheckIn(selectedEmp.id, siteId);
                          setSelectedEmpId(null);
                        }}
                        className="w-full py-1.5 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer"
                      >
                        <LogIn className="w-3.5 h-3.5" />
                        Remote Check-In (Manager Override)
                      </button>
                    )
                  )}
                </div>
              </div>
            </InfoWindow>
          )}
        </Map>
      </APIProvider>

      {/* Floating Map HUD Overlays */}
      <div className="absolute top-3 left-3 z-10 flex flex-wrap items-center gap-2">
        <button
          onClick={() => setShowGeofences(!showGeofences)}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold backdrop-blur-md border shadow-lg flex items-center gap-1.5 transition ${
            showGeofences
              ? 'bg-slate-900/90 text-amber-400 border-amber-500/40'
              : 'bg-slate-900/80 text-slate-400 border-slate-700 hover:text-white'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          {showGeofences ? 'Geofences: ON' : 'Geofences: OFF'}
        </button>

        {/* Live Fleet GPS Toggle */}
        <button
          onClick={() => setShowLiveFleet(!showLiveFleet)}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold backdrop-blur-md border shadow-lg flex items-center gap-1.5 transition ${
            showLiveFleet
              ? 'bg-slate-900/90 text-cyan-300 border-cyan-500/40'
              : 'bg-slate-900/80 text-slate-400 border-slate-700 hover:text-white'
          }`}
        >
          <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
          {showLiveFleet ? `Live Technicians GPS (${employees.filter(e => e.isActive).length})` : 'Fleet GPS: OFF'}
        </button>

        {/* Fleet Radar Drawer Trigger */}
        <button
          onClick={() => setIsFleetRadarOpen(!isFleetRadarOpen)}
          className="px-3 py-1.5 rounded-xl text-xs font-semibold backdrop-blur-md bg-slate-900/90 text-slate-200 border border-slate-700 hover:text-white shadow-lg flex items-center gap-1.5 transition"
        >
          <Users className="w-3.5 h-3.5 text-blue-400" />
          <span>Fleet Radar</span>
          {isFleetRadarOpen ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Slide-out Fleet Radar Drawer (Manager live fleet oversight) */}
      {isFleetRadarOpen && (
        <div className="absolute top-14 right-3 z-20 w-72 max-h-[420px] bg-slate-900/95 backdrop-blur-md border border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-xs">
          <div className="px-3.5 py-2.5 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
            <span className="font-bold text-white uppercase tracking-wider text-[10px] flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              Live Fleet Technician Radar
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              {employees.filter((e) => e.isActive).length} Tracked
            </span>
          </div>

          <div className="overflow-y-auto p-2 space-y-1.5 divide-y divide-slate-800/40">
            {employees
              .filter((e) => e.isActive)
              .map((emp) => {
                const activeShift = activeShiftMap.get(emp.id);
                const isOnDuty = !!activeShift;
                const assigned = sites.find((s) => s.id === emp.primarySiteId);
                const dist = assigned && emp.currentLocation
                  ? calculateDistanceMeters(
                      emp.currentLocation.lat,
                      emp.currentLocation.lng,
                      assigned.location.lat,
                      assigned.location.lng
                    )
                  : null;

                return (
                  <div
                    key={emp.id}
                    onClick={() => {
                      setSelectedEmpId(emp.id);
                      onSelectSite(null);
                    }}
                    className={`pt-1.5 first:pt-0 p-2 rounded-xl cursor-pointer transition border ${
                      selectedEmpId === emp.id
                        ? 'bg-cyan-950/40 border-cyan-500/40'
                        : 'bg-slate-950/40 border-transparent hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-[11px] truncate max-w-[140px]">
                        {emp.name}
                      </span>
                      <span
                        className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-bold uppercase ${
                          isOnDuty
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {isOnDuty ? 'On-Site' : 'Off-Duty'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                      <span className="truncate max-w-[120px]">
                        Site: {assigned?.name.split(' ')[0] || 'Unassigned'}
                      </span>
                      {dist !== null && (
                        <span className="font-mono text-cyan-300">
                          {formatDistance(dist)}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between text-[9px] text-slate-500 mt-0.5">
                      <span>Ping: {emp.currentLocation?.lastPingTime || '3m ago'}</span>
                      <span>🔋{emp.currentLocation?.battery || 85}%</span>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Legend at bottom left */}
      <div className="absolute bottom-3 left-3 z-10 bg-slate-950/85 backdrop-blur-md p-2 rounded-xl border border-slate-800/80 text-[11px] text-slate-300 hidden sm:flex items-center gap-3">
        <div className="flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
          <span>Active Fence</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>On-Site Tech</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
          <span>Off-Duty Live GPS</span>
        </div>
      </div>
    </div>
  );
}
