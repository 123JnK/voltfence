import React, { useState } from 'react';
import { Employee, ElectricalSite, AttendanceRecord } from '../types';
import {
  Users,
  Search,
  Plus,
  Edit2,
  Trash2,
  Phone,
  ShieldCheck,
  MapPin,
  ArrowRight,
  Award,
  DollarSign,
  AlertOctagon,
  UserX,
  RotateCcw,
  CheckCircle,
  Key,
} from 'lucide-react';

interface EmployeeRosterProps {
  employees: Employee[];
  sites: ElectricalSite[];
  attendanceRecords: AttendanceRecord[];
  onSelectEmployeeForField: (employeeId: string) => void;
  onAddEmployee: () => void;
  onEditEmployee: (employee: Employee) => void;
  onDeleteEmployee: (employeeId: string) => void;
  onRestoreEmployee?: (employeeId: string) => void;
  isManagerLoggedIn: boolean;
  onRequestManagerLogin: () => void;
  onManagerCheckIn?: (employeeId: string, siteId: string) => void;
  onManagerCheckOut?: (employeeId: string) => void;
  currencySymbol?: string;
}

export function EmployeeRoster({
  employees,
  sites,
  attendanceRecords,
  onSelectEmployeeForField,
  onAddEmployee,
  onEditEmployee,
  onDeleteEmployee,
  onRestoreEmployee,
  isManagerLoggedIn,
  onRequestManagerLogin,
  onManagerCheckIn,
  onManagerCheckOut,
  currencySymbol = '₹',
}: EmployeeRosterProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'on_site' | 'off_site' | 'deactivated'>(
    'all'
  );
  const [employeeToDelete, setEmployeeToDelete] = useState<Employee | null>(null);

  // Compute active on-site status based on today's active attendance
  const activeRecordsByEmp = new Map<string, AttendanceRecord>();
  attendanceRecords.forEach((r) => {
    if (r.status === 'active_shift') {
      activeRecordsByEmp.set(r.employeeId, r);
    }
  });

  const filteredEmployees = employees.filter((emp) => {
    if (statusFilter === 'deactivated') return !emp.isActive;
    if (!emp.isActive) return false;

    const hasActiveShift = activeRecordsByEmp.has(emp.id);
    if (statusFilter === 'on_site' && !hasActiveShift) return false;
    if (statusFilter === 'off_site' && hasActiveShift) return false;

    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      emp.name.toLowerCase().includes(term) ||
      emp.code.toLowerCase().includes(term) ||
      emp.role.toLowerCase().includes(term) ||
      emp.certifications.some((c) => c.toLowerCase().includes(term))
    );
  });

  const activeEmployees = employees.filter((e) => e.isActive);
  const deactivatedEmployees = employees.filter((e) => !e.isActive);
  const onSiteCount = activeEmployees.filter((e) => activeRecordsByEmp.has(e.id)).length;

  const handleConfirmDelete = () => {
    if (employeeToDelete) {
      onDeleteEmployee(employeeToDelete.id);
      setEmployeeToDelete(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Search and Filters Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-400" />
            Field Electrical Technicians Roster ({activeEmployees.length} Active Staff)
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage electricians, certifications, EPF accounts, and mobile phone access authorizations.
          </p>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          {isManagerLoggedIn ? (
            <button
              onClick={onAddEmployee}
              className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-blue-600/20"
            >
              <Plus className="w-4 h-4" />
              Add Technician
            </button>
          ) : (
            <button
              onClick={onRequestManagerLogin}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition border border-slate-700"
            >
              Manager Login to Add / Delete
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs and Search */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search technician, code, cert..."
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-blue-400"
          />
        </div>

        <div className="bg-slate-900 p-1 rounded-xl border border-slate-800 flex text-xs overflow-x-auto">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1 rounded-lg transition ${
              statusFilter === 'all'
                ? 'bg-blue-600 text-white font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All Active ({activeEmployees.length})
          </button>
          <button
            onClick={() => setStatusFilter('on_site')}
            className={`px-3 py-1 rounded-lg transition flex items-center gap-1 ${
              statusFilter === 'on_site'
                ? 'bg-emerald-600 text-white font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            On-Site ({onSiteCount})
          </button>
          <button
            onClick={() => setStatusFilter('off_site')}
            className={`px-3 py-1 rounded-lg transition ${
              statusFilter === 'off_site'
                ? 'bg-slate-700 text-white font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Off-Duty ({activeEmployees.length - onSiteCount})
          </button>
          {deactivatedEmployees.length > 0 && (
            <button
              onClick={() => setStatusFilter('deactivated')}
              className={`px-3 py-1 rounded-lg transition text-rose-400 ${
                statusFilter === 'deactivated'
                  ? 'bg-rose-950/80 border border-rose-500/40 text-rose-200 font-bold'
                  : 'hover:text-rose-300'
              }`}
            >
              Removed ({deactivatedEmployees.length})
            </button>
          )}
        </div>
      </div>

      {/* Roster Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        {filteredEmployees.map((emp) => {
          const activeShift = activeRecordsByEmp.get(emp.id);
          const primarySite = sites.find((s) => s.id === emp.primarySiteId);

          return (
            <div
              key={emp.id}
              className={`bg-slate-900 border rounded-2xl p-4 transition shadow-md flex flex-col justify-between ${
                !emp.isActive
                  ? 'border-rose-900/50 opacity-70 bg-slate-950/40'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                {/* Header with Avatar & Status */}
                <div className="flex items-start justify-between gap-2 pb-2.5 border-b border-slate-800/80">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-10 h-10 rounded-xl ${
                        emp.isActive ? emp.avatarBg : 'bg-slate-800 text-slate-500'
                      } flex items-center justify-center text-white font-bold text-xs shadow-md`}
                    >
                      {emp.name
                        .split(' ')
                        .map((n) => n[0])
                        .join('')}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white leading-tight">{emp.name}</h4>
                      <span className="text-[10px] font-mono text-cyan-400">{emp.code}</span>
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      !emp.isActive
                        ? 'bg-rose-950 text-rose-400 border border-rose-500/30'
                        : activeShift
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {!emp.isActive ? '✕ Revoked' : activeShift ? '● On-Site' : '○ Off-Duty'}
                  </span>
                </div>

                {/* Role and Site */}
                <div className="py-2.5 space-y-1.5 text-xs">
                  <div className="font-medium text-slate-200 text-[11px] leading-snug">{emp.role}</div>

                  {activeShift ? (
                    <div className="p-2 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-[11px]">
                      <span className="text-[10px] text-emerald-400 font-bold block uppercase tracking-wider">
                        Clocked In Today:
                      </span>
                      <span className="text-white font-medium truncate block">
                        {activeShift.siteName}
                      </span>
                    </div>
                  ) : primarySite ? (
                    <div className="text-[11px] text-slate-400 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-500" />
                      <span className="truncate">Default Site: {primarySite.name}</span>
                    </div>
                  ) : null}

                  {/* Live Location Tracking when not signed in */}
                  {emp.currentLocation && (
                    <div className="flex items-center justify-between text-[10px] text-slate-400 bg-slate-950/60 px-2 py-1 rounded-lg border border-slate-800/80">
                      <span className="flex items-center gap-1 text-cyan-300 font-mono">
                        <MapPin className="w-2.5 h-2.5 text-cyan-400" />
                        {emp.currentLocation.address?.slice(0, 20) || 'NCR Live GPS'}
                      </span>
                      <span>🔋{emp.currentLocation.battery || 85}% • {emp.currentLocation.lastPingTime}</span>
                    </div>
                  )}

                  {/* Wage & OT Rate Structure */}
                  <div className="flex items-center justify-between text-[10px] text-slate-300 bg-slate-950/80 px-2 py-1 rounded-lg border border-slate-800 font-mono">
                    <span>
                      Daily: <strong className="text-white">{currencySymbol}{emp.dailyWage || 1200}</strong> ({currencySymbol}{emp.regularHourlyRate || 150}/h)
                    </span>
                    <span className="text-amber-400 font-bold">
                      OT: {currencySymbol}{emp.overtimeHourlyRate || 250}/h
                    </span>
                  </div>

                  {/* EPF & Leave preview */}
                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-800/60">
                    <span className="font-mono text-emerald-400">
                      {emp.epfEnabled && emp.epfUan ? `UAN: ${emp.epfUan.slice(0, 6)}...` : 'EPF: Exempt'}
                    </span>
                    <span className="font-mono text-cyan-400 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-500/30 text-[9px] flex items-center gap-1">
                      <Key className="w-2.5 h-2.5" /> PIN: {emp.pin || '1234'}
                    </span>
                    <span>
                      CL: {emp.leaveBalance?.casual || 0} | SL: {emp.leaveBalance?.sick || 0}
                    </span>
                  </div>

                  {/* Certifications */}
                  <div className="flex flex-wrap gap-1 pt-0.5">
                    {emp.certifications.slice(0, 2).map((cert) => (
                      <span
                        key={cert}
                        className="px-1.5 py-0.5 rounded text-[9px] bg-slate-950 text-slate-300 border border-slate-800 font-mono"
                      >
                        {cert}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2.5 border-t border-slate-800 flex items-center justify-between gap-1.5 text-xs">
                {emp.isActive ? (
                  <>
                    {/* REQUIREMENT 3: Manager Remote Check-In / Check-Out */}
                    {activeShift ? (
                      onManagerCheckOut && (
                        <button
                          onClick={() => onManagerCheckOut(emp.id)}
                          className="py-1 px-2.5 rounded-lg bg-rose-600/90 hover:bg-rose-500 text-white text-[11px] font-bold transition flex items-center gap-1 shadow-sm shadow-rose-600/30"
                          title="Manager remote check-out on technician's behalf"
                        >
                          <span>Check-Out</span>
                        </button>
                      )
                    ) : (
                      onManagerCheckIn && (
                        <button
                          onClick={() => {
                            const siteId = emp.primarySiteId || sites[0]?.id;
                            onManagerCheckIn(emp.id, siteId);
                          }}
                          className="py-1 px-2.5 rounded-lg bg-emerald-600/90 hover:bg-emerald-500 text-white text-[11px] font-bold transition flex items-center gap-1 shadow-sm shadow-emerald-600/30"
                          title="Manager remote check-in on technician's behalf"
                        >
                          <span>Check-In</span>
                        </button>
                      )
                    )}

                    <button
                      onClick={() => onSelectEmployeeForField(emp.id)}
                      className="py-1 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[11px] font-semibold transition flex items-center justify-center gap-1"
                      title="Open worker app on simulated device"
                    >
                      <span>Field App</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>

                    {isManagerLoggedIn ? (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => onEditEmployee(emp)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                          title="Edit employee details, salary & EPF"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => setEmployeeToDelete(emp)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 text-rose-400 transition"
                          title="Remove employee (locks app on their phone)"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    ) : null}
                  </>
                ) : (
                  /* Deactivated State */
                  <div className="flex items-center justify-between w-full">
                    <span className="text-[10px] text-rose-400 font-medium">
                      App Locked on Device
                    </span>
                    {onRestoreEmployee && isManagerLoggedIn && (
                      <button
                        onClick={() => onRestoreEmployee(emp.id)}
                        className="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-[10px] font-bold"
                      >
                        Restore Access
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Confirmation Modal for Deletion / Phone Lockout */}
      {employeeToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div className="bg-slate-900 border border-rose-500/50 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl text-slate-100">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-2.5 rounded-2xl bg-rose-500/10 border border-rose-500/20">
                <AlertOctagon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-white text-base">Remove Technician &amp; Lock App</h3>
                <p className="text-xs text-rose-300">Irreversible Device Revocation</p>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs space-y-2 text-slate-300 leading-relaxed">
              <p>
                Are you sure you want to remove <strong className="text-white">{employeeToDelete.name}</strong> (
                <span className="font-mono text-cyan-400">{employeeToDelete.code}</span>)?
              </p>
              <div className="p-2.5 rounded-xl bg-rose-950/60 border border-rose-500/30 text-rose-300 text-[11px] font-medium">
                ⚠️ <strong>Immediate Effect on Employee Phone:</strong> When removed, the attendance app
                will immediately cease functioning on their phone, completely locking them out of
                geo-fencing clock-ins, job site maps, and safety checklists.
              </div>
            </div>

            <div className="flex gap-2 pt-1">
              <button
                onClick={() => setEmployeeToDelete(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg shadow-rose-600/30 transition"
              >
                Yes, Remove &amp; Lock App
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
