import React, { useState } from 'react';
import { Employee, ElectricalSite } from '../types';
import { X, UserPlus, ShieldAlert, Award, DollarSign, FileText, Check, AlertCircle, Lock, Eye, EyeOff, Key } from 'lucide-react';

interface EmployeeModalProps {
  employee?: Employee | null;
  sites: ElectricalSite[];
  isOpen: boolean;
  onClose: () => void;
  onSave: (empData: Partial<Employee>) => void;
  currencySymbol?: string;
}

const COMMON_ROLES = [
  'Master Electrician & Field Supervisor',
  'High-Voltage Substation Specialist',
  'Lead Maintenance Electrician',
  'Generator & ATS Control Technician',
  'Journeyman Wireman',
  'Solar PV & Inverter Field Specialist',
  'Medium Voltage Cable Splicer',
  'Low Voltage & Lighting Controls Specialist',
  'Thermal Imaging & Predictive Maintenance Tech',
  'Industrial Motor & VFD Specialist',
  'Fire Alarm & Emergency Power Specialist',
  'Electrical Apprentice (Level 3)',
  'Electrical Apprentice (Level 2)',
];

const COMMON_CERTS = [
  'Master License',
  'Journeyman License',
  'NFPA 70E Arc Flash',
  'OSHA 30',
  'OSHA 10',
  'CPR/AED Certified',
  'Substation Tech L4',
  'EGSA Certified',
  '3M Cold Shrink MV Splicer',
  'Level II Thermographer (FLIR)',
  'NICET Fire Alarm Level III',
  'NABCEP Certified PV',
];

const AVATAR_COLORS = [
  'bg-blue-600',
  'bg-indigo-600',
  'bg-emerald-600',
  'bg-teal-600',
  'bg-cyan-600',
  'bg-amber-600',
  'bg-orange-600',
  'bg-purple-600',
  'bg-rose-600',
  'bg-sky-600',
];

export function EmployeeModal({
  employee,
  sites,
  isOpen,
  onClose,
  onSave,
  currencySymbol = '₹',
}: EmployeeModalProps) {
  if (!isOpen) return null;

  const isEditing = !!employee;

  const [name, setName] = useState(employee?.name || '');
  const [code, setCode] = useState(
    employee?.code || `ELEC-${Math.floor(100 + Math.random() * 900)}`
  );
  const [role, setRole] = useState(employee?.role || COMMON_ROLES[4]);
  const [phone, setPhone] = useState(employee?.phone || '+1 (555) 000-0000');
  const [email, setEmail] = useState(
    employee?.email || `${(name || 'tech').toLowerCase().replace(/\s+/g, '.')}@voltelectric.com`
  );
  const [emergencyContact, setEmergencyContact] = useState(
    employee?.emergencyContact || 'Emergency Contact (+1 555-000-1111)'
  );
  const [primarySiteId, setPrimarySiteId] = useState(employee?.primarySiteId || sites[0]?.id || '');
  const [avatarBg, setAvatarBg] = useState(
    employee?.avatarBg || AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)]
  );
  const [certifications, setCertifications] = useState<string[]>(
    employee?.certifications || ['Journeyman License', 'OSHA 10']
  );
  const [customCert, setCustomCert] = useState('');

  // Salary, Daily Wage & Overtime Rates
  const [basicSalary, setBasicSalary] = useState<number>(employee?.basicSalary || 40000);
  const [dailyWage, setDailyWage] = useState<number>(
    employee?.dailyWage || Math.round((employee?.basicSalary || 40000) / 26)
  );
  const [regularShiftHours, setRegularShiftHours] = useState<number>(
    employee?.regularShiftHours || 8.0
  );
  const [regularHourlyRate, setRegularHourlyRate] = useState<number>(
    employee?.regularHourlyRate || Math.round((employee?.dailyWage || 1500) / (employee?.regularShiftHours || 8))
  );
  const [overtimeHourlyRate, setOvertimeHourlyRate] = useState<number>(
    employee?.overtimeHourlyRate || Math.round(((employee?.regularHourlyRate || 180) * 1.5))
  );
  const [hazardAllowance, setHazardAllowance] = useState<number>(
    employee?.hazardAllowance || 4000
  );
  const [epfEnabled, setEpfEnabled] = useState(
    employee ? employee.epfEnabled : true
  );
  const [epfUan, setEpfUan] = useState(
    employee?.epfUan || `101${Math.floor(100000000 + Math.random() * 900000000)}`
  );
  const [epfRate, setEpfRate] = useState<number>(employee?.epfRate || 12);
  const [casualLeave, setCasualLeave] = useState<number>(employee?.leaveBalance?.casual || 6);
  const [sickLeave, setSickLeave] = useState<number>(employee?.leaveBalance?.sick || 7);
  const [earnedLeave, setEarnedLeave] = useState<number>(employee?.leaveBalance?.earned || 12);
  const [pin, setPin] = useState(employee?.pin || '1234');
  const [showPin, setShowPin] = useState(false);

  const toggleCert = (c: string) => {
    setCertifications((prev) =>
      prev.includes(c) ? prev.filter((item) => item !== c) : [...prev, c]
    );
  };

  const handleAddCustomCert = (e: React.FormEvent) => {
    e.preventDefault();
    if (customCert.trim() && !certifications.includes(customCert.trim())) {
      setCertifications([...certifications, customCert.trim()]);
      setCustomCert('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onSave({
      id: employee?.id,
      name,
      code,
      role,
      phone,
      email,
      emergencyContact,
      primarySiteId,
      avatarBg,
      certifications,
      isActive: true,
      pin: pin.trim() || '1234',
      basicSalary: Number(basicSalary) || 0,
      dailyWage: Number(dailyWage) || 0,
      regularShiftHours: Number(regularShiftHours) || 8.0,
      regularHourlyRate: Number(regularHourlyRate) || 0,
      overtimeHourlyRate: Number(overtimeHourlyRate) || 0,
      hazardAllowance: Number(hazardAllowance) || 0,
      epfEnabled,
      epfUan: epfUan.trim(),
      epfRate: Number(epfRate) || 12,
      leaveBalance: {
        casual: Number(casualLeave) || 0,
        sick: Number(sickLeave) || 0,
        earned: Number(earnedLeave) || 0,
      },
      status: employee?.status || 'off_site',
      joinedDate: employee?.joinedDate || new Date().toISOString().split('T')[0],
      bankAccountMasked: employee?.bankAccountMasked || '•••• •••• ' + Math.floor(1000 + Math.random() * 9000),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">
                {isEditing ? 'Edit Electrical Technician Profile' : 'Add New Electrical Employee'}
              </h3>
              <p className="text-xs text-slate-400">
                Configure trade licenses, primary repair site, salary, and statutory EPF account
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-6 space-y-4 text-xs">
          {/* Basic Personal Info */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2 space-y-1">
              <label className="text-slate-300 font-medium">Full Legal Name *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Robert Hawkins"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-hidden focus:border-blue-400"
              />
            </div>
            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Employee Code / ID</label>
              <input
                type="text"
                required
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="ELEC-021"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono placeholder-slate-500 focus:outline-hidden focus:border-blue-400"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Trade Specialization / Role</label>
              <input
                type="text"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                list="role-suggestions"
                placeholder="Select or enter role"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-blue-400"
              />
              <datalist id="role-suggestions">
                {COMMON_ROLES.map((r) => (
                  <option key={r} value={r} />
                ))}
              </datalist>
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Primary Assigned Work Site</label>
              <select
                value={primarySiteId}
                onChange={(e) => setPrimarySiteId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden focus:border-blue-400"
              >
                {sites.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Contact Phone (Mobile App)</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1 (555) 000-0000"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden"
              />
            </div>
            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Emergency Contact Person &amp; Phone</label>
              <input
                type="text"
                value={emergencyContact}
                onChange={(e) => setEmergencyContact(e.target.value)}
                placeholder="Spouse / Parent (+1 555-000-0000)"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-hidden"
              />
            </div>
          </div>

          {/* Mobile Portal Login Security PIN */}
          <div className="p-3.5 rounded-xl bg-slate-950/90 border border-cyan-500/30 space-y-2.5">
            <div className="flex items-center justify-between pb-1 border-b border-slate-800">
              <span className="font-bold text-cyan-300 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                <Lock className="w-3.5 h-3.5 text-cyan-400" />
                Mobile Portal Access PIN (Employee Password)
              </span>
              <span className="text-[10px] text-cyan-400 font-mono bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-500/30">
                4-Digit Secure PIN
              </span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <label className="text-slate-300 text-[11px] font-medium block">
                  Employee Sign-In PIN *
                </label>
                <div className="relative w-44">
                  <input
                    type={showPin ? 'text' : 'password'}
                    maxLength={8}
                    required
                    value={pin}
                    onChange={(e) => setPin(e.target.value.replace(/\s+/g, ''))}
                    placeholder="1234"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-3 pr-8 py-1.5 text-white font-mono text-sm tracking-widest focus:outline-hidden focus:border-cyan-400"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPin(!showPin)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1 sm:pt-4">
                <button
                  type="button"
                  onClick={() => setPin('1234')}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-[11px] font-medium transition cursor-pointer"
                >
                  Reset Default (1234)
                </button>
                <button
                  type="button"
                  onClick={() => setPin(String(Math.floor(1000 + Math.random() * 9000)))}
                  className="px-2.5 py-1.5 rounded-lg bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 text-[11px] font-medium transition cursor-pointer"
                >
                  Generate New PIN
                </button>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-snug">
              💡 The technician uses this 4-digit PIN to authenticate on their mobile portal. Employees can also reset or update their own PIN directly from the login screen or in their mobile portal settings.
            </p>
          </div>

          {/* Salary & EPF Box (Manager Restricted Configuration) */}
          <div className="p-4 rounded-xl bg-slate-950/90 border border-emerald-500/30 space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-slate-800">
              <span className="font-bold text-emerald-400 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                <DollarSign className="w-4 h-4" /> Wage &amp; Statutory EPF Setup
              </span>
              <label className="flex items-center gap-1.5 cursor-pointer text-slate-300">
                <input
                  type="checkbox"
                  checked={epfEnabled}
                  onChange={(e) => setEpfEnabled(e.target.checked)}
                  className="accent-emerald-500 rounded"
                />
                <span className="font-semibold text-emerald-300">EPF Deductions Applicable</span>
              </label>
            </div>

            {/* Daily Wage & Overtime Rates Configured Separately */}
            <div className="p-3.5 rounded-xl bg-slate-900 border border-amber-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-300 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-amber-400" />
                  Shift Work Hours &amp; Overtime Pay Structure
                </span>
                <span className="text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded font-mono">
                  Calculated Separately
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-medium text-xs">
                    Daily Wage for Regular Shift ({currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="50"
                    value={dailyWage}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) || 0;
                      setDailyWage(val);
                      const hrs = regularShiftHours || 8;
                      const hrRate = Math.round(val / hrs);
                      setRegularHourlyRate(hrRate);
                      setOvertimeHourlyRate(Math.round(hrRate * 1.5));
                    }}
                    placeholder="e.g. 1200"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono text-xs focus:border-amber-400"
                  />
                  <span className="text-[10px] text-slate-400">Fixed rate for 1 standard day shift</span>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-medium text-xs">
                    Regular Shift Work Hours (Hrs) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="16"
                    step="0.5"
                    value={regularShiftHours}
                    onChange={(e) => {
                      const hrs = parseFloat(e.target.value) || 8;
                      setRegularShiftHours(hrs);
                      if (dailyWage) {
                        const hrRate = Math.round(dailyWage / hrs);
                        setRegularHourlyRate(hrRate);
                      }
                    }}
                    placeholder="e.g. 8"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono text-xs focus:border-amber-400"
                  />
                  <span className="text-[10px] text-slate-400">Standard hours per day (default 8.0 hrs)</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-slate-800">
                <div className="space-y-1">
                  <label className="text-slate-300 font-medium text-xs">
                    Regular Shift Hourly Rate ({currencySymbol}/hr)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="10"
                    value={regularHourlyRate}
                    onChange={(e) => setRegularHourlyRate(parseFloat(e.target.value) || 0)}
                    placeholder="e.g. 150"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono text-xs focus:border-amber-400"
                  />
                  <span className="text-[10px] text-emerald-400">Paid for hours within regular shift</span>
                </div>

                <div className="space-y-1">
                  <label className="text-amber-300 font-bold text-xs flex items-center justify-between">
                    <span>Overtime Hourly Rate ({currencySymbol}/hr) *</span>
                    <span className="text-[10px] text-amber-400/80 font-normal">Separate Rate</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="10"
                    value={overtimeHourlyRate}
                    onChange={(e) => setOvertimeHourlyRate(parseFloat(e.target.value) || 0)}
                    placeholder="e.g. 250"
                    className="w-full bg-slate-950 border border-amber-500/50 rounded-lg px-3 py-1.5 text-amber-300 font-mono text-xs font-bold focus:border-amber-400 shadow-inner"
                  />
                  <span className="text-[10px] text-amber-400/90 font-medium">Applied to hours exceeding regular shift</span>
                </div>
              </div>

              <p className="text-[11px] text-slate-400 italic leading-snug">
                💡 When this technician clocks in, hours up to {regularShiftHours}h are paid at {currencySymbol}{regularHourlyRate}/hr.
                Any overtime hours beyond {regularShiftHours}h are calculated separately at {currencySymbol}{overtimeHourlyRate}/hr.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-slate-400">Reference Monthly Basic ({currencySymbol})</label>
                <input
                  type="number"
                  min="0"
                  step="500"
                  value={basicSalary}
                  onChange={(e) => setBasicSalary(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400">Site High-Voltage Hazard Allowance ({currencySymbol})</label>
                <input
                  type="number"
                  min="0"
                  step="250"
                  value={hazardAllowance}
                  onChange={(e) => setHazardAllowance(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono"
                />
              </div>
            </div>

            {epfEnabled && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div className="space-y-1">
                  <label className="text-slate-400">EPF Universal Account Number (UAN)</label>
                  <input
                    type="text"
                    value={epfUan}
                    onChange={(e) => setEpfUan(e.target.value)}
                    placeholder="12-digit UAN"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400">Employee EPF Contribution Rate (%)</label>
                  <input
                    type="number"
                    min="1"
                    max="20"
                    value={epfRate}
                    onChange={(e) => setEpfRate(parseFloat(e.target.value) || 12)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono"
                  />
                </div>
              </div>
            )}

            <div className="text-[11px] text-slate-400 italic">
              💡 Statutory standard: 12% employee deduction and matching 12% employer contribution
              (3.67% EPF + 8.33% EPS pension).
            </div>
          </div>

          {/* Leave Balances */}
          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
            <span className="font-bold text-slate-300 text-xs block uppercase tracking-wider">
              Annual Leave Allowances (Days)
            </span>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-slate-400 block text-[11px] mb-1">Casual Leave (CL)</label>
                <input
                  type="number"
                  min="0"
                  value={casualLeave}
                  onChange={(e) => setCasualLeave(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-white font-mono"
                />
              </div>
              <div>
                <label className="text-slate-400 block text-[11px] mb-1">Sick Leave (SL)</label>
                <input
                  type="number"
                  min="0"
                  value={sickLeave}
                  onChange={(e) => setSickLeave(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-white font-mono"
                />
              </div>
              <div>
                <label className="text-slate-400 block text-[11px] mb-1">Earned / Annual (EL)</label>
                <input
                  type="number"
                  min="0"
                  value={earnedLeave}
                  onChange={(e) => setEarnedLeave(parseInt(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-white font-mono"
                />
              </div>
            </div>
          </div>

          {/* Trade Certifications */}
          <div className="space-y-1.5">
            <label className="text-slate-300 font-medium flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              Trade Licenses &amp; Safety Certifications
            </label>
            <div className="flex flex-wrap gap-1.5">
              {COMMON_CERTS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => toggleCert(c)}
                  className={`px-2 py-1 rounded-lg text-[11px] border transition flex items-center gap-1 ${
                    certifications.includes(c)
                      ? 'bg-amber-500/20 border-amber-500/50 text-amber-300 font-medium'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {certifications.includes(c) && <Check className="w-3 h-3 text-amber-400" />}
                  {c}
                </button>
              ))}
            </div>
          </div>

          {/* Footer actions */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-300 hover:bg-slate-800 text-xs transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-lg shadow-blue-600/25"
            >
              {isEditing ? 'Save Changes' : 'Add Employee to Roster'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
