import React, { useState } from 'react';
import {
  Building2,
  Users,
  MapPin,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  LogOut,
  Calendar,
  Layers,
  Search,
  ExternalLink,
  Zap,
  HardHat,
  Filter,
  Download,
  KeyRound,
  Check,
} from 'lucide-react';
import { ElectricalSite, Employee, AttendanceRecord, CompanySettings } from '../types';
import { formatDuration } from '../utils/geo';
import { MapView } from './MapView';

interface ClientPortalViewProps {
  sites: ElectricalSite[];
  employees: Employee[];
  attendanceRecords: AttendanceRecord[];
  companySettings: CompanySettings;
  onLogout: () => void;
  clientIdentifier?: string;
  apiKey?: string;
}

export function ClientPortalView({
  sites,
  employees,
  attendanceRecords,
  companySettings,
  onLogout,
  clientIdentifier,
  apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || 'AIzaSyAIDQ8nQBS2lWnuoonmT76KhECKlnzn7VI',
}: ClientPortalViewProps) {
  const [selectedSiteId, setSelectedSiteId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'overview' | 'sites' | 'attendance'>('overview');
  const [copiedNotification, setCopiedNotification] = useState(false);

  const activeSites = sites.filter((s) => s.status === 'active');
  const activeShifts = attendanceRecords.filter((r) => r.status === 'active_shift');
  const verifiedShifts = attendanceRecords.filter((r) => r.geofenceVerified);
  const complianceRate =
    attendanceRecords.length > 0
      ? Math.round((verifiedShifts.length / attendanceRecords.length) * 100)
      : 100;

  const filteredRecords = attendanceRecords.filter((rec) => {
    if (selectedSiteId && rec.siteId !== selectedSiteId) return false;
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      rec.employeeName.toLowerCase().includes(term) ||
      rec.siteName.toLowerCase().includes(term) ||
      (rec.taskDescription && rec.taskDescription.toLowerCase().includes(term))
    );
  });

  const handleExportCsv = () => {
    if (attendanceRecords.length === 0) {
      alert('No attendance records available to export.');
      return;
    }

    const headers = [
      'Date',
      'Technician Name',
      'Employee Code',
      'Site Name',
      'Site Code',
      'Check-In Time',
      'Check-Out Time',
      'Duration (Minutes)',
      'Regular Hours',
      'Overtime Hours',
      'Geofence Verified',
      'Distance From Center (m)',
      'PPE Confirmed',
      'Task Description',
      'Device Notes',
    ];

    const rows = attendanceRecords.map((r) => {
      const emp = employees.find((e) => e.id === r.employeeId);
      const site = sites.find((s) => s.id === r.siteId);
      return [
        r.date,
        `"${(r.employeeName || emp?.name || '').replace(/"/g, '""')}"`,
        `"${emp?.code || ''}"`,
        `"${(r.siteName || site?.name || '').replace(/"/g, '""')}"`,
        `"${site?.code || ''}"`,
        r.checkInTime,
        r.checkOutTime || 'Active Shift',
        r.durationMinutes || '',
        r.regularHours || '',
        r.overtimeHours || '',
        r.geofenceVerified ? 'YES' : 'NO (Override)',
        r.checkInDistanceMeters || 0,
        r.ppeConfirmed ? 'YES' : 'NO',
        `"${(r.taskDescription || '').replace(/"/g, '""')}"`,
        `"${(r.deviceNotes || '').replace(/"/g, '""')}"`,
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    const dateStr = new Date().toISOString().split('T')[0];
    link.setAttribute('download', `${companySettings.companyName.replace(/[^a-zA-Z0-9]/g, '_')}_Client_Attendance_${dateStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 3000);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Client Header */}
      <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shadow-lg shadow-cyan-500/10">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-white text-base tracking-tight">
                  {companySettings.companyName.split(' ')[0]}
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 uppercase font-bold">
                  Client &amp; Stakeholder Portal
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate max-w-[260px] sm:max-w-none">
                {companySettings.companyName} • Live Contractor Oversight
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleExportCsv}
              className="px-3 py-1.5 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/40 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-sm"
              title="Download full audited attendance report as CSV"
            >
              {copiedNotification ? <Check className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{copiedNotification ? 'CSV Downloaded!' : 'Export CSV Report'}</span>
            </button>

            <div className="hidden md:flex items-center gap-2 bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-xl text-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className="text-slate-300 font-medium">
                {clientIdentifier || 'Authorized Stakeholder'}
              </span>
            </div>

            <button
              onClick={onLogout}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/60 hover:text-rose-300 text-slate-300 border border-slate-700 hover:border-rose-500/40 text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
              title="Sign out of client portal"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl w-full mx-auto p-4 sm:px-6 py-6 flex-1 flex flex-col space-y-6">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Live Sites &amp; Geofences</span>
          </button>

          <button
            onClick={() => setActiveTab('attendance')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'attendance'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Attendance Log ({attendanceRecords.length})</span>
          </button>
        </div>

        {/* Top KPI Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              Assigned Sites
            </span>
            <div className="text-2xl font-black text-white font-mono mt-1">
              {sites.length}
            </div>
            <span className="text-[11px] text-cyan-400 mt-0.5 block">
              {activeSites.length} Active Under Contract
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              Electricians On-Site Now
            </span>
            <div className="text-2xl font-black text-emerald-400 font-mono mt-1 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              {activeShifts.length}
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5 block">
              Active Shift Workers
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              Geofence Safety Verification
            </span>
            <div className="text-2xl font-black text-cyan-400 font-mono mt-1">
              {complianceRate}%
            </div>
            <span className="text-[11px] text-emerald-400 mt-0.5 flex items-center gap-1 font-medium">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              Inside Safe Work Radius
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              Total Logged Shifts
            </span>
            <div className="text-2xl font-black text-amber-400 font-mono mt-1">
              {attendanceRecords.length}
            </div>
            <span className="text-[11px] text-slate-400 mt-0.5 block">
              Audited Time Logs
            </span>
          </div>
        </div>

        {/* TAB 1: OVERVIEW & MAP */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Live Map */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-cyan-400" />
                  <h3 className="text-sm font-bold text-white">Live Project Sites &amp; Geofences</h3>
                </div>
                <span className="text-xs text-slate-400 font-mono">
                  {sites.length} Active Zones
                </span>
              </div>
              <div className="mt-4 rounded-xl overflow-hidden border border-slate-800 h-[380px]">
                <MapView
                  apiKey={apiKey}
                  sites={sites}
                  employees={employees}
                  attendanceRecords={attendanceRecords}
                  userLocation={{ lat: 28.5355, lng: 77.3910, accuracy: 5 }}
                  selectedSiteId={selectedSiteId}
                  onSelectSite={(id) => setSelectedSiteId(id)}
                  onSimulateAtSite={() => {}}
                  showCompletedSites={true}
                  currencySymbol={companySettings.currencySymbol}
                />
              </div>
            </div>

            {/* Sites List */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Contracted Electrical Maintenance &amp; Repair Projects
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {sites.map((site) => {
                  const onSiteCount = attendanceRecords.filter(
                    (r) => r.siteId === site.id && r.status === 'active_shift'
                  ).length;

                  return (
                    <div
                      key={site.id}
                      onClick={() => setSelectedSiteId(site.id)}
                      className={`p-4 rounded-2xl border transition cursor-pointer flex flex-col justify-between ${
                        selectedSiteId === site.id
                          ? 'bg-slate-900 border-cyan-500 shadow-md ring-1 ring-cyan-500/20'
                          : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="text-[10px] font-mono text-cyan-400 font-bold block">
                              {site.code} • {site.category.toUpperCase()}
                            </span>
                            <h4 className="font-bold text-white text-sm mt-0.5">{site.name}</h4>
                          </div>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              site.status === 'active'
                                ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {site.status}
                          </span>
                        </div>

                        <p className="text-xs text-slate-400 mt-2 flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                          <span>{site.address}</span>
                        </p>

                        <div className="mt-3 flex items-center gap-3 text-xs text-slate-400">
                          <div>
                            <span className="text-slate-500">Geofence:</span>{' '}
                            <strong className="text-slate-200 font-mono">{site.geofenceRadius}m</strong>
                          </div>
                          <div>
                            <span className="text-slate-500">Contact:</span>{' '}
                            <strong className="text-slate-200">{site.contactPerson}</strong>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
                          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                          <span>{onSiteCount} technician{onSiteCount !== 1 ? 's' : ''} on site</span>
                        </div>
                        <span className="text-cyan-400 hover:underline flex items-center gap-1 text-[11px] font-semibold">
                          View Geofence &rarr;
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: AUDITED ATTENDANCE LOG */}
        {activeTab === 'attendance' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl">
              <div className="relative flex-1 max-w-md">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search technician, site or task..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={selectedSiteId || 'all'}
                  onChange={(e) => setSelectedSiteId(e.target.value === 'all' ? null : e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200"
                >
                  <option value="all">All Sites ({sites.length})</option>
                  {sites.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={handleExportCsv}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download CSV</span>
                </button>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950/80 border-b border-slate-800 text-[10px] uppercase font-bold tracking-wider text-slate-400">
                    <tr>
                      <th className="py-3 px-4">Technician</th>
                      <th className="py-3 px-4">Job Site</th>
                      <th className="py-3 px-4">Date &amp; Time</th>
                      <th className="py-3 px-4">Geofence Compliance</th>
                      <th className="py-3 px-4">PPE Safety</th>
                      <th className="py-3 px-4">Work Performed</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-sans">
                    {filteredRecords.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-8 text-center text-slate-500 text-xs">
                          No attendance records found matching the filter.
                        </td>
                      </tr>
                    ) : (
                      filteredRecords.map((record) => (
                        <tr key={record.id} className="hover:bg-slate-800/40 transition">
                          <td className="py-3 px-4">
                            <div className="font-bold text-white">{record.employeeName}</div>
                            <span className="text-[10px] text-cyan-400 font-mono">
                              Licensed Technician
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <div className="text-white font-medium">{record.siteName}</div>
                          </td>
                          <td className="py-3 px-4 font-mono text-[11px]">
                            <div>{record.date}</div>
                            <div className="text-slate-400 text-[10px]">
                              In: {new Date(record.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              {record.checkOutTime && (
                                <span> • Out: {new Date(record.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                              )}
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            {record.geofenceVerified ? (
                              <span className="inline-flex items-center gap-1 text-emerald-400 text-[11px] font-semibold">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                Inside Geofence ({record.checkInDistanceMeters}m)
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-amber-400 text-[11px] font-semibold">
                                <AlertTriangle className="w-3.5 h-3.5" />
                                Supervisor Override
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            {record.ppeConfirmed ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                                PPE Verified
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-400">
                                Standard
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-slate-400 max-w-xs truncate">
                            {record.taskDescription || 'Scheduled Electrical Maintenance'}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
