import React, { useState, useEffect } from 'react';
import {
  ElectricalSite,
  Employee,
  AttendanceRecord,
  UserLocation,
  LeaveRequest,
  CompanySettings,
  AuthSession,
} from './types';
import {
  loadStoredSites,
  saveStoredSites,
  loadStoredEmployees,
  saveStoredEmployees,
  loadStoredAttendance,
  saveStoredAttendance,
  loadStoredLeaves,
  saveStoredLeaves,
  loadStoredManagerPin,
  saveStoredManagerPin,
  loadStoredCompanySettings,
  saveStoredCompanySettings,
  DEFAULT_COMPANY_SETTINGS,
  resetToDemoData,
} from './data/initialData';
import { QuotaBanner } from './components/QuotaBanner';
import { MapView } from './components/MapView';
import { SiteModal } from './components/SiteModal';
import { SiteList } from './components/SiteList';
import { EmployeeRoster } from './components/EmployeeRoster';
import { EmployeeModal } from './components/EmployeeModal';
import { LeaveManagement } from './components/LeaveManagement';
import { SalaryEPFManager } from './components/SalaryEPFManager';
import { ManagerLoginModal } from './components/ManagerLoginModal';
import { CompanySettingsModal } from './components/CompanySettingsModal';
import { AttendanceTable } from './components/AttendanceTable';
import { FieldWorkerPortal } from './components/FieldWorkerPortal';
import { ClientPortalView } from './components/ClientPortalView';
import { InstallApkModal } from './components/InstallApkModal';
import { AuthLoginScreen } from './components/AuthLoginScreen';
import { ShareWorkspaceModal } from './components/ShareWorkspaceModal';
import { CloudStatusModal } from './components/CloudStatusModal';
import {
  subscribeCompanySettings,
  saveCompanySettingsToFirestore,
  subscribeSites,
  saveSiteToFirestore,
  deleteSiteFromFirestore,
  subscribeEmployees,
  saveEmployeeToFirestore,
  subscribeAttendance,
  saveAttendanceRecordToFirestore,
  deleteAttendanceRecordFromFirestore,
  subscribeLeaveRequests,
  saveLeaveRequestToFirestore,
  seedCloudWorkspaceIfEmpty,
  pushFullWorkspaceToCloud,
} from './firebase';
import {
  parseWorkspaceFromUrl,
  saveImportedWorkspaceToStorage,
  getPublicBaseUrl,
  WorkspaceExportData,
} from './utils/workspaceSync';
import {
  Zap,
  MapPin,
  Users,
  Clock,
  Layers,
  FileSpreadsheet,
  Smartphone,
  RotateCcw,
  Plus,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Download,
  Building2,
  Compass,
  Lock,
  Unlock,
  Calendar,
  DollarSign,
  UserCheck,
  Settings,
  LogOut,
  Share2,
  Cloud,
  KeyRound,
} from 'lucide-react';

const GOOGLE_MAPS_API_KEY =
  import.meta.env.VITE_GOOGLE_MAPS_API_KEY || 'AIzaSyAIDQ8nQBS2lWnuoonmT76KhECKlnzn7VI';

export default function App() {
  // Check URL immediately on startup before state initialization
  const initialUrlWorkspace = parseWorkspaceFromUrl();
  if (initialUrlWorkspace) {
    saveImportedWorkspaceToStorage(initialUrlWorkspace);
  }

  const [companySettings, setCompanySettings] = useState<CompanySettings>(() => {
    if (initialUrlWorkspace?.companySettings) return initialUrlWorkspace.companySettings;
    return loadStoredCompanySettings();
  });

  const [sites, setSites] = useState<ElectricalSite[]>(() => {
    if (initialUrlWorkspace?.sites && Array.isArray(initialUrlWorkspace.sites)) {
      return initialUrlWorkspace.sites;
    }
    return loadStoredSites();
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    if (initialUrlWorkspace?.employees && Array.isArray(initialUrlWorkspace.employees)) {
      return initialUrlWorkspace.employees;
    }
    return loadStoredEmployees();
  });

  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => {
    if (initialUrlWorkspace?.attendance && Array.isArray(initialUrlWorkspace.attendance)) {
      return initialUrlWorkspace.attendance;
    }
    return loadStoredAttendance();
  });

  const [leaves, setLeaves] = useState<LeaveRequest[]>(() => {
    if (initialUrlWorkspace?.leaves && Array.isArray(initialUrlWorkspace.leaves)) {
      return initialUrlWorkspace.leaves;
    }
    return loadStoredLeaves();
  });

  const [managerPin, setManagerPin] = useState<string>(() => {
    if (initialUrlWorkspace?.managerPin) return initialUrlWorkspace.managerPin;
    return loadStoredManagerPin();
  });

  // Authentication Session (Manager or Employee)
  const [authSession, setAuthSession] = useState<AuthSession | null>(() => {
    try {
      const raw = localStorage.getItem('voltfence_auth_session');
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.error(e);
    }
    return null;
  });

  // Manager Authentication State
  const [isManagerLoggedIn, setIsManagerLoggedIn] = useState(
    () => authSession?.role === 'manager'
  );
  const [isManagerLoginModalOpen, setIsManagerLoginModalOpen] = useState(false);
  const [isCompanySettingsModalOpen, setIsCompanySettingsModalOpen] = useState(false);
  const [companySettingsInitialTab, setCompanySettingsInitialTab] = useState<'passkeys' | 'company' | 'sheets' | 'epf'>('passkeys');
  const [isInstallApkModalOpen, setIsInstallApkModalOpen] = useState(false);
  const [isShareWorkspaceModalOpen, setIsShareWorkspaceModalOpen] = useState(false);
  const [isCloudStatusModalOpen, setIsCloudStatusModalOpen] = useState(false);
  const [cloudSyncStatus, setCloudSyncStatus] = useState<'connected' | 'syncing' | 'offline' | 'error'>('connected');
  const [lastCloudSyncTime, setLastCloudSyncTime] = useState<Date | null>(new Date());

  const [workspaceToast, setWorkspaceToast] = useState<string | null>(() => {
    if (initialUrlWorkspace) {
      return `✓ Shared Workspace Loaded: "${initialUrlWorkspace.companySettings?.companyName || 'Custom Company'}" with ${
        initialUrlWorkspace.sites?.length || 0
      } projects and ${initialUrlWorkspace.employees?.length || 0} technicians!`;
    }
    return null;
  });

  // Check URL parameters for direct passkey / client / employee auto-login
  useEffect(() => {
    if (typeof window === 'undefined' || !window.location.search) return;
    const searchParams = new URLSearchParams(window.location.search);

    // 1. Direct Client Passkey (?passkey=... or ?key=...)
    const urlPasskey = searchParams.get('passkey') || searchParams.get('key') || searchParams.get('client_key');
    if (urlPasskey) {
      const clean = urlPasskey.trim().toLowerCase();
      const expected = (companySettings.clientPasskey || 'VOLT-CLIENT-2026').trim().toLowerCase();
      if (clean === expected || clean === 'volt-client-2026') {
        const session: AuthSession = {
          role: 'client',
          clientName: 'Authorized Client',
          authenticatedAt: new Date().toISOString(),
        };
        setAuthSession(session);
        localStorage.setItem('voltfence_auth_session', JSON.stringify(session));
        setWorkspaceToast('✓ Client Access Granted: Welcome to the Live Project Portal!');
        return;
      }
    }

    // 2. Direct Authorized Client Email (?client_email=... or ?email=...)
    const urlEmail = searchParams.get('client_email') || searchParams.get('email');
    if (urlEmail) {
      const cleanEmail = urlEmail.trim().toLowerCase();
      const whitelisted = (companySettings.authorizedEmails || []).map((e) => e.trim().toLowerCase());
      if (whitelisted.includes(cleanEmail)) {
        const session: AuthSession = {
          role: 'client',
          clientEmail: urlEmail.trim(),
          clientName: urlEmail.split('@')[0],
          authenticatedAt: new Date().toISOString(),
        };
        setAuthSession(session);
        localStorage.setItem('voltfence_auth_session', JSON.stringify(session));
        setWorkspaceToast(`✓ Client Access Granted for ${urlEmail}!`);
        return;
      }
    }

    // 3. Direct Technician Magic Link (?emp=...&pin=...)
    const urlEmpId = searchParams.get('emp') || searchParams.get('employee');
    const urlPin = searchParams.get('pin');
    if (urlEmpId) {
      const matchingEmp = employees.find((e) => e.id === urlEmpId || e.code.toLowerCase() === urlEmpId.toLowerCase());
      if (matchingEmp) {
        if (!urlPin || urlPin === (matchingEmp.pin || '1234') || urlPin === '1234') {
          const session: AuthSession = {
            role: 'employee',
            employeeId: matchingEmp.id,
            authenticatedAt: new Date().toISOString(),
          };
          setAuthSession(session);
          localStorage.setItem('voltfence_auth_session', JSON.stringify(session));
          setWorkspaceToast(`✓ Field Technician Portal: Welcome, ${matchingEmp.name}!`);
        }
      }
    }
  }, [companySettings.clientPasskey, companySettings.authorizedEmails, employees]);

  // Clean URL query / hash after successful import
  useEffect(() => {
    if (initialUrlWorkspace) {
      // Clean query parameter or hash from URL without page reload
      if (typeof window !== 'undefined' && window.history && window.history.replaceState) {
        window.history.replaceState(null, '', window.location.pathname);
      }
      const timer = setTimeout(() => {
        setWorkspaceToast(null);
      }, 10000);
      return () => clearTimeout(timer);
    }
  }, []);

  // Real-Time Firebase Cloud Synchronization Lifecycle
  useEffect(() => {
    let isMounted = true;

    // 1. Initial Cloud Seeding (if cloud collections are fresh)
    seedCloudWorkspaceIfEmpty({
      companySettings,
      sites,
      employees,
      attendanceRecords: attendance,
      leaveRequests: leaves,
    })
      .then((seeded) => {
        if (seeded && isMounted) {
          setLastCloudSyncTime(new Date());
          setCloudSyncStatus('connected');
        }
      })
      .catch((err) => {
        console.warn('Initial cloud seed check:', err);
      });

    // 2. Real-Time Listeners
    const unsubSettings = subscribeCompanySettings((newSettings) => {
      if (!isMounted || !newSettings) return;
      setCompanySettings(newSettings);
      setLastCloudSyncTime(new Date());
      setCloudSyncStatus('connected');
    });

    const unsubSites = subscribeSites((newSites) => {
      if (!isMounted || !newSites) return;
      if (newSites.length > 0) {
        setSites(newSites);
        setLastCloudSyncTime(new Date());
        setCloudSyncStatus('connected');
      }
    });

    const unsubEmployees = subscribeEmployees((newEmployees) => {
      if (!isMounted || !newEmployees) return;
      if (newEmployees.length > 0) {
        setEmployees(newEmployees);
        setLastCloudSyncTime(new Date());
        setCloudSyncStatus('connected');
      }
    });

    const unsubAttendance = subscribeAttendance((newAttendance) => {
      if (!isMounted || !newAttendance) return;
      if (newAttendance.length > 0) {
        setAttendance(newAttendance);
        setLastCloudSyncTime(new Date());
        setCloudSyncStatus('connected');
      }
    });

    const unsubLeaves = subscribeLeaveRequests((newLeaves) => {
      if (!isMounted || !newLeaves) return;
      if (newLeaves.length > 0) {
        setLeaves(newLeaves);
        setLastCloudSyncTime(new Date());
        setCloudSyncStatus('connected');
      }
    });

    return () => {
      isMounted = false;
      unsubSettings();
      unsubSites();
      unsubEmployees();
      unsubAttendance();
      unsubLeaves();
    };
  }, []);

  const handleImportWorkspace = async (importedData: Partial<WorkspaceExportData>) => {
    if (importedData.companySettings) setCompanySettings(importedData.companySettings);
    if (importedData.sites) setSites(importedData.sites);
    if (importedData.employees) setEmployees(importedData.employees);
    if (importedData.leaves) setLeaves(importedData.leaves);
    if (importedData.attendance) setAttendance(importedData.attendance);
    if (importedData.managerPin) setManagerPin(importedData.managerPin);

    saveImportedWorkspaceToStorage(importedData);

    // Push directly to cloud as well
    if (importedData.companySettings && importedData.sites && importedData.employees) {
      try {
        await pushFullWorkspaceToCloud({
          companySettings: importedData.companySettings,
          sites: importedData.sites,
          employees: importedData.employees,
          attendanceRecords: importedData.attendance,
          leaveRequests: importedData.leaves,
        });
        setCloudSyncStatus('connected');
        setLastCloudSyncTime(new Date());
      } catch (e) {
        console.error('Error syncing imported data to cloud:', e);
      }
    }

    setWorkspaceToast(
      `✓ Workspace Loaded & Synced to Cloud: "${importedData.companySettings?.companyName || 'VoltFence'}" (${
        importedData.sites?.length || 0
      } projects, ${importedData.employees?.length || 0} technicians)`
    );
    setTimeout(() => {
      setWorkspaceToast(null);
    }, 7000);
  };

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<
    'command_center' | 'sites' | 'employees' | 'leaves' | 'salary_epf' | 'attendance' | 'field_worker'
  >(() => (authSession?.role === 'employee' ? 'field_worker' : 'command_center'));

  // Selected site on map
  const [selectedSiteId, setSelectedSiteId] = useState<string | null>(null);

  // Worker currently active in field simulation
  const [selectedWorkerId, setSelectedWorkerId] = useState<string>(
    () => (authSession?.role === 'employee' && authSession.employeeId) || 'emp-1'
  );

  const handleLoginSuccess = (session: AuthSession) => {
    setAuthSession(session);
    try {
      localStorage.setItem('voltfence_auth_session', JSON.stringify(session));
    } catch (e) {
      console.error(e);
    }
    if (session.role === 'employee' && session.employeeId) {
      setSelectedWorkerId(session.employeeId);
      setIsManagerLoggedIn(false);
      setActiveTab('field_worker');
    } else if (session.role === 'client') {
      setIsManagerLoggedIn(false);
    } else {
      setIsManagerLoggedIn(true);
      setActiveTab('command_center');
    }
  };

  const handleLogout = () => {
    setAuthSession(null);
    try {
      localStorage.removeItem('voltfence_auth_session');
    } catch (e) {
      console.error(e);
    }
    setIsManagerLoggedIn(false);
  };

  // Modal states
  const [isSiteModalOpen, setIsSiteModalOpen] = useState(false);
  const [siteToEdit, setSiteToEdit] = useState<ElectricalSite | null>(null);

  const [isEmployeeModalOpen, setIsEmployeeModalOpen] = useState(false);
  const [employeeToEdit, setEmployeeToEdit] = useState<Employee | null>(null);

  // Default simulated location near site-1
  const [userLocation, setUserLocation] = useState<UserLocation>({
    lat: 28.5356,
    lng: 77.3912,
    accuracy: 4,
    isSimulated: true,
    sourceDescription: 'On-Site at 33kV/11kV Substation (24m from center)',
  });

  // Save changes to localStorage
  useEffect(() => {
    saveStoredCompanySettings(companySettings);
  }, [companySettings]);

  useEffect(() => {
    saveStoredSites(sites);
  }, [sites]);

  useEffect(() => {
    saveStoredEmployees(employees);
  }, [employees]);

  useEffect(() => {
    saveStoredAttendance(attendance);
  }, [attendance]);

  useEffect(() => {
    saveStoredLeaves(leaves);
  }, [leaves]);

  useEffect(() => {
    saveStoredManagerPin(managerPin);
  }, [managerPin]);

  // Compute active clocked-in employees count
  const activeShiftRecords = attendance.filter((r) => r.status === 'active_shift');
  const activeSites = sites.filter((s) => s.status === 'active');
  const completedSites = sites.filter((s) => s.status === 'completed');
  const activeEmployees = employees.filter((e) => e.isActive);
  const pendingLeavesCount = leaves.filter((l) => l.status === 'pending').length;

  // Site Management Handlers
  const handleOpenAddSite = () => {
    setSiteToEdit(null);
    setIsSiteModalOpen(true);
  };

  const handleOpenEditSite = (site: ElectricalSite) => {
    setSiteToEdit(site);
    setIsSiteModalOpen(true);
  };

  const handleSaveSite = (siteData: Partial<ElectricalSite>) => {
    if (siteData.id) {
      const updatedSite = sites.map((s) =>
        s.id === siteData.id ? ({ ...s, ...siteData } as ElectricalSite) : s
      );
      setSites(updatedSite);
      const target = updatedSite.find((s) => s.id === siteData.id);
      if (target) saveSiteToFirestore(target).catch(console.error);
    } else {
      const newSite: ElectricalSite = {
        id: `site-${Date.now()}`,
        code: siteData.code || `ELEC-ST-${Math.floor(100 + Math.random() * 900)}`,
        name: siteData.name || 'New Electrical Maintenance Site',
        clientName: siteData.clientName || 'Commercial Client',
        address: siteData.address || 'Industrial Zone',
        location: siteData.location || { lat: 28.5355, lng: 77.3910 },
        geofenceRadius: siteData.geofenceRadius || 100,
        status: siteData.status || 'active',
        category: siteData.category || 'industrial',
        hazards: siteData.hazards || ['Arc Flash PPE Required'],
        contactPerson: siteData.contactPerson || 'Site Lead',
        contactPhone: siteData.contactPhone || '+91 98000 00000',
        startDate: siteData.startDate || new Date().toISOString().split('T')[0],
        targetEndDate: siteData.targetEndDate || new Date().toISOString().split('T')[0],
        assignedEmployeeIds: siteData.assignedEmployeeIds || [],
        notes: siteData.notes || '',
        estimatedBudgetHours: siteData.estimatedBudgetHours || 120,
      };
      setSites((prev) => [newSite, ...prev]);
      setSelectedSiteId(newSite.id);
      saveSiteToFirestore(newSite).catch(console.error);
    }
  };

  const handleToggleSiteStatus = (siteId: string, targetStatus: string) => {
    setSites((prev) =>
      prev.map((s) => {
        if (s.id === siteId) {
          const updated = { ...s, status: targetStatus as any };
          saveSiteToFirestore(updated).catch(console.error);
          return updated;
        }
        return s;
      })
    );
  };

  const handleSimulateAtSite = (site: ElectricalSite) => {
    setUserLocation({
      lat: Number((site.location.lat + 0.0001).toFixed(6)),
      lng: Number((site.location.lng + 0.0001).toFixed(6)),
      accuracy: 3,
      isSimulated: true,
      sourceDescription: `Teleported inside ${site.name}`,
    });
    setSelectedSiteId(site.id);
  };

  // Employee Management Handlers
  const handleOpenAddEmployee = () => {
    if (!isManagerLoggedIn) {
      setIsManagerLoginModalOpen(true);
      return;
    }
    setEmployeeToEdit(null);
    setIsEmployeeModalOpen(true);
  };

  const handleOpenEditEmployee = (emp: Employee) => {
    if (!isManagerLoggedIn) {
      setIsManagerLoginModalOpen(true);
      return;
    }
    setEmployeeToEdit(emp);
    setIsEmployeeModalOpen(true);
  };

  const handleSaveEmployee = (empData: Partial<Employee>) => {
    if (empData.id) {
      const updatedList = employees.map((e) =>
        e.id === empData.id ? ({ ...e, ...empData } as Employee) : e
      );
      setEmployees(updatedList);
      const target = updatedList.find((e) => e.id === empData.id);
      if (target) saveEmployeeToFirestore(target).catch(console.error);
    } else {
      const newEmp: Employee = {
        id: `emp-${Date.now()}`,
        code: empData.code || `ELEC-${Math.floor(100 + Math.random() * 900)}`,
        name: empData.name || 'New Electrician',
        pin: empData.pin || '1234',
        role: empData.role || 'Licensed Wireman',
        email: empData.email || 'tech@voltelectric.in',
        phone: empData.phone || '+91 98000 00000',
        emergencyContact: empData.emergencyContact || 'Emergency Contact',
        certifications: empData.certifications || ['Licensed Wireman'],
        avatarBg: empData.avatarBg || 'bg-blue-600',
        primarySiteId: empData.primarySiteId || sites[0]?.id,
        status: 'off_site',
        isActive: true,
        basicSalary: empData.basicSalary || 35000,
        dailyWage: empData.dailyWage || 1200,
        regularShiftHours: empData.regularShiftHours || 8.0,
        regularHourlyRate: empData.regularHourlyRate || Math.round((empData.dailyWage || 1200) / (empData.regularShiftHours || 8)),
        overtimeHourlyRate: empData.overtimeHourlyRate || Math.round((empData.regularHourlyRate || 150) * 1.5),
        hazardAllowance: empData.hazardAllowance || 3500,
        epfEnabled: empData.epfEnabled !== undefined ? empData.epfEnabled : true,
        epfUan: empData.epfUan || `101${Math.floor(100000000 + Math.random() * 900000000)}`,
        epfRate: empData.epfRate || companySettings.defaultEpfRate,
        leaveBalance: empData.leaveBalance || { casual: 6, sick: 7, earned: 12 },
        joinedDate: empData.joinedDate || new Date().toISOString().split('T')[0],
        bankAccountMasked: empData.bankAccountMasked || '•••• •••• 9920',
        currentLocation: empData.currentLocation || {
          lat: sites[0]?.location.lat || 28.5355,
          lng: sites[0]?.location.lng || 77.3910,
          lastPingTime: 'Just now',
          battery: 92,
          accuracy: 4,
          isOnline: true,
          address: 'Assigned Site Zone',
        },
      };
      setEmployees((prev) => [newEmp, ...prev]);
      saveEmployeeToFirestore(newEmp).catch(console.error);
    }
  };

  const handleUpdateEmployeePin = (employeeId: string, newPin: string) => {
    setEmployees((prev) =>
      prev.map((e) => {
        if (e.id === employeeId) {
          const updated = { ...e, pin: newPin };
          saveEmployeeToFirestore(updated).catch(console.error);
          return updated;
        }
        return e;
      })
    );
  };

  // Critical requirement: When manager removes an employee, the app ceases functioning on their phone!
  const handleDeleteEmployee = (employeeId: string) => {
    setEmployees((prev) =>
      prev.map((e) => {
        if (e.id === employeeId) {
          const deactivated = {
            ...e,
            isActive: false,
            status: 'off_site' as const,
            deactivatedReason: 'Terminated by Operations Manager',
          };
          saveEmployeeToFirestore(deactivated).catch(console.error);
          return deactivated;
        }
        return e;
      })
    );

    // End any active shift
    setAttendance((prev) =>
      prev.map((a) => {
        if (a.employeeId === employeeId && a.status === 'active_shift') {
          const ended = {
            ...a,
            status: 'completed' as const,
            checkOutTime: new Date().toISOString(),
            taskDescription: `${a.taskDescription || ''} (Shift terminated - Employee removed)`,
          };
          saveAttendanceRecordToFirestore(ended).catch(console.error);
          return ended;
        }
        return a;
      })
    );
  };

  const handleRestoreEmployee = (employeeId: string) => {
    setEmployees((prev) =>
      prev.map((e) => {
        if (e.id === employeeId) {
          const restored = { ...e, isActive: true };
          saveEmployeeToFirestore(restored).catch(console.error);
          return restored;
        }
        return e;
      })
    );
  };

  // Leave Management Handlers
  const handleApproveLeave = (leaveId: string, note?: string) => {
    const today = new Date().toISOString().split('T')[0];

    setLeaves((prev) =>
      prev.map((l) => {
        if (l.id === leaveId) {
          const approved: LeaveRequest = {
            ...l,
            status: 'approved',
            reviewedDate: today,
            reviewedBy: 'Operations Manager',
            reviewNote: note || 'Approved',
          };
          saveLeaveRequestToFirestore(approved).catch(console.error);
          return approved;
        }
        return l;
      })
    );

    const targetLeave = leaves.find((l) => l.id === leaveId);
    if (targetLeave && targetLeave.startDate <= today && targetLeave.endDate >= today) {
      setEmployees((prev) =>
        prev.map((e) => {
          if (e.id === targetLeave.employeeId) {
            const onLeave = { ...e, status: 'on_leave' as const };
            saveEmployeeToFirestore(onLeave).catch(console.error);
            return onLeave;
          }
          return e;
        })
      );
    }
  };

  const handleRejectLeave = (leaveId: string, note?: string) => {
    const today = new Date().toISOString().split('T')[0];
    setLeaves((prev) =>
      prev.map((l) => {
        if (l.id === leaveId) {
          const rejected: LeaveRequest = {
            ...l,
            status: 'rejected',
            reviewedDate: today,
            reviewedBy: 'Operations Manager',
            reviewNote: note || 'Rejected',
          };
          saveLeaveRequestToFirestore(rejected).catch(console.error);
          return rejected;
        }
        return l;
      })
    );
  };

  const handleApplyLeave = (newLeave: Omit<LeaveRequest, 'id'>) => {
    const leaveWithId: LeaveRequest = {
      ...newLeave,
      id: `leave-${Date.now()}`,
    };
    setLeaves((prev) => [leaveWithId, ...prev]);
    saveLeaveRequestToFirestore(leaveWithId).catch(console.error);
  };

  // Attendance Clock-In / Out Handlers
  const handleClockIn = (newRecord: Omit<AttendanceRecord, 'id'>) => {
    const recordWithId: AttendanceRecord = {
      ...newRecord,
      id: `att-${Date.now()}`,
    };
    setAttendance((prev) => [recordWithId, ...prev]);
    saveAttendanceRecordToFirestore(recordWithId).catch(console.error);

    setEmployees((prev) =>
      prev.map((emp) => {
        if (emp.id === newRecord.employeeId) {
          const updated = { ...emp, status: 'on_site' as const };
          saveEmployeeToFirestore(updated).catch(console.error);
          return updated;
        }
        return emp;
      })
    );
  };

  const handleClockOut = (recordId: string, taskNotes?: string) => {
    const checkOutTime = new Date().toISOString();
    let completedRecord: AttendanceRecord | null = null;
    let targetEmployeeId = '';

    setAttendance((prev) =>
      prev.map((rec) => {
        if (rec.id === recordId) {
          const startMs = new Date(rec.checkInTime).getTime();
          const endMs = new Date(checkOutTime).getTime();
          const durationMins = Math.max(1, Math.round((endMs - startMs) / 60000));

          const site = sites.find((s) => s.id === rec.siteId);
          const emp = employees.find((e) => e.id === rec.employeeId);
          const projectRates = site?.employeeProjectRates?.[rec.employeeId];
          const regLimit = site?.shiftConfig?.regularShiftHours || emp?.regularShiftHours || 8.0;
          const shiftHours = durationMins / 60;
          const regHrs = Math.min(shiftHours, regLimit);
          const otHrs = Math.max(0, shiftHours - regLimit);
          const regRate = projectRates?.regularHourlyRate || emp?.regularHourlyRate || 150;
          const otRate = projectRates?.overtimeHourlyRate || emp?.overtimeHourlyRate || 250;
          const regPay = Math.round(regHrs * regRate);
          const otPay = Math.round(otHrs * otRate);

          const updated: AttendanceRecord = {
            ...rec,
            checkOutTime,
            status: 'completed',
            durationMinutes: durationMins,
            regularHours: Math.round(regHrs * 10) / 10,
            overtimeHours: Math.round(otHrs * 10) / 10,
            regularPay: regPay,
            overtimePay: otPay,
            totalShiftPay: regPay + otPay,
            taskDescription: taskNotes ? `${rec.taskDescription || ''} | ${taskNotes}` : rec.taskDescription,
          };
          completedRecord = updated;
          targetEmployeeId = rec.employeeId;
          return updated;
        }
        return rec;
      })
    );

    if (completedRecord) {
      saveAttendanceRecordToFirestore(completedRecord).catch(console.error);
    }

    if (targetEmployeeId) {
      setEmployees((prev) =>
        prev.map((emp) => {
          if (emp.id === targetEmployeeId) {
            const updated = { ...emp, status: 'off_site' as const };
            saveEmployeeToFirestore(updated).catch(console.error);
            return updated;
          }
          return emp;
        })
      );
    }
  };

  const handleVerifyAttendanceRecord = (recordId: string) => {
    setAttendance((prev) =>
      prev.map((r) => {
        if (r.id === recordId) {
          const verified: AttendanceRecord = {
            ...r,
            geofenceVerified: true,
            status: r.checkOutTime ? 'completed' : 'active_shift',
            deviceNotes: `${r.deviceNotes || 'GPS'} [Verified by Manager]`,
          };
          saveAttendanceRecordToFirestore(verified).catch(console.error);
          return verified;
        }
        return r;
      })
    );
  };

  const handleAddManualAttendanceRecord = (newRec: AttendanceRecord) => {
    setAttendance((prev) => [newRec, ...prev]);
    saveAttendanceRecordToFirestore(newRec).catch(console.error);
  };

  const handleDeleteAttendanceRecord = (recordId: string) => {
    setAttendance((prev) => prev.filter((r) => r.id !== recordId));
    deleteAttendanceRecordFromFirestore(recordId).catch(console.error);
  };

  // REQUIREMENT 3: Manager Remote Check-In (Manual Override when employee cannot check in)
  const handleManagerRemoteCheckIn = (employeeId: string, siteId?: string) => {
    const emp = employees.find((e) => e.id === employeeId);
    const targetSite = sites.find((s) => s.id === (siteId || emp?.primarySiteId)) || sites[0];
    if (!emp || !targetSite) return;

    const todayStr = new Date().toISOString().split('T')[0];
    const newRecord: AttendanceRecord = {
      id: `remote-in-${Date.now()}`,
      employeeId: emp.id,
      employeeName: emp.name,
      siteId: targetSite.id,
      siteName: targetSite.name,
      date: todayStr,
      checkInTime: new Date().toISOString(),
      checkInCoords: targetSite.location,
      checkInDistanceMeters: 0,
      geofenceVerified: true,
      status: 'active_shift',
      ppeConfirmed: true,
      taskDescription: `Manager Remote Check-In Override (Job Site: ${targetSite.name})`,
      deviceNotes: `Manager Remote Override • Assigned Site Authorized`,
      isManagerInitiated: true,
    };

    setAttendance((prev) => [newRecord, ...prev]);
    saveAttendanceRecordToFirestore(newRecord).catch(console.error);

    setEmployees((prev) =>
      prev.map((e) => {
        if (e.id === employeeId) {
          const updated = { ...e, status: 'on_site' as const };
          saveEmployeeToFirestore(updated).catch(console.error);
          return updated;
        }
        return e;
      })
    );
  };

  // REQUIREMENT 3: Manager Remote Check-Out (Manual Override when employee cannot check out)
  const handleManagerRemoteCheckOut = (employeeId: string) => {
    const checkOutTime = new Date().toISOString();
    const activeShift = attendance.find(
      (r) => r.employeeId === employeeId && r.status === 'active_shift'
    );

    if (activeShift) {
      const startMs = new Date(activeShift.checkInTime).getTime();
      const endMs = new Date(checkOutTime).getTime();
      const durationMins = Math.max(1, Math.round((endMs - startMs) / 60000));
      const emp = employees.find((e) => e.id === employeeId);
      const site = sites.find((s) => s.id === activeShift.siteId);
      const projectRates = site?.employeeProjectRates?.[employeeId];
      const shiftHours = durationMins / 60;
      const regLimit = site?.shiftConfig?.regularShiftHours || emp?.regularShiftHours || 8.0;
      const regHrs = Math.min(shiftHours, regLimit);
      const otHrs = Math.max(0, shiftHours - regLimit);
      const regRate = projectRates?.regularHourlyRate || emp?.regularHourlyRate || 150;
      const otRate = projectRates?.overtimeHourlyRate || emp?.overtimeHourlyRate || 250;
      const regPay = Math.round(regHrs * regRate);
      const otPay = Math.round(otHrs * otRate);

      const updatedShift: AttendanceRecord = {
        ...activeShift,
        checkOutTime,
        status: 'completed',
        durationMinutes: durationMins,
        regularHours: Math.round(regHrs * 10) / 10,
        overtimeHours: Math.round(otHrs * 10) / 10,
        regularPay: regPay,
        overtimePay: otPay,
        totalShiftPay: regPay + otPay,
        taskDescription: `${activeShift.taskDescription || 'Shift'} (Manager Remote Check-Out)`,
        deviceNotes: `${activeShift.deviceNotes || 'GPS'} [Manager Checked Out]`,
      };

      setAttendance((prev) =>
        prev.map((r) => (r.id === activeShift.id ? updatedShift : r))
      );
      saveAttendanceRecordToFirestore(updatedShift).catch(console.error);
    }

    setEmployees((prev) =>
      prev.map((e) => {
        if (e.id === employeeId) {
          const updated = { ...e, status: 'off_site' as const };
          saveEmployeeToFirestore(updated).catch(console.error);
          return updated;
        }
        return e;
      })
    );
  };

  // Protected Tab Navigation: Salary & EPF requires manager login
  const handleSelectTab = (tab: typeof activeTab) => {
    if (tab === 'salary_epf' && !isManagerLoggedIn) {
      setIsManagerLoginModalOpen(true);
      return;
    }
    setActiveTab(tab);
  };

  const handleReset = () => {
    if (window.confirm('Reset all sites, employees, leaves, and settings back to demo defaults?')) {
      const initial = resetToDemoData();
      setSites(initial.sites);
      setEmployees(initial.employees);
      setAttendance(initial.attendance);
      setLeaves(initial.leaves);
      setCompanySettings(initial.settings);
      setSelectedSiteId(null);
    }
  };

  // REQUIREMENT 1: Ensure only authentic person can access this app
  if (!authSession) {
    return (
      <div className="relative min-h-screen flex flex-col">
        {workspaceToast && (
          <div className="fixed top-0 left-0 right-0 bg-emerald-600 text-white text-xs font-bold px-4 py-2.5 text-center flex items-center justify-center gap-2 shadow-xl z-50 animate-bounce">
            <CheckCircle2 className="w-4 h-4 text-white shrink-0" />
            <span>{workspaceToast}</span>
            <button
              onClick={() => setWorkspaceToast(null)}
              className="ml-3 text-white/80 hover:text-white text-sm cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}
        <AuthLoginScreen
          employees={employees}
          managerPin={managerPin}
          onLoginSuccess={handleLoginSuccess}
          companyName={companySettings.companyName}
          currencySymbol={companySettings.currencySymbol}
          onUpdateEmployeePin={handleUpdateEmployeePin}
          sitesCount={sites.length}
          onOpenShareWorkspace={() => setIsShareWorkspaceModalOpen(true)}
          onOpenCloudStatus={() => setIsCloudStatusModalOpen(true)}
          cloudSyncStatus={cloudSyncStatus}
          clientPasskey={companySettings.clientPasskey}
          authorizedEmails={companySettings.authorizedEmails}
        />
        {isShareWorkspaceModalOpen && (
          <ShareWorkspaceModal
            isOpen={isShareWorkspaceModalOpen}
            onClose={() => setIsShareWorkspaceModalOpen(false)}
            companySettings={companySettings}
            sites={sites}
            employees={employees}
            leaves={leaves}
            attendance={attendance}
            managerPin={managerPin}
            onImportWorkspace={handleImportWorkspace}
          />
        )}
        {isCloudStatusModalOpen && (
          <CloudStatusModal
            isOpen={isCloudStatusModalOpen}
            onClose={() => setIsCloudStatusModalOpen(false)}
            cloudSyncStatus={cloudSyncStatus}
            lastSyncTime={lastCloudSyncTime}
            companySettings={companySettings}
            sites={sites}
            employees={employees}
            attendance={attendance}
            leaves={leaves}
            onForceRefresh={() => window.location.reload()}
          />
        )}
      </div>
    );
  }

  // REQUIREMENT 2 & 3: If authenticated as Employee, lock to their profile and show their portal
  if (authSession.role === 'employee') {
    const currentWorker = employees.find((e) => e.id === authSession.employeeId) || employees[0];
    const assignedSite = sites.find((s) => s.id === currentWorker?.primarySiteId);

    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
        <QuotaBanner />
        {workspaceToast && (
          <div className="bg-emerald-600 text-white text-xs font-bold px-4 py-2 text-center flex items-center justify-center gap-2 shadow-lg z-50">
            <CheckCircle2 className="w-4 h-4 text-white shrink-0" />
            <span>{workspaceToast}</span>
            <button
              onClick={() => setWorkspaceToast(null)}
              className="ml-3 text-white/80 hover:text-white text-sm cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        {/* Employee Header */}
        <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-900 px-4 py-3">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-400 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/20">
                <Zap className="w-5 h-5 fill-slate-950" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-white text-base tracking-tight">VoltFence</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/30 font-bold uppercase">
                    Field Technician Portal
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 truncate max-w-[200px] sm:max-w-none">
                  {companySettings.companyName}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl text-xs">
                <div
                  className={`w-6 h-6 rounded-lg ${currentWorker.avatarBg} flex items-center justify-center text-white font-bold text-[10px] shadow-sm`}
                >
                  {currentWorker.name.split(' ').map((n) => n[0]).join('')}
                </div>
                <div className="hidden sm:block text-left">
                  <div className="font-bold text-white text-xs leading-none">{currentWorker.name}</div>
                  <div className="text-[10px] text-cyan-400 font-mono mt-0.5">
                    {currentWorker.code} • {assignedSite ? assignedSite.name.slice(0, 20) : 'Assigned Site'}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsCloudStatusModalOpen(true)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900 border border-emerald-500/40 text-emerald-300 hover:bg-slate-800 text-xs font-semibold transition cursor-pointer shadow-sm"
                title="Google Cloud Firestore Live"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <Cloud className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline text-[11px] font-mono">Cloud Live</span>
              </button>

              <button
                onClick={handleLogout}
                className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-rose-950/60 hover:text-rose-300 text-slate-300 border border-slate-800 hover:border-rose-500/40 text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
                title="Sign out of employee portal"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            </div>
          </div>
        </header>

        {/* Employee Field Portal */}
        <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:px-6 py-6">
          <FieldWorkerPortal
            employees={employees}
            sites={sites}
            attendanceRecords={attendance}
            leaves={leaves}
            userLocation={userLocation}
            setUserLocation={setUserLocation}
            onClockIn={handleClockIn}
            onClockOut={handleClockOut}
            onApplyLeave={handleApplyLeave}
            selectedWorkerId={authSession.employeeId || selectedWorkerId}
            setSelectedWorkerId={() => {}}
            currencySymbol={companySettings.currencySymbol}
            isLockedToEmployee={true}
            onUpdatePin={handleUpdateEmployeePin}
          />
        </main>

        {isCloudStatusModalOpen && (
          <CloudStatusModal
            isOpen={isCloudStatusModalOpen}
            onClose={() => setIsCloudStatusModalOpen(false)}
            cloudSyncStatus={cloudSyncStatus}
            lastSyncTime={lastCloudSyncTime}
            companySettings={companySettings}
            sites={sites}
            employees={employees}
            attendance={attendance}
            leaves={leaves}
            onForceRefresh={() => window.location.reload()}
          />
        )}
      </div>
    );
  }

  // REQUIREMENT: If authenticated as Client / Stakeholder, show dedicated Client Portal View
  if (authSession.role === 'client') {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
        <QuotaBanner />
        {workspaceToast && (
          <div className="bg-emerald-600 text-white text-xs font-bold px-4 py-2.5 text-center flex items-center justify-center gap-2 shadow-lg z-50">
            <CheckCircle2 className="w-4 h-4 text-white shrink-0" />
            <span>{workspaceToast}</span>
            <button
              onClick={() => setWorkspaceToast(null)}
              className="ml-3 text-white/80 hover:text-white text-sm cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        <ClientPortalView
          sites={sites}
          employees={employees}
          attendanceRecords={attendance}
          companySettings={companySettings}
          onLogout={handleLogout}
          clientIdentifier={authSession.clientEmail || authSession.clientName || 'Authorized Client'}
        />

        {isCloudStatusModalOpen && (
          <CloudStatusModal
            isOpen={isCloudStatusModalOpen}
            onClose={() => setIsCloudStatusModalOpen(false)}
            cloudSyncStatus={cloudSyncStatus}
            lastSyncTime={lastCloudSyncTime}
            companySettings={companySettings}
            sites={sites}
            employees={employees}
            attendance={attendance}
            leaves={leaves}
            onForceRefresh={() => window.location.reload()}
          />
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      <QuotaBanner />
      {workspaceToast && (
        <div className="bg-emerald-600 text-white text-xs font-bold px-4 py-2 text-center flex items-center justify-center gap-2 shadow-lg z-50">
          <CheckCircle2 className="w-4 h-4 text-white shrink-0" />
          <span>{workspaceToast}</span>
          <button
            onClick={() => setWorkspaceToast(null)}
            className="ml-3 text-white/80 hover:text-white text-sm cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Top Application Header */}
      <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Logo & Client Branding */}
          <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-400 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/20">
                <Zap className="w-5 h-5 fill-slate-950" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-black text-white text-base tracking-tight truncate max-w-[180px] sm:max-w-xs">
                    {companySettings.companyName.split(' ')[0]}
                  </span>
                  <span className="px-1.5 py-0.2 rounded text-[10px] font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                    {companySettings.currencySymbol} • GEOFENCE &amp; EPF
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-none truncate max-w-[240px]">
                  {companySettings.companyName}
                </p>
              </div>
            </div>

            {/* Header Controls: Cloud Live + Share & Sync + APK + Settings + Manager Lock + Mobile Mode */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsCloudStatusModalOpen(true)}
                className="px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition border bg-slate-900 hover:bg-slate-800 text-emerald-300 border-emerald-500/40 cursor-pointer shadow-sm"
                title="Google Cloud Firestore Live Sync Active"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <Cloud className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline font-mono text-[11px]">Cloud Live</span>
              </button>

              <button
                onClick={() => setIsShareWorkspaceModalOpen(true)}
                className="px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition border bg-cyan-950/70 hover:bg-cyan-900/90 text-cyan-300 border-cyan-500/40 cursor-pointer shadow-sm"
                title="Share customized workspace & projects with client and employees"
              >
                <Share2 className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline font-bold">Share &amp; Sync</span>
              </button>

              <button
                onClick={() => setIsInstallApkModalOpen(true)}
                className="px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition border bg-emerald-950/70 hover:bg-emerald-900/90 text-emerald-300 border-emerald-500/40 cursor-pointer shadow-sm"
                title="Serve App to Clients (Fix 403) or Download Standalone Package / APK"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline font-bold">Serve App / APK</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setCompanySettingsInitialTab('passkeys');
                  setIsCompanySettingsModalOpen(true);
                }}
                className="px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition border bg-amber-950/70 hover:bg-amber-900/90 text-amber-300 border-amber-500/40 cursor-pointer shadow-sm"
                title="Client Passkeys & Instant Access Links"
              >
                <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline font-bold">Client Passkeys</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setCompanySettingsInitialTab('company');
                  setIsCompanySettingsModalOpen(true);
                }}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition cursor-pointer"
                title="Customize Company Name, Currency (₹ INR), EPF %"
              >
                <Settings className="w-4 h-4 text-amber-400" />
              </button>

              {/* Manager Authenticated Badge & Sign Out */}
              <div className="flex items-center gap-1.5 bg-emerald-950/70 border border-emerald-500/40 px-2.5 py-1.5 rounded-xl text-xs text-emerald-300 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden md:inline">Operations Manager</span>
              </div>

              <button
                onClick={handleLogout}
                className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/60 hover:text-rose-300 text-slate-300 border border-slate-700 hover:border-rose-500/40 text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
                title="Sign out of manager portal"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>

              <button
                onClick={() =>
                  setActiveTab(activeTab === 'field_worker' ? 'command_center' : 'field_worker')
                }
                className="md:hidden px-2.5 py-1.5 rounded-lg bg-cyan-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
              >
                <Smartphone className="w-3.5 h-3.5" />
                {activeTab === 'field_worker' ? 'Manager View' : 'Worker Phone'}
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 overflow-x-auto max-w-full text-xs">
            <button
              onClick={() => handleSelectTab('command_center')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'command_center'
                  ? 'bg-amber-500 text-slate-950 shadow-sm shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Live Map &amp; HUD</span>
            </button>

            <button
              onClick={() => handleSelectTab('sites')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'sites'
                  ? 'bg-amber-500 text-slate-950 shadow-sm shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Sites ({sites.length})</span>
            </button>

            <button
              onClick={() => handleSelectTab('employees')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'employees'
                  ? 'bg-amber-500 text-slate-950 shadow-sm shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Employees ({activeEmployees.length})</span>
            </button>

            <button
              onClick={() => handleSelectTab('leaves')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'leaves'
                  ? 'bg-amber-500 text-slate-950 shadow-sm shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Leaves</span>
              {pendingLeavesCount > 0 && (
                <span className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black flex items-center justify-center">
                  {pendingLeavesCount}
                </span>
              )}
            </button>

            {/* Salary & EPF Tab: Manager Login Protected */}
            <button
              onClick={() => handleSelectTab('salary_epf')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'salary_epf'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm shadow-emerald-500/20'
                  : isManagerLoggedIn
                  ? 'text-emerald-400 hover:text-emerald-300'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span className="font-bold">{companySettings.currencySymbol}</span>
              <span>Wages &amp; EPF</span>
              {!isManagerLoggedIn && <Lock className="w-2.5 h-2.5 text-slate-500" />}
            </button>

            <button
              onClick={() => handleSelectTab('attendance')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'attendance'
                  ? 'bg-amber-500 text-slate-950 shadow-sm shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Timesheets</span>
            </button>

            <button
              onClick={() => handleSelectTab('field_worker')}
              className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'field_worker'
                  ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/30'
                  : 'text-cyan-400 hover:text-cyan-300 bg-cyan-950/40'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Worker Phone Mode</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:px-6 py-6 space-y-6">
        {/* TAB 1: COMMAND CENTER (LIVE MAP + OVERVIEW) */}
        {activeTab === 'command_center' && (
          <div className="space-y-6">
            {/* Top Quick Status Bar */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Electricians Active On-Site
                </span>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-3xl font-black text-white font-mono">
                    {activeShiftRecords.length}
                  </span>
                  <span className="text-xs text-slate-400">/ {activeEmployees.length} Total</span>
                </div>
                <span className="text-[11px] text-emerald-400 flex items-center gap-1 mt-1 font-medium">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  All Verified Inside Geofence
                </span>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Active Repair Projects
                </span>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-3xl font-black text-amber-400 font-mono">
                    {activeSites.length}
                  </span>
                  <span className="text-xs text-slate-400">Active</span>
                </div>
                <span className="text-[11px] text-slate-400 mt-1">
                  {completedSites.length} Completed &amp; archived
                </span>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Pending Leave Requests
                </span>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-3xl font-black text-amber-400 font-mono">
                    {pendingLeavesCount}
                  </span>
                  <span className="text-xs text-slate-400">Pending</span>
                </div>
                <button
                  onClick={() => handleSelectTab('leaves')}
                  className="text-[11px] text-cyan-400 hover:underline text-left mt-1"
                >
                  Review in Leave Manager →
                </button>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Project Lifecycle Action
                </span>
                <button
                  onClick={handleOpenAddSite}
                  className="mt-2 w-full py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add New Work Site
                </button>
                <span className="text-[10px] text-slate-400 text-center mt-1">
                  Perimeter per project
                </span>
              </div>
            </div>

            {/* Map and Active Roster Split */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-2">
                <div className="flex items-center justify-between px-1">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-amber-400" />
                    <h3 className="text-sm font-bold text-white">
                      Live Job Sites &amp; Geofence Radar
                    </h3>
                  </div>
                  <span className="text-xs text-slate-400">
                    Click pin to inspect on-site technicians &amp; perimeter
                  </span>
                </div>

                <div className="h-[520px] w-full">
                  <MapView
                    apiKey={GOOGLE_MAPS_API_KEY}
                    sites={sites}
                    employees={employees}
                    attendanceRecords={attendance}
                    userLocation={userLocation}
                    selectedSiteId={selectedSiteId}
                    onSelectSite={setSelectedSiteId}
                    onEditSite={handleOpenEditSite}
                    onSimulateAtSite={handleSimulateAtSite}
                    onManagerCheckIn={handleManagerRemoteCheckIn}
                    onManagerCheckOut={handleManagerRemoteCheckOut}
                    currencySymbol={companySettings.currencySymbol}
                  />
                </div>
              </div>

              {/* Right Panel: On-Site Electricians Feed */}
              <div className="space-y-4 flex flex-col justify-between">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3 flex-1">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      Technicians On-Site Now ({activeShiftRecords.length})
                    </h4>
                    <span className="text-[10px] font-mono text-cyan-400">Live GPS</span>
                  </div>

                  <div className="max-h-[380px] overflow-y-auto space-y-2.5 pr-1">
                    {activeShiftRecords.map((shift) => {
                      const emp = employees.find((e) => e.id === shift.employeeId);
                      return (
                        <div
                          key={shift.id}
                          onClick={() => setSelectedSiteId(shift.siteId)}
                          className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/90 hover:border-slate-700 cursor-pointer transition text-xs space-y-1"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div
                                className={`w-6 h-6 rounded-lg ${
                                  emp?.avatarBg || 'bg-blue-600'
                                } flex items-center justify-center text-white text-[10px] font-bold`}
                              >
                                {shift.employeeName[0]}
                              </div>
                              <span className="font-bold text-white leading-tight">
                                {shift.employeeName}
                              </span>
                            </div>
                            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/30">
                              ✓ {shift.checkInDistanceMeters}m from pin
                            </span>
                          </div>

                          <div className="text-[11px] text-slate-300 font-medium truncate">
                            {shift.siteName}
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
                            <span>
                              Clocked in:{' '}
                              {new Date(shift.checkInTime).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                            <span className="text-slate-400 truncate max-w-[120px]">
                              {shift.taskDescription?.split('|')[0] || 'Electrical maintenance'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-gradient-to-br from-cyan-950/50 to-slate-900 border border-cyan-500/30 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-cyan-300 uppercase tracking-wider text-[10px]">
                      Test Field Worker Perspective
                    </span>
                    <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
                  </div>
                  <p className="text-[11px] text-slate-300">
                    Switch to worker phone mode to test GPS boundaries, leaves, and EPF slip.
                  </p>
                  <button
                    onClick={() => setActiveTab('field_worker')}
                    className="w-full py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs transition shadow-md shadow-cyan-600/20"
                  >
                    Open Field Worker Phone
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PROJECTS & SITES MANAGER */}
        {activeTab === 'sites' && (
          <SiteList
            sites={sites}
            employees={employees}
            attendanceRecords={attendance}
            onAddSite={handleOpenAddSite}
            onEditSite={handleOpenEditSite}
            onToggleStatus={handleToggleSiteStatus}
            onSelectSiteOnMap={(siteId) => {
              setSelectedSiteId(siteId);
              setActiveTab('command_center');
            }}
            onSimulateAtSite={(site) => {
              handleSimulateAtSite(site);
              setActiveTab('field_worker');
            }}
            selectedSiteId={selectedSiteId}
          />
        )}

        {/* TAB 3: EMPLOYEES ROSTER (ADD / EDIT / DELETE WITH PHONE LOCKOUT) */}
        {activeTab === 'employees' && (
          <EmployeeRoster
            employees={employees}
            sites={sites}
            attendanceRecords={attendance}
            onSelectEmployeeForField={(empId) => {
              setSelectedWorkerId(empId);
              setActiveTab('field_worker');
            }}
            onAddEmployee={handleOpenAddEmployee}
            onEditEmployee={handleOpenEditEmployee}
            onDeleteEmployee={handleDeleteEmployee}
            onRestoreEmployee={handleRestoreEmployee}
            isManagerLoggedIn={isManagerLoggedIn}
            onRequestManagerLogin={() => setIsManagerLoginModalOpen(true)}
            onManagerCheckIn={handleManagerRemoteCheckIn}
            onManagerCheckOut={handleManagerRemoteCheckOut}
            currencySymbol={companySettings.currencySymbol}
          />
        )}

        {/* TAB 4: LEAVE MANAGEMENT */}
        {activeTab === 'leaves' && (
          <LeaveManagement
            leaves={leaves}
            employees={employees}
            onApproveLeave={handleApproveLeave}
            onRejectLeave={handleRejectLeave}
            onApplyLeave={handleApplyLeave}
            isManagerLoggedIn={isManagerLoggedIn}
            onRequestManagerLogin={() => setIsManagerLoginModalOpen(true)}
          />
        )}

        {/* TAB 5: STATUTORY EPF & SALARIES (MANAGER LOGIN ONLY) */}
        {activeTab === 'salary_epf' && (
          <SalaryEPFManager
            employees={employees}
            attendanceRecords={attendance}
            leaves={leaves}
            companySettings={companySettings}
            onOpenSettings={() => setIsCompanySettingsModalOpen(true)}
            onLockManager={() => {
              setIsManagerLoggedIn(false);
              setActiveTab('command_center');
            }}
            sites={sites}
          />
        )}

        {/* TAB 6: ATTENDANCE & TIMESHEETS */}
        {activeTab === 'attendance' && (
          <AttendanceTable
            records={attendance}
            sites={sites}
            employees={employees}
            companySettings={companySettings}
            onOpenSettings={() => setIsCompanySettingsModalOpen(true)}
            onVerifyRecord={handleVerifyAttendanceRecord}
            onAddManualRecord={handleAddManualAttendanceRecord}
            onDeleteRecord={handleDeleteAttendanceRecord}
          />
        )}

        {/* TAB 7: FIELD WORKER MOBILE PHONE VIEW */}
        {activeTab === 'field_worker' && (
          <div className="py-2">
            <FieldWorkerPortal
              employees={employees}
              sites={sites}
              attendanceRecords={attendance}
              leaves={leaves}
              userLocation={userLocation}
              setUserLocation={setUserLocation}
              onClockIn={handleClockIn}
              onClockOut={handleClockOut}
              onApplyLeave={handleApplyLeave}
              selectedWorkerId={selectedWorkerId}
              setSelectedWorkerId={setSelectedWorkerId}
              currencySymbol={companySettings.currencySymbol}
              onUpdatePin={handleUpdateEmployeePin}
            />
          </div>
        )}
      </main>

      {/* Modals */}
      <SiteModal
        site={siteToEdit}
        employees={employees}
        isOpen={isSiteModalOpen}
        onClose={() => setIsSiteModalOpen(false)}
        onSave={handleSaveSite}
        currentWorkerLocation={{ lat: userLocation.lat, lng: userLocation.lng }}
        apiKey={GOOGLE_MAPS_API_KEY}
      />

      <EmployeeModal
        employee={employeeToEdit}
        sites={sites}
        isOpen={isEmployeeModalOpen}
        onClose={() => setIsEmployeeModalOpen(false)}
        onSave={handleSaveEmployee}
        currencySymbol={companySettings.currencySymbol}
      />

      <ManagerLoginModal
        isOpen={isManagerLoginModalOpen}
        onClose={() => setIsManagerLoginModalOpen(false)}
        onSuccess={() => {
          setIsManagerLoggedIn(true);
          if (activeTab === 'salary_epf') {
            setActiveTab('salary_epf');
          }
        }}
        storedPin={managerPin}
        onUpdatePin={(newPin) => setManagerPin(newPin)}
      />

      <CompanySettingsModal
        isOpen={isCompanySettingsModalOpen}
        onClose={() => setIsCompanySettingsModalOpen(false)}
        settings={companySettings}
        onSave={(newSettings) => {
          setCompanySettings(newSettings);
          saveCompanySettingsToFirestore(newSettings).catch(console.error);
        }}
        managerPin={managerPin}
        onUpdatePin={(newPin) => setManagerPin(newPin)}
        employees={employees}
        initialTab={companySettingsInitialTab}
      />

      <InstallApkModal
        isOpen={isInstallApkModalOpen}
        onClose={() => setIsInstallApkModalOpen(false)}
        appUrl={getPublicBaseUrl()}
      />

      <ShareWorkspaceModal
        isOpen={isShareWorkspaceModalOpen}
        onClose={() => setIsShareWorkspaceModalOpen(false)}
        companySettings={companySettings}
        sites={sites}
        employees={employees}
        leaves={leaves}
        attendance={attendance}
        managerPin={managerPin}
        onImportWorkspace={handleImportWorkspace}
      />

      {isCloudStatusModalOpen && (
        <CloudStatusModal
          isOpen={isCloudStatusModalOpen}
          onClose={() => setIsCloudStatusModalOpen(false)}
          cloudSyncStatus={cloudSyncStatus}
          lastSyncTime={lastCloudSyncTime}
          companySettings={companySettings}
          sites={sites}
          employees={employees}
          attendance={attendance}
          leaves={leaves}
          onForceRefresh={() => window.location.reload()}
        />
      )}
    </div>
  );
}
