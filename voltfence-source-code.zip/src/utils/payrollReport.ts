import { AttendanceRecord, ElectricalSite, Employee, CompanySettings } from '../types';
import { downloadCSV, formatDuration } from './geo';

export interface PayPeriodRange {
  label: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
}

/**
 * Get standard pay period ranges (e.g. Current Month, Previous Month, Bi-Weekly)
 */
export function getStandardPayPeriods(): PayPeriodRange[] {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth(); // 0-indexed

  // Current month
  const firstDayCurrentMonth = new Date(year, month, 1);
  const lastDayCurrentMonth = new Date(year, month + 1, 0);

  // Previous month
  const firstDayPrevMonth = new Date(year, month - 1, 1);
  const lastDayPrevMonth = new Date(year, month, 0);

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const currentMonthName = monthNames[month];
  const prevMonthName = monthNames[month === 0 ? 11 : month - 1];

  const formatDate = (d: Date) => d.toISOString().split('T')[0];

  return [
    {
      label: `Current Month (${currentMonthName} ${year})`,
      startDate: formatDate(firstDayCurrentMonth),
      endDate: formatDate(lastDayCurrentMonth),
    },
    {
      label: `Previous Month (${prevMonthName} ${firstDayPrevMonth.getFullYear()})`,
      startDate: formatDate(firstDayPrevMonth),
      endDate: formatDate(lastDayPrevMonth),
    },
    {
      label: `Current Bi-Weekly (1st - 15th ${currentMonthName})`,
      startDate: `${year}-${String(month + 1).padStart(2, '0')}-01`,
      endDate: `${year}-${String(month + 1).padStart(2, '0')}-15`,
    },
    {
      label: `Current Bi-Weekly (16th - End of ${currentMonthName})`,
      startDate: `${year}-${String(month + 1).padStart(2, '0')}-16`,
      endDate: formatDate(lastDayCurrentMonth),
    },
    {
      label: 'All Recorded Pay Periods',
      startDate: '2020-01-01',
      endDate: '2099-12-31',
    },
  ];
}

export interface ShiftPayrollComputed {
  record: AttendanceRecord;
  employee?: Employee;
  site?: ElectricalSite;
  durationMinutes: number;
  totalHours: number;
  regularHours: number;
  overtimeHours: number;
  regularRate: number;
  overtimeRate: number;
  regularPay: number;
  overtimePay: number;
  grossPay: number;
  epfDeduction: number;
  employerEpf: number;
  employerEps: number;
  netPay: number;
}

export interface EmployeePayrollSummary {
  employee: Employee;
  shiftsCount: number;
  totalHours: number;
  regularHours: number;
  overtimeHours: number;
  regularPay: number;
  overtimePay: number;
  hazardAllowance: number;
  grossPay: number;
  epfDeduction: number;
  netPay: number;
}

/**
 * Filter and compute payroll details for all shifts within a specific pay period
 */
export function computePayPeriodPayroll(
  records: AttendanceRecord[],
  employees: Employee[],
  sites: ElectricalSite[],
  companySettings: CompanySettings,
  startDate: string,
  endDate: string
) {
  // Filter records within pay period date range
  const periodRecords = records.filter((r) => {
    const shiftDate = r.date || (r.checkInTime ? r.checkInTime.split('T')[0] : '');
    return shiftDate >= startDate && shiftDate <= endDate;
  });

  const computedShifts: ShiftPayrollComputed[] = periodRecords.map((rec) => {
    const emp = employees.find((e) => e.id === rec.employeeId);
    const site = sites.find((s) => s.id === rec.siteId);

    // Duration calculation
    let minutes = rec.durationMinutes;
    if (minutes === undefined || minutes === null) {
      if (rec.status === 'active_shift') {
        const elapsed = Math.max(0, Date.now() - new Date(rec.checkInTime).getTime());
        minutes = Math.round(elapsed / 60000);
      } else if (rec.checkOutTime) {
        const dur = Math.max(0, new Date(rec.checkOutTime).getTime() - new Date(rec.checkInTime).getTime());
        minutes = Math.round(dur / 60000);
      } else {
        minutes = 480; // default 8 hours
      }
    }

    const shiftHours = Math.round((minutes / 60) * 10) / 10;
    const regLimit = site?.shiftConfig?.regularShiftHours || emp?.regularShiftHours || 8.0;
    const regHrs = Math.round(Math.min(shiftHours, regLimit) * 10) / 10;
    const otHrs = Math.round(Math.max(0, shiftHours - regLimit) * 10) / 10;

    const projectRate = site?.employeeProjectRates?.[rec.employeeId];
    const regRate =
      projectRate?.regularHourlyRate ||
      emp?.regularHourlyRate ||
      Math.round((emp?.dailyWage || 1200) / regLimit);

    const otRate =
      projectRate?.overtimeHourlyRate ||
      emp?.overtimeHourlyRate ||
      Math.round(regRate * 1.5);

    const regularPay = rec.regularPay !== undefined ? rec.regularPay : Math.round(regHrs * regRate);
    const overtimePay = rec.overtimePay !== undefined ? rec.overtimePay : Math.round(otHrs * otRate);
    const grossPay = regularPay + overtimePay;

    const epfRate = emp?.epfRate || companySettings.defaultEpfRate || 12;
    const epfDeduction = emp?.epfEnabled ? Math.round((regularPay * epfRate) / 100) : 0;
    const employerEpf = emp?.epfEnabled
      ? Math.round(regularPay * ((companySettings.defaultEmployerEpfRate || 3.67) / 100))
      : 0;
    const employerEps = emp?.epfEnabled
      ? Math.round(regularPay * ((companySettings.defaultEmployerEpsRate || 8.33) / 100))
      : 0;
    const netPay = grossPay - epfDeduction;

    return {
      record: rec,
      employee: emp,
      site,
      durationMinutes: minutes,
      totalHours: shiftHours,
      regularHours: regHrs,
      overtimeHours: otHrs,
      regularRate: regRate,
      overtimeRate: otRate,
      regularPay,
      overtimePay,
      grossPay,
      epfDeduction,
      employerEpf,
      employerEps,
      netPay,
    };
  });

  // Aggregate by employee
  const employeeSummariesMap = new Map<string, EmployeePayrollSummary>();

  for (const computed of computedShifts) {
    if (!computed.employee) continue;
    const empId = computed.employee.id;

    if (!employeeSummariesMap.has(empId)) {
      employeeSummariesMap.set(empId, {
        employee: computed.employee,
        shiftsCount: 0,
        totalHours: 0,
        regularHours: 0,
        overtimeHours: 0,
        regularPay: 0,
        overtimePay: 0,
        hazardAllowance: computed.employee.hazardAllowance || 0,
        grossPay: 0,
        epfDeduction: 0,
        netPay: 0,
      });
    }

    const summary = employeeSummariesMap.get(empId)!;
    summary.shiftsCount += 1;
    summary.totalHours = Math.round((summary.totalHours + computed.totalHours) * 10) / 10;
    summary.regularHours = Math.round((summary.regularHours + computed.regularHours) * 10) / 10;
    summary.overtimeHours = Math.round((summary.overtimeHours + computed.overtimeHours) * 10) / 10;
    summary.regularPay += computed.regularPay;
    summary.overtimePay += computed.overtimePay;
    summary.grossPay += computed.grossPay;
    summary.epfDeduction += computed.epfDeduction;
    summary.netPay += computed.netPay;
  }

  // Add active employees who may have had 0 shifts in this pay period for complete roster reconciliation
  for (const emp of employees) {
    if (emp.isActive && !employeeSummariesMap.has(emp.id)) {
      employeeSummariesMap.set(emp.id, {
        employee: emp,
        shiftsCount: 0,
        totalHours: 0,
        regularHours: 0,
        overtimeHours: 0,
        regularPay: 0,
        overtimePay: 0,
        hazardAllowance: emp.hazardAllowance || 0,
        grossPay: 0,
        epfDeduction: 0,
        netPay: 0,
      });
    }
  }

  const employeeSummaries = Array.from(employeeSummariesMap.values()).sort((a, b) =>
    a.employee.name.localeCompare(b.employee.name)
  );

  // Overall Totals
  const totalShifts = computedShifts.length;
  const totalRegularHours = computedShifts.reduce((acc, c) => acc + c.regularHours, 0);
  const totalOvertimeHours = computedShifts.reduce((acc, c) => acc + c.overtimeHours, 0);
  const totalHours = totalRegularHours + totalOvertimeHours;
  const totalGrossPay = computedShifts.reduce((acc, c) => acc + c.grossPay, 0);
  const totalEpfDeductions = computedShifts.reduce((acc, c) => acc + c.epfDeduction, 0);
  const totalNetPay = computedShifts.reduce((acc, c) => acc + c.netPay, 0);

  return {
    computedShifts,
    employeeSummaries,
    totalShifts,
    totalRegularHours: Math.round(totalRegularHours * 10) / 10,
    totalOvertimeHours: Math.round(totalOvertimeHours * 10) / 10,
    totalHours: Math.round(totalHours * 10) / 10,
    totalGrossPay,
    totalEpfDeductions,
    totalNetPay,
  };
}

/**
 * Export full attendance and payroll report as formatted CSV
 */
export function exportAttendancePayrollCSV({
  records,
  employees,
  sites,
  companySettings,
  payPeriodLabel,
  startDate,
  endDate,
}: {
  records: AttendanceRecord[];
  employees: Employee[];
  sites: ElectricalSite[];
  companySettings: CompanySettings;
  payPeriodLabel: string;
  startDate: string;
  endDate: string;
}) {
  const result = computePayPeriodPayroll(
    records,
    employees,
    sites,
    companySettings,
    startDate,
    endDate
  );

  const currency = companySettings.currencySymbol || '₹';
  const generatedAt = new Date().toLocaleString();

  const rows: string[][] = [];

  // ==========================================
  // SECTION 1: REPORT HEADER
  // ==========================================
  rows.push(['COMPANY ATTENDANCE & PAYROLL RECONCILIATION REPORT']);
  rows.push(['Company Name', companySettings.companyName]);
  rows.push(['Pay Period', `${payPeriodLabel} (${startDate} to ${endDate})`]);
  rows.push(['Report Generated At', generatedAt]);
  rows.push(['Currency', `${companySettings.currencyCode || 'INR'} (${currency})`]);
  rows.push([
    'Period Totals',
    `Total Shifts: ${result.totalShifts}`,
    `Total Hours: ${result.totalHours} hrs`,
    `Gross Payroll: ${currency}${result.totalGrossPay.toLocaleString()}`,
    `EPF Deductions: ${currency}${result.totalEpfDeductions.toLocaleString()}`,
    `Net Payout: ${currency}${result.totalNetPay.toLocaleString()}`,
  ]);
  rows.push([]); // blank line

  // ==========================================
  // SECTION 2: SHIFT-BY-SHIFT DETAILED AUDIT
  // ==========================================
  rows.push(['SECTION 1: DETAILED SHIFT LOGS & WAGE BREAKDOWN']);
  rows.push([
    'Shift ID',
    'Employee Code',
    'Technician Name',
    'Designation / Role',
    'Site / Project Name',
    'Site Code',
    'Shift Date',
    'Check-In Time',
    'Check-Out Time',
    'Duration (HH:MM)',
    'Regular Shift Hours',
    'Overtime Hours',
    'Total Hours',
    `Regular Rate (${currency}/hr)`,
    `Overtime Rate (${currency}/hr)`,
    `Regular Wages (${currency})`,
    `Overtime Wages (${currency})`,
    `Gross Shift Pay (${currency})`,
    'EPF Deduct %',
    `EPF Employee Share (${currency})`,
    `EPF Employer Share (EPS+EPF) (${currency})`,
    `Net Shift Payout (${currency})`,
    'Geofence Verified',
    'Distance from Site (m)',
    'Safety PPE Confirmed',
    'Field Task Description & Supervisor Notes',
  ]);

  for (const c of result.computedShifts) {
    const rec = c.record;
    const emp = c.employee;
    const site = c.site;

    rows.push([
      rec.id,
      emp?.code || 'N/A',
      rec.employeeName,
      emp?.role || 'Technician',
      rec.siteName,
      site?.code || 'N/A',
      rec.date,
      new Date(rec.checkInTime).toLocaleTimeString(),
      rec.checkOutTime ? new Date(rec.checkOutTime).toLocaleTimeString() : 'Active On-Site',
      formatDuration(c.durationMinutes),
      c.regularHours.toFixed(1),
      c.overtimeHours.toFixed(1),
      c.totalHours.toFixed(1),
      c.regularRate.toString(),
      c.overtimeRate.toString(),
      c.regularPay.toString(),
      c.overtimePay.toString(),
      c.grossPay.toString(),
      emp?.epfEnabled ? `${emp.epfRate || companySettings.defaultEpfRate}%` : '0%',
      c.epfDeduction.toString(),
      (c.employerEpf + c.employerEps).toString(),
      c.netPay.toString(),
      rec.geofenceVerified ? 'VERIFIED INSIDE GEOFENCE' : 'FLAGGED / OVERRIDE',
      rec.checkInDistanceMeters.toString(),
      rec.ppeConfirmed ? 'YES' : 'NO',
      `${rec.taskDescription || ''} ${rec.deviceNotes ? `[${rec.deviceNotes}]` : ''}`.trim(),
    ]);
  }

  rows.push([]); // blank line
  rows.push([]); // blank line

  // ==========================================
  // SECTION 3: PAYROLL RECONCILIATION SUMMARY BY TECHNICIAN
  // ==========================================
  rows.push(['SECTION 2: PAYROLL RECONCILIATION SUMMARY BY TECHNICIAN']);
  rows.push([
    'Employee Code',
    'Technician Name',
    'Role / Trade',
    'Active Shifts',
    'Regular Hours',
    'Overtime Hours',
    'Total Hours',
    `Regular Pay (${currency})`,
    `Overtime Pay (${currency})`,
    `Hazard Allowance (${currency})`,
    `Gross Wages (${currency})`,
    `EPF Deduction (${currency})`,
    `Net Take-Home Pay (${currency})`,
    'EPF UAN Number',
    'Disbursement Bank Masked',
    'Employee Status',
  ]);

  for (const s of result.employeeSummaries) {
    const grossWithHazard = s.grossPay + (s.shiftsCount > 0 ? s.hazardAllowance : 0);
    const netWithHazard = grossWithHazard - s.epfDeduction;

    rows.push([
      s.employee.code,
      s.employee.name,
      s.employee.role,
      s.shiftsCount.toString(),
      s.regularHours.toFixed(1),
      s.overtimeHours.toFixed(1),
      s.totalHours.toFixed(1),
      s.regularPay.toString(),
      s.overtimePay.toString(),
      s.hazardAllowance.toString(),
      grossWithHazard.toString(),
      s.epfDeduction.toString(),
      netWithHazard.toString(),
      s.employee.epfUan || 'Not Applicable',
      s.employee.bankAccountMasked || '•••• •••• 9920',
      s.employee.isActive ? 'Active Employee' : 'Deactivated',
    ]);
  }

  // ==========================================
  // GRAND TOTALS ROW
  // ==========================================
  rows.push([
    'GRAND TOTALS',
    `${result.employeeSummaries.length} Employees`,
    '-',
    result.totalShifts.toString(),
    result.totalRegularHours.toFixed(1),
    result.totalOvertimeHours.toFixed(1),
    result.totalHours.toFixed(1),
    result.employeeSummaries.reduce((a, b) => a + b.regularPay, 0).toString(),
    result.employeeSummaries.reduce((a, b) => a + b.overtimePay, 0).toString(),
    result.employeeSummaries.reduce((a, b) => a + b.hazardAllowance, 0).toString(),
    result.employeeSummaries
      .reduce((a, b) => a + b.grossPay + (b.shiftsCount > 0 ? b.hazardAllowance : 0), 0)
      .toString(),
    result.totalEpfDeductions.toString(),
    result.employeeSummaries
      .reduce((a, b) => a + (b.grossPay + (b.shiftsCount > 0 ? b.hazardAllowance : 0) - b.epfDeduction), 0)
      .toString(),
    '-',
    '-',
    '-',
  ]);

  const sanitizedFilename = `VoltFence_Payroll_Attendance_${startDate}_to_${endDate}.csv`;
  downloadCSV(sanitizedFilename, rows);
}
