import { ElectricalSite, Employee, AttendanceRecord, LeaveRequest, CompanySettings } from '../types';
import { STORAGE_KEYS } from '../data/initialData';

export interface WorkspaceExportData {
  version: string;
  exportedAt: string;
  companySettings: CompanySettings;
  sites: ElectricalSite[];
  employees: Employee[];
  leaves?: LeaveRequest[];
  attendance?: AttendanceRecord[];
  managerPin?: string;
}

/**
 * Creates a clean JSON export of the current workspace
 */
export function createWorkspaceExport(
  settings: CompanySettings,
  sites: ElectricalSite[],
  employees: Employee[],
  leaves: LeaveRequest[],
  attendance: AttendanceRecord[],
  managerPin?: string
): WorkspaceExportData {
  return {
    version: '1.0',
    exportedAt: new Date().toISOString(),
    companySettings: settings,
    sites,
    employees,
    leaves,
    attendance,
    managerPin,
  };
}

/**
 * Resolves the public, client-safe URL for sharing.
 * CRITICAL 403 FIX: Replaces private developer origins ('ais-dev-...') with public preview origins ('ais-pre-...')
 * so external clients and technicians never encounter HTTP 403 Forbidden.
 */
export function getPublicBaseUrl(): string {
  const fallback = 'https://ais-pre-4pree6d3pyfs454kni3ca4-881390920619.asia-east1.run.app';
  if (typeof window === 'undefined') {
    return fallback;
  }
  let origin = window.location.origin;
  // Convert private development container URL to public shareable URL
  if (origin.includes('ais-dev-')) {
    origin = origin.replace('ais-dev-', 'ais-pre-');
  }
  return origin + window.location.pathname;
}

/**
 * Encodes workspace data into a shareable URL (both query param and hash supported)
 */
export function encodeWorkspaceToUrl(data: WorkspaceExportData): string {
  try {
    // Keep essential fields to prevent overly long URLs
    const compact = {
      v: data.version,
      t: data.exportedAt,
      cs: data.companySettings,
      s: data.sites,
      e: data.employees,
      pin: data.managerPin,
    };
    const json = JSON.stringify(compact);
    const base64 = btoa(unescape(encodeURIComponent(json)));
    const baseUrl = getPublicBaseUrl();
    // Use query parameter '?ws=' for max compatibility across all messaging apps and browsers,
    // with '#workspace=' fallback for hash routers
    return `${baseUrl}?ws=${encodeURIComponent(base64)}`;
  } catch (err) {
    console.error('Error generating share link:', err);
    return getPublicBaseUrl();
  }
}

/**
 * Checks for and decodes a shared workspace from either URL query param (?ws=...) or URL hash (#workspace=...)
 */
export function parseWorkspaceFromUrl(): Partial<WorkspaceExportData> | null {
  try {
    let base64Part: string | null = null;

    // 1. Check URL query parameters (?ws=... or ?workspace=...)
    if (typeof window !== 'undefined' && window.location.search) {
      const searchParams = new URLSearchParams(window.location.search);
      base64Part = searchParams.get('ws') || searchParams.get('workspace');
    }

    // 2. If not found in query params, check URL hash (#workspace=... or #ws=...)
    if (!base64Part && typeof window !== 'undefined' && window.location.hash) {
      const hash = window.location.hash;
      if (hash.includes('workspace=')) {
        base64Part = hash.split('workspace=')[1]?.split('&')[0] || null;
      } else if (hash.includes('ws=')) {
        base64Part = hash.split('ws=')[1]?.split('&')[0] || null;
      }
    }

    if (!base64Part) return null;

    // Decode URL-safe string
    const decodedUri = decodeURIComponent(base64Part);
    const json = decodeURIComponent(escape(atob(decodedUri)));
    const parsed = JSON.parse(json);

    return {
      version: parsed.v || '1.0',
      exportedAt: parsed.t,
      companySettings: parsed.cs,
      sites: parsed.s,
      employees: parsed.e,
      managerPin: parsed.pin,
    };
  } catch (err) {
    console.error('Failed to parse workspace from URL', err);
    return null;
  }
}

/**
 * Applies imported workspace data directly to localStorage
 */
export function saveImportedWorkspaceToStorage(data: Partial<WorkspaceExportData>): boolean {
  try {
    if (data.companySettings) {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(data.companySettings));
    }
    if (data.sites && Array.isArray(data.sites)) {
      localStorage.setItem(STORAGE_KEYS.SITES, JSON.stringify(data.sites));
    }
    if (data.employees && Array.isArray(data.employees)) {
      localStorage.setItem(STORAGE_KEYS.EMPLOYEES, JSON.stringify(data.employees));
    }
    if (data.leaves && Array.isArray(data.leaves)) {
      localStorage.setItem(STORAGE_KEYS.LEAVES, JSON.stringify(data.leaves));
    }
    if (data.attendance && Array.isArray(data.attendance)) {
      localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(data.attendance));
    }
    if (data.managerPin) {
      localStorage.setItem(STORAGE_KEYS.MANAGER_PIN, data.managerPin);
    }
    return true;
  } catch (err) {
    console.error('Failed to save imported workspace to localStorage', err);
    return false;
  }
}
