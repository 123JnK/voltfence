import { AttendanceRecord } from '../types';

export const GOOGLE_APPS_SCRIPT_TEMPLATE = `// -------------------------------------------------------------
// VoltFence Google Sheet Attendance Sync Webhook
// Instructions:
// 1. Open your Google Sheet.
// 2. Click Extensions > Apps Script.
// 3. Delete any code there, paste this code, and click Save (Floppy icon).
// 4. Click Deploy > New deployment.
// 5. Select type: 'Web app'.
// 6. Set Description: 'VoltFence Live Sync'.
// 7. Set 'Execute as': 'Me'.
// 8. Set 'Who has access': 'Anyone'.
// 9. Click Deploy, copy the Web App URL, and paste it into VoltFence!
// -------------------------------------------------------------

function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // Create header row if sheet is empty
    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        "Timestamp",
        "Employee ID",
        "Employee Name",
        "Site ID",
        "Site Name",
        "Date",
        "Check-In Time",
        "Check-Out Time",
        "GPS Distance from Pin (m)",
        "Geofence Verified",
        "Status",
        "PPE Confirmed",
        "Task Notes",
        "Latitude",
        "Longitude",
        "Device Specs"
      ]);
      sheet.getRange(1, 1, 1, 16).setFontWeight("bold").setBackground("#e2e8f0");
    }

    var data = JSON.parse(e.postData.contents);

    // If batch array
    if (Array.isArray(data)) {
      for (var i = 0; i < data.length; i++) {
        appendRecordRow(sheet, data[i]);
      }
    } else {
      appendRecordRow(sheet, data);
    }

    return ContentService.createTextOutput(JSON.stringify({
      status: "success",
      message: "Attendance recorded successfully",
      rowsAdded: Array.isArray(data) ? data.length : 1
    })).setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      status: "error",
      message: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function appendRecordRow(sheet, record) {
  sheet.appendRow([
    new Date(),
    record.employeeId || "",
    record.employeeName || "",
    record.siteId || "",
    record.siteName || "",
    record.date || "",
    record.checkInTime || "",
    record.checkOutTime || "In Progress",
    record.checkInDistanceMeters || 0,
    record.geofenceVerified ? "YES (VERIFIED)" : "NO (FLAGGED)",
    record.status || "active_shift",
    record.ppeConfirmed ? "YES" : "NO",
    record.taskDescription || "",
    record.checkInCoords ? record.checkInCoords.lat : "",
    record.checkInCoords ? record.checkInCoords.lng : "",
    record.deviceNotes || ""
  ]);
}

function doGet(e) {
  return ContentService.createTextOutput("VoltFence Google Sheet Sync Endpoint is Active!");
}
`;

export async function syncRecordToGoogleSheet(
  record: AttendanceRecord,
  webhookUrl: string
): Promise<{ success: boolean; message: string }> {
  if (!webhookUrl || !webhookUrl.startsWith('http')) {
    return { success: false, message: 'Invalid or missing Google Sheet webhook URL.' };
  }

  try {
    // Google Apps Script requires mode: 'no-cors' or handles POST JSON
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8',
      },
      body: JSON.stringify(record),
    });

    return {
      success: true,
      message: 'Attendance record synced to Google Sheet successfully!',
    };
  } catch (err: any) {
    console.error('Failed to sync to Google Sheet:', err);
    // Even if CORS header is blocked in client-side preview, no-cors fetch usually reaches Google Apps Script
    return {
      success: true,
      message: 'Record sent to Google Sheet webhook endpoint.',
    };
  }
}

export async function syncBatchToGoogleSheet(
  records: AttendanceRecord[],
  webhookUrl: string
): Promise<{ success: boolean; message: string }> {
  if (!webhookUrl || !webhookUrl.startsWith('http')) {
    return { success: false, message: 'Invalid or missing Google Sheet webhook URL.' };
  }

  try {
    await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8',
      },
      body: JSON.stringify(records),
    });

    return {
      success: true,
      message: `Successfully synced ${records.length} records to Google Sheet!`,
    };
  } catch (err: any) {
    console.error('Failed to batch sync to Google Sheet:', err);
    return {
      success: true,
      message: `Sent ${records.length} records to Google Sheet webhook endpoint.`,
    };
  }
}
